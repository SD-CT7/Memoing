#!/usr/bin/env python3
"""
players_window.py -- プレイヤー名簿の入力と、プレイヤー別スコアの表示 (画面のみ)
=============================================================================
集計そのものは race_log.py が行う。この画面は次の2つだけを担当する:
  * 名簿 (1行に1人) の入力  -> APPLY で集計 (読み取り済みの過去レースも遡って集計)
  * 集計結果の表示
  * 順位表の画像出力 (スタイルを選んで「画像出力」。実際の出力は本体が行う)
  * lorenzi の入力欄に貼るテキストの表示とコピー (中身は本体が作る)
"""

import tkinter as tk
from tkinter import ttk

_FONT = ("Consolas", 9)


class PlayersWindow(tk.Toplevel):
    def __init__(self, master, theme, roster, on_apply, get_last_names, on_close,
                 on_export=None, styles=None, default_style="dark"):
        """
        theme           {"bg","bg2","fg","fg2","btnb","btnf"} (本体と同じ配色)
        roster          最初に表示する名簿 (名前のリスト)
        on_apply(names) APPLY が押されたときに呼ぶ
        get_last_names() 直近に読み取ったレースの名前リストを返す (FILL 用)
        on_close()      画面を閉じたときに呼ぶ
        on_export(key)  画像出力が押されたときに呼ぶ (key = スタイルの識別名)。
                        返した文字列を、この画面のメッセージ欄に出す
        styles          [(識別名, 表示名), ...]  default_style: 最初に選ぶ識別名
        """
        super().__init__(master)
        self._t = theme
        self._on_apply = on_apply
        self._get_last_names = get_last_names
        self._on_close = on_close
        self._on_export = on_export
        self._styles = list(styles or [])

        self.title("Players")
        self.configure(bg=theme["bg"])
        self.geometry("560x880")

        self._label("PLAYER NAMES  (1 name per line, up to 8 players)", bold=True,
                    color=theme["fg"]).pack(anchor="w", padx=16, pady=(12, 2))
        self._label("Symbols (◇◆☆) and case are ignored. A short name also works.",
                    color=theme["fg2"], size=8).pack(anchor="w", padx=16)

        self.txt_names = tk.Text(self, height=8, bg=theme["bg2"], fg=theme["fg"],
                                 insertbackground=theme["fg"], font=_FONT, relief="flat")
        self.txt_names.pack(fill="x", padx=16, pady=6)
        self.txt_names.insert("1.0", "\n".join(roster))

        row = tk.Frame(self, bg=theme["bg"])
        row.pack(pady=4)
        self._button(row, "APPLY", self._apply).pack(side="left", padx=6)
        self._button(row, "FILL FROM LAST RACE", self._fill).pack(side="left", padx=6)

        if on_export and self._styles:
            exp = tk.Frame(self, bg=theme["bg"])
            exp.pack(pady=(6, 2))
            tk.Label(exp, text="STYLE", bg=theme["bg"], fg=theme["fg2"],
                     font=("Consolas", 9)).pack(side="left", padx=(0, 6))
            labels = [label for _, label in self._styles]
            default = next((label for key, label in self._styles if key == default_style), labels[0])
            self.var_style = tk.StringVar(value=default)
            ttk.Combobox(exp, textvariable=self.var_style, values=labels, state="readonly",
                         width=16).pack(side="left", padx=4)
            self._button(exp, "画像出力 (PNG)", self._export).pack(side="left", padx=6)

        self.var_info = tk.StringVar(value="")
        tk.Label(self, textvariable=self.var_info, bg=theme["bg"], fg=theme["fg2"],
                 font=("Consolas", 8), wraplength=520, justify="left"
                 ).pack(anchor="w", padx=16, pady=2)

        self._label("RESULT", bold=True, color=theme["fg"]).pack(anchor="w", padx=16, pady=(8, 2))
        self.txt_out = tk.Text(self, height=12, bg=theme["bg2"], fg=theme["fg"],
                               font=_FONT, relief="flat", state="disabled")
        self.txt_out.pack(fill="both", expand=True, padx=16, pady=(2, 6))

        head = tk.Frame(self, bg=theme["bg"])
        head.pack(fill="x", padx=16, pady=(6, 2))
        self._label("LORENZI TEXT  (4レースごとの和)", bold=True, color=theme["fg"]).pack(
            in_=head, side="left")
        self._button(head, "COPY", self._copy_lorenzi).pack(side="right")
        self.txt_lorenzi = tk.Text(self, height=11, bg=theme["bg2"], fg=theme["fg"],
                                   font=_FONT, relief="flat", state="disabled")
        self.txt_lorenzi.pack(fill="both", expand=True, padx=16, pady=(2, 12))

        self.protocol("WM_DELETE_WINDOW", self._close)

    # ── 部品 ──────────────────────────────────
    def _label(self, text, size=9, bold=False, color=None):
        return tk.Label(self, text=text, bg=self._t["bg"], fg=color or self._t["fg2"],
                        font=("Consolas", size, "bold" if bold else "normal"))

    def _button(self, parent, text, cmd):
        return tk.Button(parent, text=text, command=cmd, bg=self._t["btnb"],
                         fg=self._t["btnf"], activebackground="#555555",
                         font=("Consolas", 9, "bold"), relief="flat",
                         padx=8, pady=4, cursor="hand2")

    # ── 操作 ──────────────────────────────────
    def names(self):
        """入力欄から名簿を取り出す (空行は無視)。"""
        text = self.txt_names.get("1.0", "end")
        return [line.strip() for line in text.splitlines() if line.strip()]

    def _apply(self):
        self._on_apply(self.names())

    def _export(self):
        label = self.var_style.get()
        key = next((k for k, lab in self._styles if lab == label), self._styles[0][0])
        self.set_info(self._on_export(key) or "")

    def _copy_lorenzi(self):
        text = self.txt_lorenzi.get("1.0", "end").rstrip("\n")
        self.clipboard_clear()
        self.clipboard_append(text)
        self.set_info("lorenzi のテキストをコピーしました。lorenzi の入力欄に貼り付けてください。")

    def _fill(self):
        names = self._get_last_names()
        if not names:
            self.set_info("No race has been read yet.")
            return
        self.txt_names.delete("1.0", "end")
        self.txt_names.insert("1.0", "\n".join(names))
        self.set_info("Filled from the last race. Fix any misread names, then press APPLY.")

    def _close(self):
        self._on_close()
        self.destroy()

    # ── 表示 (本体から呼ぶ) ───────────────────
    def set_info(self, msg):
        self.var_info.set(msg)

    def show_lorenzi(self, text):
        """lorenzi の入力欄に貼るテキストを表示する (選択してコピーできる)。"""
        self.txt_lorenzi.config(state="normal")
        self.txt_lorenzi.delete("1.0", "end")
        self.txt_lorenzi.insert("end", text)
        self.txt_lorenzi.config(state="disabled")

    def show(self, text):
        self.txt_out.config(state="normal")
        self.txt_out.delete("1.0", "end")
        self.txt_out.insert("end", text)
        self.txt_out.config(state="disabled")
