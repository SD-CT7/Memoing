#!/usr/bin/env python3
"""
leaderboard.py -- チーム別・プレイヤー別の結果画像 (PNG) を作る
==============================================================
race_log.py の集計 (名簿を適用した結果) から、次のような画像を作る:

    ┌ タイトル ───────────────────────────────────┐
    │ チームの帯 (チームごとに色が固定)                   │
    │   TAG   プレイヤー  レース1 レース2 ...  合計  順位   チーム合計 │
    │   ±差 (すぐ下のチームとのポイント差)                   │
    └─────────────────────────────────────────────┘

* OBS では「画像ソース」で leaderboard_latest.png を指定する。
  ファイルを書き換えたときに表示も更新される (差し替えは一時ファイル経由で行う)。
* チーム = そのプレイヤーに最も多く付いたタグ。チームの合計は、スコアボードと同じく
  タグごとのポイントの合計 (名簿に載っていない人の分も含む)。
* 表示するレースは直近 12 レースまで (合計は全レース分)。
* 日本語フォント: MK7_FONT で指定、無ければ Windows の游ゴシック/メイリオ等を探す。
"""

import os
from collections import Counter
from functools import lru_cache
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

MAX_RACES = 12

W = 1600
HEADER_H = 76
STRIP_H = 34
ROW_H = 54
ROW_GAP = 8
PAD_TOP = 16
PAD_BOTTOM = 40
MIN_STACK_H = 150
LEFT_W = 360
NAME_W = 260
COL_W = 46
TOTAL_W = 104
PLACE_W = 84

# チームの色 (タグの並び順で固定。順位が入れ替わっても色は変わらない)
PALETTE = [((47, 180, 245), (74, 99, 255)),     # 青
           ((240, 80, 125), (232, 80, 76)),     # ピンク
           ((79, 176, 255), (90, 92, 255)),     # 水色
           ((245, 184, 58), (240, 138, 44))]    # オレンジ
OTHER_COLORS = ((125, 125, 135), (80, 80, 90))
MEDALS = {1: (245, 197, 24), 2: (192, 199, 208), 3: (205, 127, 50)}

_FONT_CANDIDATES = [
    r"C:\Windows\Fonts\YuGothB.ttc",
    r"C:\Windows\Fonts\meiryob.ttc",
    r"C:\Windows\Fonts\msgothic.ttc",
    r"C:\Windows\Fonts\arialbd.ttf",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
]


# ── フォント ──────────────────────────────────
@lru_cache(maxsize=None)
def get_font(size):
    paths = []
    custom = os.environ.get("MK7_FONT", "").strip()
    if custom:
        paths.append(custom)
    paths += _FONT_CANDIDATES
    for path in paths:
        try:
            if os.path.isfile(path):
                return ImageFont.truetype(path, size)
        except OSError:
            continue
    try:
        return ImageFont.load_default(size)
    except TypeError:                       # 古い Pillow
        return ImageFont.load_default()


def fit_font(draw, text, max_w, start, minimum=14):
    """text が max_w に収まる最大のフォントを返す。"""
    size = start
    while size > minimum:
        font = get_font(size)
        if draw.textlength(text, font=font) <= max_w:
            return font
        size -= 2
    return get_font(minimum)


def _draw_text(draw, xy, text, font, fill=(255, 255, 255), align="c", stroke=0):
    """align: l=左 / c=中央 / r=右 に揃え、縦は中央に置く。"""
    x, cy = xy
    w = draw.textlength(text, font=font)
    if align == "c":
        x -= w / 2
    elif align == "r":
        x -= w
    try:
        asc, desc = font.getmetrics()
        top = cy - (asc + desc) / 2
    except AttributeError:
        top = cy - 8
    draw.text((x, top), text, font=font, fill=fill, stroke_width=stroke,
              stroke_fill=(0, 0, 0))


def ordinal(n):
    if 10 <= n % 100 <= 20:
        return f"{n}th"
    suffix = {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")
    return f"{n}{suffix}"


# ── データ ────────────────────────────────────
def build_board(races, report, max_races=MAX_RACES):
    """集計 (report) と確定済みレース (races) から、描画用のデータを作る。"""
    shown = races[-max_races:]
    seqs = [r.get("seq", 0) for r in shown]

    team_total = Counter()
    for race in races:
        for row in race.get("rows", []):
            if row.get("tag") and row.get("points"):
                team_total[row["tag"]] += row["points"]

    order = []                               # チームの並び (色の割り当て用)
    for race in races:
        for t in race.get("tags") or []:
            if t not in order:
                order.append(t)
    for p in report.get("players", []):
        if p.get("team") and p["team"] not in order:
            order.append(p["team"])
    for t in team_total:
        if t not in order:
            order.append(t)

    # 全プレイヤーの順位 (同点は同順位)
    players = report.get("players", [])
    ranked = sorted(range(len(players)), key=lambda i: -players[i]["points"])
    place, cur, last = {}, 0, None
    for pos, i in enumerate(ranked, 1):
        if players[i]["points"] != last:
            cur, last = pos, players[i]["points"]
        place[i] = cur

    def view(i):
        p = players[i]
        per = []
        for s in seqs:
            e = p.get("per_race", {}).get(str(s))
            per.append(e["points"] if e else None)
        return {"name": p["name"], "total": p["points"], "per_race": per, "place": place[i]}

    teams = []
    for idx, tag in enumerate(order):
        members = [view(i) for i, p in enumerate(players) if p.get("team") == tag]
        if not members and team_total[tag] <= 0:
            continue
        members.sort(key=lambda m: (-m["total"], m["name"]))
        teams.append({"tag": tag, "color_index": idx, "total": team_total[tag],
                      "players": members})
    teams.sort(key=lambda t: (-t["total"], t["color_index"]))
    others = sorted((view(i) for i, p in enumerate(players) if not p.get("team")),
                    key=lambda m: (-m["total"], m["name"]))
    return {"teams": teams, "others": others, "race_count": len(seqs),
            "races_total": len(races)}


# ── 描画 ──────────────────────────────────────
def _gradient(draw, box, top, bottom):
    x0, y0, x1, y1 = box
    h = max(1, y1 - y0)
    for i in range(h):
        t = i / h
        color = tuple(int(top[k] + (bottom[k] - top[k]) * t) for k in range(3))
        draw.line([(x0, y0 + i), (x1, y0 + i)], fill=color)


def render_board(board, title="MK7 Mogi", subtitle=""):
    """データから画像 (PIL.Image, RGB) を作る。"""
    n = board["race_count"]
    table_w = NAME_W + n * COL_W + TOTAL_W + PLACE_W
    x_name = LEFT_W + NAME_W / 2
    x_race0 = LEFT_W + NAME_W
    x_total = x_race0 + n * COL_W
    x_place = x_total + TOTAL_W
    right_x0 = LEFT_W + table_w + 20
    right_cx = (right_x0 + W) / 2

    groups = [(t, PALETTE[t["color_index"] % len(PALETTE)]) for t in board["teams"]]
    if board["others"]:
        groups.append(({"tag": "?", "total": None, "players": board["others"]}, OTHER_COLORS))

    # 帯の位置を決める
    bands, y = [], HEADER_H + STRIP_H
    for team, colors in groups:
        k = len(team["players"])
        stack = k * (ROW_H + ROW_GAP) - ROW_GAP if k else 0
        h = PAD_TOP + max(stack, MIN_STACK_H) + PAD_BOTTOM
        bands.append((team, colors, y, y + h))
        y += h
    height = max(y, HEADER_H + STRIP_H + 120)

    base = Image.new("RGBA", (W, height), (0, 0, 0, 255))
    d = ImageDraw.Draw(base)
    for _, colors, y0, y1 in bands:
        _gradient(d, (0, y0, W, y1), *colors)
    d.rectangle([0, 0, W, HEADER_H], fill=(0, 0, 0))
    d.rectangle([0, HEADER_H, W, HEADER_H + STRIP_H], fill=(18, 18, 26))

    # 半透明の行・セル
    overlay = Image.new("RGBA", base.size, (0, 0, 0, 0))
    od = ImageDraw.Draw(overlay)
    rows = []                                   # (player, y_center, team_has_team)
    for team, _, y0, y1 in bands:
        for i, pl in enumerate(team["players"]):
            top = y0 + PAD_TOP + i * (ROW_H + ROW_GAP)
            od.rounded_rectangle([LEFT_W + 4, top, LEFT_W + table_w - 4, top + ROW_H],
                                 radius=10, fill=(0, 0, 0, 70))
            od.rounded_rectangle([x_total + 4, top + 3, x_total + TOTAL_W - 4, top + ROW_H - 3],
                                 radius=8, fill=(255, 255, 255, 70))
            rows.append((pl, top + ROW_H / 2))
    base = Image.alpha_composite(base, overlay)
    d = ImageDraw.Draw(base)

    # ヘッダー
    _draw_text(d, (W / 2, HEADER_H / 2), title + (f"   •   {subtitle}" if subtitle else ""),
               fit_font(d, title + subtitle, W - 200, 40), stroke=0)
    cy = HEADER_H + STRIP_H / 2
    small = get_font(18)
    grey = (170, 170, 185)
    _draw_text(d, (x_name, cy), "PLAYER", small, grey)
    for i in range(n):
        _draw_text(d, (x_race0 + COL_W * i + COL_W / 2, cy), str(i + 1), small, grey)
    _draw_text(d, (x_total + TOTAL_W / 2, cy), "TOTAL", small, grey)
    _draw_text(d, (x_place + PLACE_W / 2, cy), "RANK", small, grey)
    if board["races_total"] > n:
        _draw_text(d, (LEFT_W - 20, cy), f"last {n} of {board['races_total']} races",
                   get_font(16), grey, align="r")

    # チームごとの内容
    for bi, (team, _, y0, y1) in enumerate(bands):
        mid = (y0 + y1 - PAD_BOTTOM + PAD_TOP) / 2
        _draw_text(d, (LEFT_W / 2, mid), team["tag"],
                   fit_font(d, team["tag"], LEFT_W - 50, 120, 30),
                   (255, 255, 255), stroke=4)
        if team["total"] is not None:
            _draw_text(d, (right_cx, mid), str(team["total"]),
                       fit_font(d, str(team["total"]), W - right_x0 - 30, 120, 40),
                       (255, 255, 255), stroke=4)
        if bi + 1 < len(bands) and team["total"] is not None and bands[bi + 1][0]["total"] is not None:
            gap = team["total"] - bands[bi + 1][0]["total"]
            _draw_text(d, (right_cx, y1 - PAD_BOTTOM / 2), f"±{gap}", get_font(30),
                       (255, 255, 255), stroke=2)

    # プレイヤーの行
    f_cell, f_total = get_font(24), get_font(30)
    for pl, cy in rows:
        _draw_text(d, (x_name, cy), pl["name"] or "?", fit_font(d, pl["name"] or "?", NAME_W - 24, 30, 14),
                   (255, 255, 255), stroke=2)
        for i, pts in enumerate(pl["per_race"]):
            x = x_race0 + COL_W * i + COL_W / 2
            if pts is None:
                _draw_text(d, (x, cy), "-", f_cell, (200, 200, 210))
            else:
                _draw_text(d, (x, cy), str(pts), f_cell, (255, 255, 255), stroke=1)
        _draw_text(d, (x_total + TOTAL_W / 2, cy), str(pl["total"]), f_total,
                   (255, 255, 255), stroke=2)
        px = x_place + PLACE_W / 2
        if pl["place"] in MEDALS:
            r = 21
            d.ellipse([px - r, cy - r, px + r, cy + r], fill=MEDALS[pl["place"]],
                      outline=(40, 40, 40), width=3)
            _draw_text(d, (px, cy), str(pl["place"]), get_font(24), (30, 30, 30))
        else:
            _draw_text(d, (px, cy), ordinal(pl["place"]), get_font(24), (255, 255, 255), stroke=2)

    if not bands:
        _draw_text(d, (W / 2, HEADER_H + STRIP_H + 60), "No data yet", get_font(36), grey)
    return base.convert("RGB")


# ── 保存 ──────────────────────────────────────
def save_png_atomic(img, path):
    """OBS が書きかけを読まないよう、一時ファイル経由で差し替える。"""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    img.save(tmp, format="PNG")
    os.replace(tmp, path)


def write_leaderboard(races, report, paths, title="MK7 Mogi", subtitle=""):
    """画像を作って、すべての保存先に書く。作った画像を返す。"""
    img = render_board(build_board(races, report), title, subtitle)
    for p in paths:
        save_png_atomic(img, p)
    return img
