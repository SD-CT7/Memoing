#!/usr/bin/env python3
"""
name_lists.py -- 「よくあるOCRミスのリスト」と「表示名の辞書」
==============================================================
2つのリストは、利用者が画面 (LISTS ボタン) で編集し、テキストファイルに保存される。

1) OCRミスのリスト  (ocr_fixes.txt)   ※ 名簿との照合にだけ使う
     4 -> A        OCR が「4」と読んだら、本当は「A」 (一方向)
     0 <-> O       どちら向きにも間違える (= 0 -> O と O -> 0 の両方)
     rn -> m       2文字以上でもよい
   名簿のどのプレイヤーとも一致しなかった行にだけ、このリストで文字を置き換えて照合し直す。
   一致したら、そのプレイヤーの集計に入れる (race_log.compute_player_totals)。

2) 表示名の辞書  (name_dictionary.txt)  ※ lorenzi 風の画像出力にだけ使う
   見出し (左側) は PLAYERS の名前と「一字一句同じ」でなければ使われない。似た名前を選ぶ補正はしない
   (OCR の読み間違いは、PLAYERS の名前に直す段階 = OCR ミスのリストで直す。辞書はその後の名前を引くだけ)。
     Ayaneko = あやねこ         試合中に使っている名前 = 画像に載せる名前
     Ayaneko = Lemon [jp]       名前の後ろの [国コード] は国旗になる (lorenzi の入力欄と同じ書き方)
     Ayaneko = [jp]             名前はそのままで国旗だけ付ける
   集計・照合・名簿画面の表示には使わない (leaderboard_adapter.build_model だけが使う)。

書式: 1行に1件。空行と、行頭が # の行は無視する。解釈できない行は無視して、理由を返す。
2つのファイルはテキストエディタで直してよい (UTF-8 / UTF-8 BOM付き / Shift-JIS (ANSI) / UTF-16 を読める)。
画面から保存したときは UTF-8 (BOM付き) で書く。
tkinter には依存しない。
"""

import os
import re
import sys
from pathlib import Path


MAX_DEPTH = 2          # 1つの行に当てはめる置き換えの最大回数
MAX_VARIANTS = 400     # 置き換え後の候補の上限 (リストが多くても重くならないように)
FIX_FILE = "ocr_fixes.txt"
DICT_FILE = "name_dictionary.txt"

_TWO_WAY = ("<->", "↔", "⇔")
_ONE_WAY = ("->", "→", "=>", "⇒")

HELP_FIXES = """# OCRがよく間違える文字のリスト (行頭が # の行は無視されます)
# 名簿のどの人ともマッチしなかった行にだけ当てはめ、マッチしたら集計に反映します。
#   4 -> A        OCRが「4」と読んだら、本当は「A」
#   0 <-> O       どちら向きにも間違える
#   rn -> m       2文字以上でもOK
"""

HELP_DICT = """# PLAYERS の名前 = lorenzi の画像に載せる名前 (行頭が # の行は無視されます)
# 左側は PLAYERS の名前と一字一句同じに書いてください (似た名前は使われません)。
# 画像出力だけに使います。集計や名簿の照合には使いません。
#   Ayaneko = あやねこ
#   B◇SD = SD
# 名前の後ろに [国コード] を付けると、lorenzi で国旗が出ます (jp, us, gb-eng など)。
#   Dahlia = Lemon [jp]       名前を Lemon にして、日本の国旗を付ける
#   ATM = [us]                名前はそのままで、国旗だけ付ける
"""


# ══════════════════════════════════════════════
#  OCRミスのリスト
# ══════════════════════════════════════════════
def parse_confusions(text):
    """(rules, errors) を返す。rules = [(置き換え前, 置き換え後)] (両方向の指定は2件に展開)。
    errors = [(行番号, 行の内容, 理由)]。"""
    rules, errors, seen = [], [], set()

    def add(a, b):
        if (a, b) not in seen:
            seen.add((a, b))
            rules.append((a, b))

    for no, raw in enumerate(text.splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        two_way = False
        left = right = None
        for tok in _TWO_WAY:
            if tok in line:
                left, right = line.split(tok, 1)
                two_way = True
                break
        if left is None:
            for tok in _ONE_WAY:
                if tok in line:
                    left, right = line.split(tok, 1)
                    break
        if left is None and "=" in line:
            left, right = line.split("=", 1)
            two_way = True
        if left is None:
            errors.append((no, raw, "区切りがありません (-> か <-> か = を使ってください)"))
            continue
        left, right = left.strip(), right.strip()
        if not left or not right:
            errors.append((no, raw, "左右どちらかが空です"))
            continue
        if left == right:
            errors.append((no, raw, "左右が同じです"))
            continue
        add(left, right)
        if two_way:
            add(right, left)
    return rules, errors


def expand_variants(text, rules, max_depth=MAX_DEPTH, limit=MAX_VARIANTS):
    """text に rules の置き換えを最大 max_depth 回まで当てはめた候補を返す (元の文字列は含まない)。"""
    if not rules or not text:
        return []
    seen, frontier, out = {text}, [text], []
    for _ in range(max_depth):
        nxt = []
        for v in frontier:
            for src, dst in rules:
                start = 0
                while True:
                    i = v.find(src, start)
                    if i < 0:
                        break
                    nv = v[:i] + dst + v[i + len(src):]
                    if nv not in seen:
                        seen.add(nv)
                        out.append(nv)
                        nxt.append(nv)
                        if len(out) >= limit:
                            return out
                    start = i + 1
        frontier = nxt
    return out


# ══════════════════════════════════════════════
#  表示名の辞書
# ══════════════════════════════════════════════
def parse_dictionary(text):
    """(辞書 {試合中の名前: 表示名}, errors) を返す。同じ名前が複数あれば後の行が勝つ。"""
    mapping, errors = {}, []
    for no, raw in enumerate(text.splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if any(tok in line for tok in _TWO_WAY):
            errors.append((no, raw, "辞書は片方向です (試合中の名前 = 表示名 の形で書いてください)"))
            continue
        left = right = None
        for tok in ("=>", "->", "→", "⇒", "="):
            if tok in line:
                left, right = line.split(tok, 1)
                break
        if left is None:
            errors.append((no, raw, "区切りがありません (= を使ってください)"))
            continue
        left, right = left.strip(), right.strip()
        if not left or not right:
            errors.append((no, raw, "左右どちらかが空です"))
            continue
        mapping[left] = right
    return mapping, errors


_FLAG_RE = re.compile(r"\s*(?:\[|［|「|【)(.*?)(?:\]|］|」|】)$")     # lorenzi の parse と同じ括弧


def split_flag(display):
    """表示名の末尾の [国コード] を取り出す。 "Lemon [jp]" → ("Lemon", "jp")。
    国コードが無ければ (表示名, None)。 "[jp]" だけなら ("", "jp") (名前は呼び出し側で補う)。"""
    text = display.strip()
    m = _FLAG_RE.search(text)
    if not m:
        return text, None
    code = m.group(1).strip()
    return text[:m.start()].strip(), (code or None)


def display_name(name, mapping):
    """辞書に完全一致する見出しがあれば、その表示名を返す。無ければ元の名前のまま。
    記号・大文字小文字・全角半角の違いは見ない (似た名前を選ぶ補正はしない)。"""
    if not mapping:
        return name
    return mapping.get(name, name)


def unlisted_names(names, mapping):
    """names (PLAYERS の名前) のうち、辞書に完全一致する見出しが無いもの (元の順、重複なし)。"""
    out = []
    for n in names:
        if n not in mapping and n not in out:
            out.append(n)
    return out


# ══════════════════════════════════════════════
#  保存と読み込み
# ══════════════════════════════════════════════
class NameLists:
    """2つのリストの本文と、解釈した結果。"""

    def __init__(self, fix_text="", dict_text=""):
        self.fix_text, self.dict_text = fix_text, dict_text
        self.rules, self.fix_errors = parse_confusions(fix_text)
        self.names, self.dict_errors = parse_dictionary(dict_text)

    @property
    def errors(self):
        return ([("OCRミス", *e) for e in self.fix_errors]
                + [("辞書", *e) for e in self.dict_errors])


def settings_dir():
    env = os.environ.get("MK7_SETTINGS_DIR", "").strip()
    if env:
        return Path(env)
    base = Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
    return base / "settings"


def decode_text(raw):
    """テキストエディタで保存されたファイルの文字コードを見分けて、文字列にする。
    UTF-16 (BOM付き) / UTF-8 (BOM の有無は問わない) / Shift-JIS (ANSI) の順に試す。"""
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        return raw.decode("utf-16")
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        pass
    try:
        return raw.decode("cp932")
    except UnicodeDecodeError:
        return raw.decode("utf-8", errors="replace")


def _read(path):
    try:
        return decode_text(Path(path).read_bytes())
    except OSError:
        return ""


def load_lists(directory=None):
    d = Path(directory) if directory else settings_dir()
    return NameLists(_read(d / FIX_FILE), _read(d / DICT_FILE))


def save_lists(fix_text, dict_text, directory=None):
    """2つのファイルを書き (途中で止まっても壊れないよう一時ファイル経由)、解釈した結果を返す。"""
    d = Path(directory) if directory else settings_dir()
    d.mkdir(parents=True, exist_ok=True)
    for name, text in ((FIX_FILE, fix_text), (DICT_FILE, dict_text)):
        path = d / name
        tmp = path.with_name(name + ".tmp")
        with open(tmp, "w", encoding="utf-8-sig", newline="") as f:      # メモ帳でも文字化けしない
            f.write(text)
        os.replace(tmp, path)
    return NameLists(fix_text, dict_text)
