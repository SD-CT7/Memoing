#!/usr/bin/env python3
"""leaderboard_adapter.py のテスト (実行: python test_leaderboard_adapter.py)  ※ APIは使いません"""
import unittest

import leaderboard_render as lr
import json
from pathlib import Path

from leaderboard_adapter import (NO_TEAM, RACES_PER_COLUMN, ZWSP, ExportError, _safe_player,
                                 _safe_tag, build_model, to_lorenzi_text)
from race_log import DEFAULT_POINTS

NAMES = ["B◇SD", "Cじゃなくてd", "DCだけはこめん", "Ayaneko",
         "D☆Dekasugi", "B◆よめない", "C◆うお", "D◇どわー"]
TAGS = ["A", "B", "C", "D"]
TAG_OF = {"B◇SD": "B", "Cじゃなくてd": "C", "DCだけはこめん": "D", "Ayaneko": "A",
          "D☆Dekasugi": "D", "B◆よめない": "B", "C◆うお": "C", "D◇どわー": "D"}


def race(seq, order, tag_of=TAG_OF):
    rows = []
    for i, name in enumerate(order):
        tag = tag_of.get(name)
        rows.append({"rank": i + 1, "text": name, "tag": tag, "points": DEFAULT_POINTS[i] if tag else None})
    return {"seq": seq, "status": "added", "tags": TAGS, "rows": rows}


class TestBuildModel(unittest.TestCase):
    def test_empty_roster_and_no_races_give_clear_messages(self):
        with self.assertRaises(ExportError) as cm:
            build_model([race(1, NAMES)], [])
        self.assertIn("名簿", str(cm.exception))
        with self.assertRaises(ExportError) as cm:
            build_model([], NAMES)
        self.assertIn("レース", str(cm.exception))
        with self.assertRaises(ExportError):
            build_model([race(1, NAMES)], ["", None])

    def test_teams_players_and_scores(self):
        races = [race(1, NAMES), race(2, NAMES[::-1]), race(3, NAMES)]
        m = build_model(races, NAMES, title="Mock 1", date="2026-11-05")
        self.assertEqual(m["title"], "Mock 1")
        self.assertEqual({t["tag"] for t in m["teams"]}, set(TAGS))
        by_tag = {t["tag"]: t for t in m["teams"]}
        self.assertEqual(sorted(p["name"] for p in by_tag["D"]["players"]),
                         sorted(["DCだけはこめん", "D☆Dekasugi", "D◇どわー"]))
        p = next(p for t in m["teams"] for p in t["players"] if p["name"] == "B◇SD")
        self.assertEqual(p["scores"], [21])                        # 3レースの和 (4レース未満なので1列)
        self.assertTrue(all(len(p["scores"]) == 1 for t in m["teams"] for p in t["players"]))
        self.assertIsNone(p["flag"])                               # 国コードの情報が無ければ空

    def test_flags_names_colors_and_bonus_are_passed_through(self):
        m = build_model([race(1, NAMES)], NAMES, flags={"B◇SD": "jp"},
                        team_names={"B": "Team B"}, team_colors={"B": "#112233"},
                        team_bonus={"B": -10}, player_bonus={"B◇SD": 5})
        b = next(t for t in m["teams"] if t["tag"] == "B")
        self.assertEqual((b["name"], b["color"], b["bonus"]), ("Team B", "#112233", -10))
        p = next(p for p in b["players"] if p["name"] == "B◇SD")
        self.assertEqual((p["flag"], p["bonus"]), ("jp", 5))

    def test_player_without_a_team_goes_to_no_team(self):
        tag_of = dict(TAG_OF, Ayaneko=None)
        m = build_model([race(1, NAMES, tag_of)], NAMES)
        nt = next(t for t in m["teams"] if t["tag"] == NO_TEAM)
        self.assertEqual([p["name"] for p in nt["players"]], ["Ayaneko"])

    def test_player_absent_from_a_race_gets_zero(self):
        r2 = race(2, [n for n in NAMES if n != "Ayaneko"])
        m = build_model([race(1, NAMES), r2], NAMES)
        a = next(p for t in m["teams"] for p in t["players"] if p["name"] == "Ayaneko")
        self.assertEqual(a["scores"], [5])                         # 出ていないレースは 0 として足す

    def test_totals_equal_sum_of_race_points_and_render(self):
        races = [race(1, NAMES), race(2, NAMES[::-1])]
        m = build_model(races, NAMES)
        ex = lr.expand(m)
        total = sum(t["finalScore"] for t in ex["teams"])
        self.assertEqual(total, 2 * sum(DEFAULT_POINTS))
        img = lr.render_table(m, "dark", 1)                        # そのまま描画できる
        self.assertGreater(img.size[0], 500)

    def test_single_race_has_single_score_column(self):
        m = build_model([race(1, NAMES)], NAMES)
        self.assertTrue(all(len(p["scores"]) == 1 for t in m["teams"] for p in t["players"]))
        lr.render_table(m, "light", 1)



class TestListsInTheAdapter(unittest.TestCase):
    def test_display_dictionary_changes_only_the_names_on_the_image(self):
        races = [race(1, NAMES), race(2, NAMES[::-1])]
        plain = build_model(races, NAMES)
        m = build_model(races, NAMES, name_dict={"B◇SD": "SD", "Ayaneko": "あやねこ"},
                        flags={"B◇SD": "jp"}, player_bonus={"B◇SD": 5})
        names = {p["name"] for t in m["teams"] for p in t["players"]}
        self.assertIn("SD", names)
        self.assertIn("あやねこ", names)
        self.assertNotIn("B◇SD", names)
        sd = next(p for t in m["teams"] for p in t["players"] if p["name"] == "SD")
        self.assertEqual((sd["flag"], sd["bonus"]), ("jp", 5))          # 国旗・ボーナスは試合中の名前で対応づく
        orig = next(p for t in plain["teams"] for p in t["players"] if p["name"] == "B◇SD")
        self.assertEqual(sd["scores"], orig["scores"])                   # 点数は変わらない
        self.assertEqual(sorted(p["name"] for t in plain["teams"] for p in t["players"]), sorted(NAMES))

    def test_dictionary_needs_the_exact_players_name(self):
        for similar in ("b sd", "B SD", "BSD", "B◆SD", "ｂ◇ｓｄ", "b◇sd"):
            m = build_model([race(1, NAMES)], NAMES, name_dict={similar: "SD"})
            shown = {p["name"] for t in m["teams"] for p in t["players"]}
            self.assertNotIn("SD", shown, similar)                     # 似た見出しは使われない
            self.assertIn("B◇SD", shown, similar)
        m = build_model([race(1, NAMES)], NAMES, name_dict={"B◇SD": "SD"})
        self.assertIn("SD", {p["name"] for t in m["teams"] for p in t["players"]})

    def test_the_leaderboard_only_shows_players_names(self):
        """100件近い辞書でも、画像・テキストに出る名前は PLAYERS の名前 (またはその表示名) だけ。"""
        big = {f"他の選手{i:03d}": f"別名{i:03d}" for i in range(100)}
        big.update({"Ayaneko": "あやねこ", "B◇SD": "SD"})
        m = build_model([race(1, NAMES), race(2, NAMES[::-1])], NAMES, name_dict=big)
        shown = sorted(p["name"] for t in m["teams"] for p in t["players"])
        expected = sorted({"Ayaneko": "あやねこ", "B◇SD": "SD"}.get(n, n) for n in NAMES)
        self.assertEqual(shown, expected)                              # 辞書だけにある名前は載らない
        text = to_lorenzi_text(m)
        self.assertNotIn("他の選手", text)
        self.assertNotIn("別名", text)

    def test_ocr_rules_make_the_image_match_the_players_screen(self):
        roster = ["Ai" if n == "Ayaneko" else n for n in NAMES]
        tag_of = dict(TAG_OF, **{"4i": "A", "Ai": "A"})
        r = race(1, [("4i" if n == "Ai" else n) for n in roster], tag_of)   # Ai が "4i" と読まれた
        without = build_model([r], roster)
        with_rules = build_model([r], roster, ocr_rules=[("4", "A")])
        total = lambda m: sum(sum(p["scores"]) for t in m["teams"] for p in t["players"])
        self.assertEqual(total(with_rules) - total(without), DEFAULT_POINTS[3])     # 4位ぶんが加わる



def _plain_races(n):
    """順位が毎回入れ替わる n レース (名前, 順位) と、その各レースのポイント表。"""
    out = []
    for seq in range(1, n + 1):
        order = NAMES[seq % 8:] + NAMES[:seq % 8]
        out.append(race(seq, order))
    return out


class TestFourRaceColumns(unittest.TestCase):
    """lorenzi の得点列は 4レースごとの和 (12レースなら 4|4|4 の3列)。余りは最後の列。"""

    def _per_race(self, races, name):
        pts = {}
        for r in races:
            for row in r["rows"]:
                pts.setdefault(row["text"], []).append(row["points"])
        return pts[name]

    def test_constant_is_four(self):
        self.assertEqual(RACES_PER_COLUMN, 4)

    def test_twelve_races_make_three_columns(self):
        races = _plain_races(12)
        m = build_model(races, NAMES)
        for t in m["teams"]:
            for p in t["players"]:
                per = self._per_race(races, p["name"])
                self.assertEqual(p["scores"], [sum(per[0:4]), sum(per[4:8]), sum(per[8:12])], p["name"])

    def test_remainder_goes_into_the_last_column(self):
        for n, sizes in ((5, [4, 1]), (6, [4, 2]), (7, [4, 3]), (9, [4, 4, 1]), (4, [4]), (3, [3]), (1, [1]), (8, [4, 4])):
            races = _plain_races(n)
            m = build_model(races, NAMES)
            for t in m["teams"]:
                for p in t["players"]:
                    per = self._per_race(races, p["name"])
                    cuts, start, expect = sizes, 0, []
                    for size in cuts:
                        expect.append(sum(per[start:start + size]))
                        start += size
                    self.assertEqual(p["scores"], expect, f"{n} races / {p['name']}")

    def test_five_races_are_four_plus_one(self):
        races = [race(i, NAMES) for i in range(1, 6)]               # 毎回同じ順位
        m = build_model(races, NAMES)
        top = next(p for t in m["teams"] for p in t["players"] if p["name"] == "B◇SD")   # 毎回1位 (10点)
        self.assertEqual(top["scores"], [40, 10])

    def test_columns_add_up_to_the_totals(self):
        races = _plain_races(12)
        m = build_model(races, NAMES)
        total = sum(sum(p["scores"]) for t in m["teams"] for p in t["players"])
        self.assertEqual(total, 12 * sum(DEFAULT_POINTS))
        ex = lr.expand(m)
        self.assertEqual(sum(t["finalScore"] for t in ex["teams"]), total)

    def test_races_per_column_can_be_changed(self):
        races = _plain_races(5)
        cols = lambda n: {len(p["scores"]) for t in build_model(races, NAMES, races_per_column=n)["teams"]
                          for p in t["players"]}
        self.assertEqual(cols(1), {5})            # 1 にすると従来どおりレースごと
        self.assertEqual(cols(2), {3})            # 2+2+1
        self.assertEqual(cols(99), {1})
        self.assertEqual(cols(0), {5})            # 0 以下は 1 として扱う

    def test_image_has_a_total_column_only_when_there_are_several_columns(self):
        one = lr.compute_layout(lr.expand(build_model(_plain_races(4), NAMES)), lr.STYLES["dark"], False)
        three = lr.compute_layout(lr.expand(build_model(_plain_races(12), NAMES)), lr.STYLES["dark"], False)
        self.assertEqual(one["max_sc"], 1)
        self.assertEqual(three["max_sc"], 3)


LZ = json.loads((Path(__file__).resolve().parent / "tests_data" / "lorenzi_text_cases.json").read_text("utf-8"))["cases"]


def _z(s):
    return (s or "").replace(ZWSP, "")


class TestLorenziText(unittest.TestCase):
    def test_format_of_a_simple_model(self):
        m = {"title": "Mock 1", "teams": [
            {"tag": "A", "name": "Alpha", "color": "#3a86ff", "bonus": -10, "players": [
                {"name": "Ren", "flag": "jp", "scores": [4, 5, 6], "bonus": 5},
                {"name": "Sam", "flag": None, "scores": [1, 2, 3], "bonus": 0}]},
            {"tag": "B", "name": None, "color": None, "bonus": 0, "players": [
                {"name": "Lee", "flag": None, "scores": [7], "bonus": -2}]}]}
        self.assertEqual(to_lorenzi_text(m), "#title Mock 1\nA - Alpha #3a86ff (-10)\nRen [jp] 4|5|6 (+5)\n"
                                              "Sam 1|2|3\n\nB\nLee 7 (-2)\n")

    def test_hide_options_and_no_title(self):
        m = {"teams": [{"tag": "A", "players": [{"name": "x", "scores": [1]}]}],
             "hide_team_names": True, "hide_player_scores": True}
        self.assertEqual(to_lorenzi_text(m), "#hide teamNames,playerScores\nA\nx 1\n")

    def test_normal_names_get_no_invisible_characters(self):
        text = to_lorenzi_text(build_model(_plain_races(3), NAMES))
        self.assertNotIn(ZWSP, text)

    def test_unsafe_names_and_tags_are_protected(self):
        self.assertEqual(_safe_player("#fan"), ZWSP + "#fan")          # 行頭 # は行ごと無視されるため
        self.assertEqual(_safe_player("Ren[2]"), "Ren[2]" + ZWSP)      # 末尾の [..] は国コードに見える
        self.assertEqual(_safe_player("a|b"), "a¦b")                   # | は得点の区切り
        self.assertEqual(_safe_player("Taro 12"), "Taro 12")           # 空白+数字は名前の中なら問題ない
        self.assertEqual(_safe_tag("Team 1"), "Team 1" + ZWSP)         # 選手の行と間違われる
        self.assertEqual(_safe_tag("A (5)"), "A (5)" + ZWSP)           # ボーナスに見える
        self.assertEqual(_safe_tag("X - Y"), "X Y")                    # チーム名の区切り
        self.assertEqual(_safe_tag("#T"), ZWSP + "#T")

    def test_text_is_read_by_the_real_lorenzi_parser_as_the_same_table(self):
        """to_lorenzi_text の出力を、参考実装 (leaderboard-table-maker.html) の parse() に通した結果
        (tests_data に保存してある) が、描画に使う model と一致すること。"""
        self.assertGreaterEqual(len(LZ), 10)
        for name, case in LZ.items():
            model, js = case["model"], case["js"]
            self.assertEqual(to_lorenzi_text(model), case["text"], name)          # 文面そのもの
            ex = lr.expand(model)
            self.assertEqual(len(ex["teams"]), len(js["teams"]), name)
            for t, jt in zip(ex["teams"], js["teams"]):
                self.assertEqual((_z(_safe_tag(t["tag"])), t["bonus"], t["finalScore"], t["ranking"]),
                                 (_z(jt["tag"]), jt["bonus"], jt["finalScore"], jt["ranking"]), name)
                self.assertEqual(len(t["players"]), len(jt["players"]), name)
                for p, jp in zip(t["players"], jt["players"]):
                    self.assertEqual((_z(_safe_player(p["name"])), p["flag"], p["scores"], p["bonus"], p["ranking"]),
                                     (_z(jp["name"]), jp["flag"], jp["scores"], jp["bonus"], jp["ranking"]), name)

    def test_twelve_race_text_has_three_columns_per_player(self):
        text = LZ["standard_12_races"]["text"]
        player_lines = [l for l in text.splitlines() if "|" in l]
        self.assertEqual(len(player_lines), 8)
        self.assertTrue(all(l.rsplit(" ", 1)[1].count("|") == 2 for l in player_lines))
        five = [l for l in LZ["standard_5_races"]["text"].splitlines() if "|" in l]
        self.assertTrue(all(l.rsplit(" ", 1)[1].count("|") == 1 for l in five))       # 4|1 の2列



class TestDictionaryFlags(unittest.TestCase):
    """表示名の辞書の値の末尾に [国コード] を書くと、lorenzi で国旗が出る"""

    def _players(self, **kw):
        m = build_model([race(1, NAMES), race(2, NAMES[::-1])], NAMES, **kw)
        return m, {p["name"]: p for t in m["teams"] for p in t["players"]}

    def test_flag_in_the_dictionary_value_becomes_the_flag(self):
        m, players = self._players(name_dict={"Ayaneko": "Lemon [jp]"})
        self.assertEqual((players["Lemon"]["flag"], "Ayaneko" in players), ("jp", False))
        self.assertTrue(all("[" not in n for n in players))             # 国コードは名前に残らない

    def test_flag_only_keeps_the_in_game_name(self):
        m, players = self._players(name_dict={"B◇SD": "[us]"})
        self.assertEqual(players["B◇SD"]["flag"], "us")

    def test_dictionary_flag_wins_over_the_flags_argument(self):
        m, players = self._players(name_dict={"B◇SD": "SD [us]"}, flags={"B◇SD": "jp", "Ayaneko": "fr"})
        self.assertEqual(players["SD"]["flag"], "us")                   # 辞書が優先
        self.assertEqual(players["Ayaneko"]["flag"], "fr")              # 辞書に無い人は flags 引数のまま

    def test_names_not_in_the_dictionary_are_never_split(self):
        names = ["Ren[2]", "Sam"]
        rows = [{"rank": i + 1, "text": n, "tag": "A", "points": DEFAULT_POINTS[i]} for i, n in enumerate(names)]
        m = build_model([{"seq": 1, "status": "added", "tags": ["A"], "rows": rows}], names,
                        name_dict={"Sam": "サム [jp]"})
        players = {p["name"]: p["flag"] for t in m["teams"] for p in t["players"]}
        self.assertEqual(players, {"Ren[2]": None, "サム": "jp"})          # Ren[2] は名前のまま (国旗にしない)
        self.assertIn("Ren[2]" + ZWSP + " ", to_lorenzi_text(m))           # テキストでは国旗と読まれないよう保護

    def test_text_has_the_flag_in_lorenzi_syntax_without_invisible_characters(self):
        m, _ = self._players(name_dict={"Ayaneko": "Lemon [jp]", "B◇SD": "[us]"})
        lines = to_lorenzi_text(m).splitlines()
        self.assertTrue(any(l.startswith("Lemon [jp] ") for l in lines))
        self.assertTrue(any(l.startswith("B◇SD [us] ") for l in lines))
        self.assertNotIn(ZWSP, "\n".join(lines))

    def test_flag_column_appears_when_only_the_dictionary_has_flags(self):
        plain, _ = self._players()
        flagged, _ = self._players(name_dict={"Ayaneko": "Lemon [jp]"})
        w = lambda m: lr.compute_layout(lr.expand(m), lr.STYLES["dark"], True)["W"]
        self.assertEqual(w(flagged) - w(plain), 54)
        img = lr.render_table(flagged, "dark", 1)
        self.assertGreater(img.size[0], lr.render_table(plain, "dark", 1).size[0])

    def test_dictionary_does_not_change_scores(self):
        _, with_dict = self._players(name_dict={"Ayaneko": "Lemon [jp]"})
        _, plain = self._players()
        self.assertEqual(with_dict["Lemon"]["scores"], plain["Ayaneko"]["scores"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
