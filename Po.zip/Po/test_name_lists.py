#!/usr/bin/env python3
"""name_lists.py のテスト (実行: python test_name_lists.py)  ※ APIは使いません"""
import tempfile
import unittest
from pathlib import Path

from name_lists import (DICT_FILE, FIX_FILE, HELP_DICT, HELP_FIXES, NameLists, decode_text, display_name,
                        expand_variants, load_lists, parse_confusions, parse_dictionary,
                        save_lists, split_flag, unlisted_names)


class TestParseConfusions(unittest.TestCase):
    def test_one_way_and_two_way(self):
        rules, errors = parse_confusions("4 -> A\n0 <-> O\nl = I\n1 ↔ l\nB → 8\nS => 5\n")
        self.assertEqual(errors, [])
        self.assertEqual(rules, [("4", "A"),                       # -> は一方向
                                 ("0", "O"), ("O", "0"),            # <-> は両方向
                                 ("l", "I"), ("I", "l"),            # = も両方向
                                 ("1", "l"), ("l", "1"),            # ↔ も両方向
                                 ("B", "8"), ("S", "5")])           # → と => は一方向

    def test_comments_blank_lines_and_spaces(self):
        rules, errors = parse_confusions("# コメント\n\n   \n  rn   ->   m  \n#4 -> A\n")
        self.assertEqual(rules, [("rn", "m")])
        self.assertEqual(errors, [])

    def test_errors_are_reported_and_other_lines_survive(self):
        rules, errors = parse_confusions("4 -> A\nno separator here\n-> B\nC ->\nX -> X\n0 <-> O")
        self.assertEqual(rules, [("4", "A"), ("0", "O"), ("O", "0")])
        self.assertEqual([e[0] for e in errors], [2, 3, 4, 5])           # 行番号
        self.assertIn("区切り", errors[0][2])
        self.assertIn("空", errors[1][2])
        self.assertIn("同じ", errors[3][2])

    def test_duplicates_are_removed(self):
        rules, _ = parse_confusions("4 -> A\n4 -> A\nA <-> 4")
        self.assertEqual(rules, [("4", "A"), ("A", "4")])

    def test_japanese_rules(self):
        rules, errors = parse_confusions("ー -> 一\nカ <-> 力")
        self.assertEqual(errors, [])
        self.assertIn(("力", "カ"), rules)


class TestExpandVariants(unittest.TestCase):
    def test_single_substitution_at_each_position(self):
        v = expand_variants("4A4", [("4", "A")], max_depth=1)
        self.assertEqual(sorted(v), ["4AA", "AA4"])                       # 元の文字列は含まない

    def test_two_substitutions_by_default(self):
        self.assertIn("AA", expand_variants("44", [("4", "A")]))
        self.assertNotIn("AA", expand_variants("44", [("4", "A")], max_depth=1))

    def test_multi_char_and_no_rules(self):
        self.assertIn("Tom", expand_variants("Torn", [("rn", "m")]))
        self.assertEqual(expand_variants("abc", []), [])
        self.assertEqual(expand_variants("", [("a", "b")]), [])

    def test_variant_count_is_capped(self):
        rules = [(c, d) for c in "abcdefgh" for d in "ijklmnop"]
        v = expand_variants("abcdefgh" * 3, rules, limit=50)
        self.assertEqual(len(v), 50)


class TestDictionary(unittest.TestCase):
    def test_parse(self):
        m, errors = parse_dictionary("# c\nAyaneko = あやねこ\nB◇SD -> SD\nDahlia => ダリア\n\n")
        self.assertEqual(errors, [])
        self.assertEqual(m, {"Ayaneko": "あやねこ", "B◇SD": "SD", "Dahlia": "ダリア"})

    def test_errors_and_last_line_wins(self):
        m, errors = parse_dictionary("a = 1\nno sep\n = x\ny =\nq <-> r\na = 2")
        self.assertEqual(m, {"a": "2"})
        self.assertEqual([e[0] for e in errors], [2, 3, 4, 5])
        self.assertIn("片方向", errors[3][2])

    def test_display_name_lookup_is_exact(self):
        m = {"B◇SD": "SD", "Ayaneko": "あやねこ"}
        self.assertEqual(display_name("B◇SD", m), "SD")                   # 完全一致だけ引く
        self.assertEqual(display_name("Ayaneko", m), "あやねこ")
        self.assertEqual(display_name("Unknown", m), "Unknown")           # 無ければ元のまま
        self.assertEqual(display_name("x", {}), "x")
        self.assertEqual(display_name("x", None), "x")

    def test_similar_names_are_never_picked(self):
        """似た名前 (記号・大文字小文字・全角半角・空白の違い) では辞書を引かない。"""
        m = {"B◇SD": "SD", "Ayaneko": "あやねこ", "ATM": "えーてぃーえむ"}
        for similar in ("b sd", "B SD", "BSD", "B◆SD", "ｂ◇ｓｄ", "B◇SD ", " B◇SD", "AYANEKO", "ayaneko",
                        "Ａｙａｎｅｋｏ", "Ayanek0", "ATM2", "☆◇"):
            self.assertEqual(display_name(similar, m), similar, repr(similar))

    def test_unlisted_names(self):
        m = {"B◇SD": "SD", "Ayaneko": "あやねこ"}
        self.assertEqual(unlisted_names(["B◇SD", "Dahlia", "ATM", "Dahlia", "Ayaneko"], m), ["Dahlia", "ATM"])
        self.assertEqual(unlisted_names([], m), [])
        self.assertEqual(unlisted_names(["a", "b"], {}), ["a", "b"])
        self.assertEqual(unlisted_names(["b sd"], m), ["b sd"])           # 似た名前は載っているとは見なさない

    def test_large_dictionary_with_about_a_hundred_entries(self):
        lines = ["# 名簿 (100件)"] + [f"選手{i:03d}☆{chr(65 + i % 26)} = 表示{i:03d} [jp]" for i in range(100)]
        m, errors = parse_dictionary("\n".join(lines))
        self.assertEqual((len(m), errors), (100, []))
        self.assertEqual(display_name("選手042☆Q", m), "表示042 [jp]")
        self.assertEqual(display_name("選手042☆q", m), "選手042☆q")          # 大文字小文字違いは引かない
        self.assertEqual(len(unlisted_names([f"選手{i:03d}☆{chr(65 + i % 26)}" for i in range(0, 200, 2)], m)), 50)


class TestReadingEditedFiles(unittest.TestCase):
    """テキストエディタで直したファイルの文字コードを見分けて読む"""
    TEXT = "# 名簿\nAyaneko = あやねこ\nB◇SD = エスディー [jp]\r\nD☆Dekasugi = でかすぎ\n"

    def _roundtrip(self, raw):
        with tempfile.TemporaryDirectory() as d:
            (Path(d) / DICT_FILE).write_bytes(raw)
            return load_lists(d)

    def test_utf8_with_and_without_bom(self):
        for raw in (self.TEXT.encode("utf-8"), b"\xef\xbb\xbf" + self.TEXT.encode("utf-8")):
            lists = self._roundtrip(raw)
            self.assertEqual(lists.names["Ayaneko"], "あやねこ")
            self.assertEqual(lists.names["B◇SD"], "エスディー [jp]")
            self.assertEqual(lists.errors, [])

    def test_shift_jis_ansi_from_old_notepad(self):
        text = "Ayaneko = あやねこ\nカナ = かな\n"                         # ◇ などは Shift-JIS に無いので使わない
        lists = self._roundtrip(text.encode("cp932"))
        self.assertEqual(lists.names, {"Ayaneko": "あやねこ", "カナ": "かな"})

    def test_utf16_with_bom_from_notepad_unicode(self):
        lists = self._roundtrip(b"\xff\xfe" + self.TEXT.encode("utf-16-le"))
        self.assertEqual(lists.names["D☆Dekasugi"], "でかすぎ")
        lists = self._roundtrip(b"\xfe\xff" + self.TEXT.encode("utf-16-be"))
        self.assertEqual(lists.names["Ayaneko"], "あやねこ")

    def test_decode_text_never_raises(self):
        self.assertIsInstance(decode_text(b"\xff\xfd\x80abc"), str)
        self.assertEqual(decode_text(b""), "")

    def test_saving_from_the_window_normalises_to_utf8_bom(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d) / DICT_FILE).write_bytes("Ayaneko = あやねこ\n".encode("cp932"))
            lists = load_lists(d)
            save_lists(lists.fix_text, lists.dict_text, d)
            self.assertTrue((Path(d) / DICT_FILE).read_bytes().startswith(b"\xef\xbb\xbf"))
            self.assertEqual(load_lists(d).names, {"Ayaneko": "あやねこ"})

    def test_help_text_says_exact(self):
        self.assertIn("一字一句同じ", HELP_DICT)


class TestPersistence(unittest.TestCase):
    def test_roundtrip_with_japanese(self):
        with tempfile.TemporaryDirectory() as d:
            lists = save_lists("4 -> A\n0 <-> O\n", "B◇SD = エスディー\n", d)
            self.assertEqual(len(lists.rules), 3)
            self.assertEqual(lists.names, {"B◇SD": "エスディー"})
            again = load_lists(d)
            self.assertEqual((again.rules, again.names), (lists.rules, lists.names))
            self.assertEqual(again.fix_text, "4 -> A\n0 <-> O\n")
            raw = (Path(d) / DICT_FILE).read_bytes()
            self.assertTrue(raw.startswith(b"\xef\xbb\xbf"))              # メモ帳でも読める
            self.assertEqual(list(Path(d).glob("*.tmp")), [])

    def test_missing_files_give_empty_lists(self):
        with tempfile.TemporaryDirectory() as d:
            lists = load_lists(Path(d) / "nothing_here")
            self.assertEqual((lists.rules, lists.names, lists.errors), ([], {}, []))

    def test_save_creates_folder_and_overwrites(self):
        with tempfile.TemporaryDirectory() as d:
            target = Path(d) / "a" / "b"
            save_lists("1 -> l", "", target)
            save_lists("2 -> Z", "", target)
            self.assertEqual(load_lists(target).rules, [("2", "Z")])
            self.assertTrue((target / FIX_FILE).is_file())

    def test_errors_are_labelled(self):
        lists = NameLists("bad line", "also bad")
        self.assertEqual([(k, no) for k, no, _, _ in lists.errors], [("OCRミス", 1), ("辞書", 1)])

    def test_help_texts_are_only_comments(self):
        self.assertEqual(parse_confusions(HELP_FIXES), ([], []))
        self.assertEqual(parse_dictionary(HELP_DICT), ({}, []))



class TestSplitFlag(unittest.TestCase):
    def test_trailing_bracket_is_the_flag(self):
        self.assertEqual(split_flag("Lemon [jp]"), ("Lemon", "jp"))
        self.assertEqual(split_flag("Lemon[jp]"), ("Lemon", "jp"))
        self.assertEqual(split_flag("  Lemon   [jp]  "), ("Lemon", "jp"))
        self.assertEqual(split_flag("Lemon [gb-eng]"), ("Lemon", "gb-eng"))

    def test_other_bracket_styles_like_lorenzi(self):
        self.assertEqual(split_flag("Lemon［ＪＰ］"), ("Lemon", "ＪＰ"))
        self.assertEqual(split_flag("名前「us」"), ("名前", "us"))
        self.assertEqual(split_flag("名前【us】"), ("名前", "us"))

    def test_flag_only_gives_an_empty_name(self):
        self.assertEqual(split_flag("[jp]"), ("", "jp"))             # 名前は呼び出し側 (元の名前) で補う

    def test_no_flag(self):
        self.assertEqual(split_flag("Lemon"), ("Lemon", None))
        self.assertEqual(split_flag("[jp] Lemon"), ("[jp] Lemon", None))   # 末尾でなければ名前の一部
        self.assertEqual(split_flag("Lemon [ ]"), ("Lemon", None))          # 空の [] は国旗なし (括弧は取る)

    def test_dictionary_value_may_contain_a_flag(self):
        m, errors = parse_dictionary("Dahlia = Lemon [jp]\nATM = [us]")
        self.assertEqual(errors, [])
        self.assertEqual(m, {"Dahlia": "Lemon [jp]", "ATM": "[us]"})

    def test_help_text_mentions_flags(self):
        self.assertIn("[jp]", HELP_DICT)


if __name__ == "__main__":
    unittest.main(verbosity=2)
