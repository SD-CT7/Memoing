#!/usr/bin/env python3
"""
段階0: Google Cloud Vision API 精度検証スクリプト (score_app_v2.py とは独立)
=====================================================================
MK7の結果画面に対して TEXT_DETECTION / DOCUMENT_TEXT_DETECTION を比較します。

使い方 (Windows コマンドプロンプト):
    pip install pillow
    (.env に GOOGLE_VISION_API_KEY=... を書くか、次の行で設定)
    set GOOGLE_VISION_API_KEY=あなたのAPIキー
    python vision_test.py game_-_コピー.png

    # 消費ユニットだけ確認 (APIは呼ばない)
    python vision_test.py game_-_コピー.png --dry-run

注意:
  * 1 画像 x 1 機能 = 1 ユニット消費します (月1,000ユニット無料枠)。
    既定の組み合わせ = 2 倍率 x 2 機能 = 1 画像につき 4 ユニット。
  * APIキーはコードに書かず、環境変数で渡してください。
  * このキーは検証用です。配布アプリには絶対に入れません (Worker経由にします)。
  * 結果は vision_test_out フォルダに保存されます (report.txt / 生JSON)。
"""

import argparse
import base64
import io
import json
import os
import statistics
import sys
import urllib.error
import urllib.request
from datetime import datetime
from difflib import SequenceMatcher

from PIL import Image

try:
    from vision_ocr import load_env_file
except ImportError:
    load_env_file = None

try:   # 同じ月間カウンターに検証分も記録する (usage_guard.py が同じフォルダにある場合)
    from usage_guard import UsageGuard
except ImportError:
    UsageGuard = None

API_URL = "https://vision.googleapis.com/v1/images:annotate"
FEATURES = ["TEXT_DETECTION", "DOCUMENT_TEXT_DETECTION"]

# 正解データ (game_-_コピー.png の目視書き起こし)
GROUND_TRUTH = [
    "B◇SD",
    "Cじゃなくてd",
    "DCだけはこめん",
    "Ayaneko",
    "D☆Dekasugi",
    "B◆よめない",
    "C◆うお",
    "D◇どわー",
]
SYMBOLS = "◇◆☆"


# ── 画像バリアント ────────────────────────────
def make_variants(img, scales):
    """倍率ごとの画像を返す。{ラベル: PIL.Image}"""
    out = {}
    for s in scales:
        if s == 1:
            out["x1"] = img
        else:
            out[f"x{s}"] = img.resize((img.width * s, img.height * s), Image.LANCZOS)
    return out


def to_png_bytes(img):
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


# ── Vision API 呼び出し ───────────────────────
def call_vision(png, feature, api_key, hints):
    body = {
        "requests": [{
            "image": {"content": base64.b64encode(png).decode("ascii")},
            "features": [{"type": feature}],
        }]
    }
    if hints:
        body["requests"][0]["imageContext"] = {"languageHints": hints}
    req = urllib.request.Request(
        f"{API_URL}?key={api_key}",
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {e.code}: {detail}") from None


# ── 応答 -> 単語リスト ────────────────────────
def _box(vertices):
    xs = [v.get("x", 0) for v in vertices]
    ys = [v.get("y", 0) for v in vertices]
    return min(xs), min(ys), max(xs), max(ys)


def extract_words(resp, feature):
    """[(text, x0, y0, x1, y1, conf or None)] を返す"""
    r = resp.get("responses", [{}])[0]
    if "error" in r:
        raise RuntimeError(f"Vision error: {r['error']}")
    words = []
    if feature == "TEXT_DETECTION":
        anns = r.get("textAnnotations", [])
        for a in anns[1:]:   # [0] は全文
            x0, y0, x1, y1 = _box(a["boundingPoly"]["vertices"])
            words.append((a["description"], x0, y0, x1, y1, None))
    else:
        full = r.get("fullTextAnnotation", {})
        for page in full.get("pages", []):
            for block in page.get("blocks", []):
                for para in block.get("paragraphs", []):
                    for w in para.get("words", []):
                        text = "".join(s.get("text", "") for s in w.get("symbols", []))
                        x0, y0, x1, y1 = _box(w["boundingBox"]["vertices"])
                        words.append((text, x0, y0, x1, y1, w.get("confidence")))
    return words


def group_rows(words):
    """Y中心で行にまとめ、行内はX順に連結。[(row_text, y)]"""
    if not words:
        return []
    heights = [w[4] - w[2] for w in words]
    margin = max(4, statistics.median(heights) * 0.6)
    ws = sorted(words, key=lambda w: (w[2] + w[4]) / 2)
    rows = []
    for w in ws:
        yc = (w[2] + w[4]) / 2
        if rows and abs(yc - rows[-1]["y"]) < margin:
            rows[-1]["words"].append(w)
            rows[-1]["y"] = (rows[-1]["y"] + yc) / 2
        else:
            rows.append({"y": yc, "words": [w]})
    result = []
    for row in rows:
        row["words"].sort(key=lambda w: w[1])
        result.append(("".join(w[0] for w in row["words"]), row["y"]))
    return result


# ── 正解との比較 ──────────────────────────────
def evaluate(rows):
    """各正解名に最も近い行を探し、一致状況を返す"""
    lines = []
    exact = sym_ok = tag_ok = 0
    used = set()
    for truth in GROUND_TRUTH:
        best_i, best_r = None, -1.0
        for i, (text, _) in enumerate(rows):
            if i in used:
                continue
            # 行に pts 等が混ざるので、正解名を含むか / 類似度で判定
            r = SequenceMatcher(None, truth, text[:len(truth) + 3]).ratio()
            if truth in text:
                r = 1.0
            if r > best_r:
                best_i, best_r = i, r
        if best_i is None:
            lines.append(f"  x {truth:<16} -> (該当行なし)")
            continue
        used.add(best_i)
        got = rows[best_i][0]
        is_exact = truth in got
        truth_syms = [c for c in truth if c in SYMBOLS]
        is_sym = all(c in got for c in truth_syms) if truth_syms else None
        core = got.lstrip("0123456789■□ \u3000")      # 順位数字・アイコンのゴミを除いて比較
        is_tag = core[:1].upper() == truth[:1].upper()
        exact += is_exact
        tag_ok += is_tag
        if is_sym is not None:
            sym_ok += bool(is_sym)
        mark = "OK" if is_exact else "NG"
        lines.append(f"  {mark} 正解={truth:<16} 認識={got}"
                     f"   [先頭タグ:{'o' if is_tag else 'x'}"
                     f" 記号:{'-' if is_sym is None else ('o' if is_sym else 'x')}]")
    n_sym = sum(1 for t in GROUND_TRUTH if any(c in SYMBOLS for c in t))
    summary = (f"  完全一致 {exact}/{len(GROUND_TRUTH)}   "
               f"先頭タグ一致 {tag_ok}/{len(GROUND_TRUTH)}   "
               f"記号一致 {sym_ok}/{n_sym}")
    return lines, summary


# ── メイン ────────────────────────────────────
def main():
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("images", nargs="+", help="検証する画像 (結果画面を切り抜いたもの)")
    ap.add_argument("--scales", default="1,2",
                    help="試す拡大倍率 (カンマ区切り, 既定 1,2)")
    ap.add_argument("--features", default="both",
                    choices=["both", "text", "document"],
                    help="試すAPI機能 (既定 both)")
    ap.add_argument("--hints", default="ja,en",
                    help="languageHints (空文字で無指定, 既定 ja,en)")
    ap.add_argument("--dry-run", action="store_true",
                    help="APIを呼ばず消費ユニット数だけ表示")
    ap.add_argument("--no-truth", action="store_true",
                    help="正解との比較をしない (別画像用)")
    args = ap.parse_args()

    scales = [int(s) for s in args.scales.split(",") if s.strip()]
    feats = {"both": FEATURES, "text": FEATURES[:1],
             "document": FEATURES[1:]}[args.features]
    hints = [h for h in args.hints.split(",") if h.strip()]

    total = len(args.images) * len(scales) * len(feats)
    print(f"画像 {len(args.images)} x 倍率 {len(scales)} x 機能 {len(feats)}"
          f" = {total} ユニット消費します")
    if args.dry_run:
        print("(dry-run: APIは呼びません)")
        return

    if load_env_file:
        load_env_file()   # .env (このファイルと同じフォルダ) があれば読む
    api_key = os.environ.get("GOOGLE_VISION_API_KEY", "").strip()
    if not api_key:
        print("APIキーが見つかりません。次のどちらかで設定してください:")
        print("  1) .env ファイルに GOOGLE_VISION_API_KEY=キー を書く (同じフォルダ)")
        print("  2) set GOOGLE_VISION_API_KEY=キー  (このコマンドプロンプト内)")
        sys.exit(1)
    if input("続行しますか? [y/N] ").strip().lower() != "y":
        return

    guard = UsageGuard() if UsageGuard else None
    out_dir = "vision_test_out"
    os.makedirs(out_dir, exist_ok=True)
    report = [f"Vision API 検証  {datetime.now():%Y-%m-%d %H:%M:%S}",
              f"hints={hints}  scales={scales}  features={feats}", ""]

    for path in args.images:
        base = os.path.splitext(os.path.basename(path))[0]
        img = Image.open(path).convert("RGB")
        report.append("=" * 60)
        report.append(f"{path}  ({img.width}x{img.height})")
        for label, vimg in make_variants(img, scales).items():
            png = to_png_bytes(vimg)
            for feat in feats:
                tag = f"{base}_{label}_{feat}"
                report.append("")
                report.append(f"--- {label} / {feat}  ({len(png)//1024} KB) ---")
                try:
                    if guard:
                        guard.reserve(1, "vision_test:" + feat)
                    resp = call_vision(png, feat, api_key, hints)
                except Exception as e:
                    report.append(f"  ERROR: {e}")
                    continue
                with open(os.path.join(out_dir, tag + ".json"), "w",
                          encoding="utf-8") as f:
                    json.dump(resp, f, ensure_ascii=False, indent=1)
                words = extract_words(resp, feat)
                rows = group_rows(words)
                report.append("[認識された行]")
                for text, y in rows:
                    report.append(f"  y={y:6.1f}  {text}")
                if not args.no_truth:
                    lines, summary = evaluate(rows)
                    report.append("[正解との比較]")
                    report.extend(lines)
                    report.append(summary)
                if feat == "DOCUMENT_TEXT_DETECTION":
                    confs = [w[5] for w in words if w[5] is not None]
                    if confs:
                        report.append(f"  単語信頼度: 平均 {sum(confs)/len(confs):.2f}"
                                      f" / 最小 {min(confs):.2f}")

    text = "\n".join(report)
    with open(os.path.join(out_dir, "report.txt"), "w", encoding="utf-8") as f:
        f.write(text)
    print(text)
    print(f"\n保存先: {os.path.abspath(out_dir)}")


if __name__ == "__main__":
    main()
