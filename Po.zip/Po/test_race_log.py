#!/usr/bin/env python3
"""race_log.py のテスト (実行: python test_race_log.py)  ※ APIは使いません"""
import json
import tempfile
import unittest
from pathlib import Path

from PIL import Image

from race_log import (DEFAULT_POINTS, SessionLog, compute_player_totals, delta_diff,
                      format_report, match_roster, match_roster_with_fixes, name_score,
                      parse_names_text, rebuild_rows, team_delta)

# 1レース = 順位順の名前 (OCR後の行テキスト)。レースごとに順位が入れ替わる。
LOBBY = ["Dahlia", "ATM", "みつりょう☆サザエ☆", "Arcahv",
         "Miel JJG<3", "Mielodrome", "Dette", "みつりょう★イセエビ"]
RACES = [
    LOBBY,
    LOBBY[::-1],
    LOBBY[3:] + LOBBY[:3],
]
# 名簿 (OCRの表記ゆれ・略称を含む)
ROSTER = ["Dahlia", "ATM", "みつりょうサザエ", "Arcahv",
          "Miel JJG<3", "Mielodrome", "Dette", "ミツリョウ★イセエビ"]


def rows_for(names, extra=False):
    rows = [{"rank": i + 1, "text": n, "tag": None, "points": None}
            for i, n in enumerate(names)]
    if extra:
        rows.append({"rank": None, "text": "ghost", "tag": None, "points": None})
    return rows


def expected_points(roster_idx_to_lobby_name):
    total = {}
    for names in RACES:
        for rank, n in enumerate(names, 1):
            total[n] = total.get(n, 0) + DEFAULT_POINTS[rank - 1]
    return total


class TestNameMatching(unittest.TestCase):
    def test_scores(self):
        self.assertEqual(name_score("B◇SD", "B◇SD"), 1.0)
        self.assertEqual(name_score("B◆よめない", "Bよめない"), 1.0)        # ◆ を落としても同じ
        self.assertEqual(name_score("ミツリョウ", "みつりよう"), 1.0)       # カナ・小書き
        self.assertGreaterEqual(name_score("SD", "B◇SD"), 0.9)              # 略称
        self.assertGreaterEqual(name_score("みつりょうサザエ", "みつりょう☆サ"), 0.9)  # 右端で切れた
        self.assertLess(name_score("Dahlia", "Dette"), 0.6)
        self.assertEqual(name_score("", "x"), 0.0)

    def test_similar_prefix_names_are_assigned_one_to_one(self):
        rows = rows_for(["Miel JJG<3", "Mielodrome"])
        m = match_roster(rows, ["Mielodrome", "Miel JJG<3"])
        self.assertEqual(m, {0: 1, 1: 0})

    def test_extra_rows_are_ignored(self):
        rows = rows_for(["Dahlia"], extra=True)
        m = match_roster(rows, ["ghost"])
        self.assertEqual(m, {})


class TestSessionFiles(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def _img(self):
        return Image.new("RGB", (40, 30), "white")

    def test_layout_and_status_flow(self):
        s = SessionLog.create(self.base)
        a = s.save_capture(self._img(), rows_for(LOBBY), {"mode": "window_half", "row_count": 8})
        b = s.save_capture(self._img(), rows_for(LOBBY))
        c = s.save_capture(self._img(), rows_for(LOBBY))
        self.assertEqual((a, b, c), (1, 2, 3))
        for n in ("race_01.png", "race_01.json", "session.txt", "session.json"):
            self.assertTrue((s.folder / n).is_file(), n)
        self.assertEqual(json.loads((s.folder / "race_01.json").read_text("utf-8"))["status"], "pending")

        s.set_status(a, "added")
        s.set_status(b, "discarded")           # c は pending のまま
        self.assertEqual([r["seq"] for r in s.load_races()], [1])
        self.assertEqual([r["seq"] for r in s.load_races(statuses=None)], [1, 2, 3])
        self.assertEqual([p.name for p in s.folder.glob("*.tmp")], [])   # 一時ファイルが残らない

    def test_japanese_text_is_saved_readably(self):
        s = SessionLog.create(self.base)
        s.save_capture(self._img(), rows_for(["みつりょう☆サザエ☆"]))
        raw = (s.folder / "race_01.json").read_text("utf-8")
        self.assertIn("みつりょう☆サザエ☆", raw)             # \uXXXX にならない
        txt = (s.folder / "session.txt").read_bytes()
        self.assertTrue(txt.startswith(b"\xef\xbb\xbf"))    # メモ帳向けのBOM付き
        self.assertIn("みつりょう☆サザエ☆", txt.decode("utf-8-sig"))

    def test_reopen_continues_numbering_and_roster(self):
        s = SessionLog.create(self.base)
        s.save_capture(self._img(), rows_for(LOBBY))
        s.save_roster(["A", "B"])
        s2 = SessionLog(s.folder)               # アプリ再起動を想定
        self.assertEqual(s2.save_capture(self._img(), rows_for(LOBBY)), 2)
        self.assertEqual(s2.load_roster(), ["A", "B"])

    def test_two_sessions_in_same_second_get_different_folders(self):
        from datetime import datetime
        t = datetime(2026, 11, 5, 20, 15, 30)
        a = SessionLog.create(self.base, now=t)
        b = SessionLog.create(self.base, now=t)
        self.assertNotEqual(a.folder, b.folder)


class TestRetroactivePlayerTotals(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.s = SessionLog.create(Path(self.tmp.name))
        self.img = Image.new("RGB", (10, 10))

    def tearDown(self):
        self.tmp.cleanup()

    def test_roster_entered_after_races_counts_past_races(self):
        # 名簿が無い状態で3レース読み取り・確定
        for names in RACES:
            seq = self.s.save_capture(self.img, rows_for(names))
            self.s.set_status(seq, "added")
        # あとから名簿を入力 -> 過去分も遡って集計
        report = compute_player_totals(self.s.load_races(), ROSTER)
        got = {p["name"]: p["points"] for p in report["players"]}
        exp = expected_points(None)
        pairs = dict(zip(ROSTER, LOBBY))          # 名簿 <-> ロビーの実名 (表記ゆれあり)
        for roster_name, lobby_name in pairs.items():
            self.assertEqual(got[roster_name], exp[lobby_name], roster_name)
        self.assertEqual(report["issues"], [])
        self.assertEqual(report["races"], [1, 2, 3])
        self.assertTrue(all(p["races"] == 3 for p in report["players"]))

    def test_only_added_races_are_counted(self):
        a = self.s.save_capture(self.img, rows_for(LOBBY))
        b = self.s.save_capture(self.img, rows_for(LOBBY))
        c = self.s.save_capture(self.img, rows_for(LOBBY))
        self.s.set_status(a, "added")
        self.s.set_status(b, "discarded")
        report = compute_player_totals(self.s.load_races(), ROSTER)
        self.assertEqual(report["races"], [1])
        self.assertEqual(c, 3)
        self.assertEqual(sum(p["points"] for p in report["players"]), sum(DEFAULT_POINTS))

    def test_missing_and_unmatched_are_reported(self):
        seq = self.s.save_capture(self.img, rows_for(LOBBY[:7] + ["???"]))
        self.s.set_status(seq, "added")
        report = compute_player_totals(self.s.load_races(), ROSTER)
        self.assertEqual(len(report["issues"]), 1)
        issue = report["issues"][0]
        self.assertEqual(issue["race"], 1)
        self.assertEqual(issue["missing_players"], [ROSTER[7]])
        self.assertEqual([r["text"] for r in issue["unmatched_rows"]], ["???"])

    def test_export_and_format(self):
        seq = self.s.save_capture(self.img, rows_for(LOBBY))
        self.s.set_status(seq, "added")
        report = compute_player_totals(self.s.load_races(), ROSTER)
        self.s.export_players(report)
        txt = (self.s.folder / "players.txt").read_text("utf-8-sig")
        self.assertIn("PLAYER TOTALS", txt)
        self.assertIn("Dahlia", txt)
        self.assertEqual(json.loads((self.s.folder / "players.json").read_text("utf-8"))["races"], [1])
        self.assertIn("10 pts", format_report(report))



class TestEditingHelpers(unittest.TestCase):
    def test_parse_names_text(self):
        self.assertEqual(parse_names_text("A\n B \nC\n\n\n"), ["A", "B", "C"])   # 末尾の空行は無視
        self.assertEqual(parse_names_text("A\n\nC"), ["A", "", "C"])              # 途中の空行は残す
        self.assertEqual(parse_names_text(""), [])
        self.assertEqual(parse_names_text("\n\n"), [])

    def test_rebuild_rows_ranks_tags_points(self):
        from tag_match import closest_tag
        names = ["B◇SD", "", "Cじゃなくてd"] + ["Ayaneko"] * 6          # 9行
        rows = rebuild_rows(names, ["A", "B", "C", "D"], closest_tag, DEFAULT_POINTS)
        self.assertEqual([r["rank"] for r in rows], [1, 2, 3, 4, 5, 6, 7, 8, None])
        self.assertEqual((rows[0]["tag"], rows[0]["points"]), ("B", 10))
        self.assertEqual((rows[1]["tag"], rows[1]["points"]), (None, None))   # 空行 = 名前不明
        self.assertEqual((rows[2]["tag"], rows[2]["points"]), ("C", 6))        # 順位は数える
        self.assertEqual((rows[8]["tag"], rows[8]["points"]), (None, None))    # 9行目は対象外

    def test_team_delta_and_diff(self):
        rows = [{"tag": "B", "points": 10}, {"tag": "C", "points": 8},
                {"tag": "B", "points": 3}, {"tag": None, "points": None}]
        self.assertEqual(team_delta(rows), {"B": 13, "C": 8})
        self.assertEqual(delta_diff({"B": 13, "C": 8}, {"B": 11, "C": 10, "D": 0}),
                         {"B": -2, "C": 2})
        self.assertEqual(delta_diff({"A": 5}, {"A": 5}), {})


class TestUpdateAndRevert(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.s = SessionLog.create(Path(self.tmp.name))
        self.seq = self.s.save_capture(Image.new("RGB", (10, 10)), rows_for(LOBBY))

    def tearDown(self):
        self.tmp.cleanup()

    def test_update_keeps_original_once(self):
        new1 = rows_for(LOBBY[::-1])
        self.s.update_race(self.seq, rows=new1, status="added")
        d = self.s.load_race(self.seq)
        self.assertTrue(d["edited"])
        self.assertEqual(d["rows_original"], rows_for(LOBBY))
        self.s.update_race(self.seq, rows=rows_for(LOBBY[3:]))          # 2回目の編集
        d = self.s.load_race(self.seq)
        self.assertEqual(d["rows_original"], rows_for(LOBBY))           # 元は最初のまま
        self.assertEqual(d["row_count"], 5)
        self.assertIn("(edited)", (self.s.folder / "session.txt").read_text("utf-8-sig"))

    def test_revert_restores_original(self):
        self.assertFalse(self.s.revert_race(self.seq))                  # 未編集は False
        self.s.update_race(self.seq, rows=rows_for(LOBBY[::-1]))
        self.assertTrue(self.s.revert_race(self.seq))
        d = self.s.load_race(self.seq)
        self.assertEqual(d["rows"], rows_for(LOBBY))
        self.assertNotIn("rows_original", d)
        self.assertFalse(d["edited"])

    def test_update_unknown_race_raises(self):
        with self.assertRaises(KeyError):
            self.s.update_race(99, rows=[])

    def test_edited_rows_change_player_totals(self):
        self.s.update_race(self.seq, status="added")
        before = compute_player_totals(self.s.load_races(), ROSTER)
        self.s.update_race(self.seq, rows=rows_for(LOBBY[::-1]))        # 順位を逆にする
        after = compute_player_totals(self.s.load_races(), ROSTER)
        b = {p["name"]: p["points"] for p in before["players"]}
        a = {p["name"]: p["points"] for p in after["players"]}
        self.assertEqual(b["Dahlia"], 10)
        self.assertEqual(a["Dahlia"], 1)



def _race(seq, texts, tags=None):
    rows = [{"rank": i + 1, "text": t, "tag": (tags or {}).get(t), "points": None}
            for i, t in enumerate(texts)]
    return {"seq": seq, "status": "added", "rows": rows}


class TestOcrMisreadList(unittest.TestCase):
    """OCR ミスのリストは、名簿のどの人ともマッチしなかった行にだけ使う"""

    def test_misread_row_is_matched_after_applying_the_list(self):
        roster = ["Ai", "ATM", "Bob"]
        rows = _race(1, ["4i", "ATM", "Bob"])["rows"]
        matched, fixes = match_roster_with_fixes(rows, roster, [])
        self.assertEqual(matched, {1: 1, 2: 2})                       # "4i" は (Ai と) マッチしない
        matched, fixes = match_roster_with_fixes(rows, roster, [("4", "A")])
        self.assertEqual(matched, {0: 0, 1: 1, 2: 2})
        self.assertEqual(fixes, {0: "Ai"})

    def test_totals_use_the_fixed_row_and_report_it(self):
        roster = ["Ai", "ATM", "Bob"]
        races = [_race(1, ["4i", "ATM", "Bob"]), _race(2, ["Ai", "ATM", "Bob"])]
        before = compute_player_totals(races, roster)
        after = compute_player_totals(races, roster, rules=[("4", "A")])
        pts = lambda r: {p["name"]: p["points"] for p in r["players"]}
        self.assertEqual(pts(before)["Ai"], 10)                        # 2レース目の1位だけ
        self.assertEqual(pts(after)["Ai"], 10 + 10)                   # 1レース目 (補正) 1位10 + 2レース目 1位10
        self.assertEqual(after["corrections"], [{"race": 1, "rank": 1, "text": "4i", "fixed": "Ai",
                                                 "player": "Ai"}])
        self.assertEqual(before["corrections"], [])
        # 補正して一致した行は「マッチしなかった行」の一覧から消える
        self.assertTrue(any(it["race"] == 1 for it in before["issues"]))
        self.assertFalse(any(it["race"] == 1 for it in after["issues"]))

    def test_rows_that_already_match_are_left_alone(self):
        roster = ["R4M", "Zed"]
        rows = _race(1, ["R4M", "Zed"])["rows"]
        matched, fixes = match_roster_with_fixes(rows, roster, [("4", "A")])
        self.assertEqual((matched, fixes), ({0: 0, 1: 1}, {}))

    def test_it_never_steals_a_roster_name_that_is_already_taken(self):
        roster = ["Ai", "4i"]                      # "4i" という名前の人もいる
        rows = _race(1, ["4i", "xx"])["rows"]
        matched, fixes = match_roster_with_fixes(rows, roster, [("4", "A")])
        self.assertEqual(matched, {1: 0})          # 行 "4i" は名簿の "4i" に一致したまま
        self.assertEqual(fixes, {})

    def test_two_way_rule_and_multi_char_rule(self):
        roster = ["A0", "Tom"]                       # 短い名前は1文字違いで一致しなくなる
        rows = _race(1, ["AO", "Torn"])["rows"]
        self.assertEqual(match_roster_with_fixes(rows, roster, [])[0], {})
        matched, fixes = match_roster_with_fixes(rows, roster, [("O", "0"), ("rn", "m")])
        self.assertEqual(matched, {0: 0, 1: 1})
        self.assertEqual(fixes, {0: "A0", 1: "Tom"})
        # 両方向の指定 (0 <-> O) なら、逆向きの間違い (名簿が O で OCR が 0) にも効く
        from name_lists import parse_confusions
        rules, _ = parse_confusions("0 <-> O")
        self.assertEqual(match_roster_with_fixes(_race(1, ["B0"])["rows"], ["BO"], rules)[0], {0: 0})

    def test_two_substitutions_in_one_row(self):
        matched, fixes = match_roster_with_fixes(_race(1, ["44"])["rows"], ["AA"], [("4", "A")])
        self.assertEqual((matched, fixes), ({0: 0}, {0: "AA"}))

    def test_no_rules_means_no_change(self):
        roster = ["Ai", "ATM"]
        races = [_race(1, ["4i", "ATM"])]
        self.assertEqual(compute_player_totals(races, roster), compute_player_totals(races, roster, rules=[]))
        self.assertEqual(compute_player_totals(races, roster, rules=None)["corrections"], [])

    def test_report_text_lists_auto_fixes(self):
        report = compute_player_totals([_race(1, ["4i", "ATM"])], ["Ai", "ATM"], rules=[("4", "A")])
        text = format_report(report)
        self.assertIn("AUTO-FIXED", text)
        self.assertIn("4i -> Ai", text)
        self.assertNotIn("AUTO-FIXED", format_report(compute_player_totals([_race(1, ["Ai"])], ["Ai"])))

    def test_stored_race_data_is_not_modified(self):
        races = [_race(1, ["4i", "ATM"])]
        compute_player_totals(races, ["Ai", "ATM"], rules=[("4", "A")])
        self.assertEqual(races[0]["rows"][0]["text"], "4i")           # 保存された読み取り結果は元のまま


if __name__ == "__main__":
    unittest.main(verbosity=2)
