#!/usr/bin/env python3
"""
lists_window.py -- 「OCRミスのリスト」と「表示名の辞書」を編集する画面 (画面のみ)
=====================================================================
  上: OCRミスのリスト   名簿のどの人ともマッチしなかった行にだけ使い、マッチしたら集計に反映
  中: 表示名の辞書       lorenzi 風の画像出力にだけ使う (集計・照合には使わない)。左側は PLAYERS の名前と
                         一字一句同じに書く (似た名前は使わない)
  下: 今マッチしていない名前 / 辞書に載っていない PLAYERS の名前 (参考。リストを作るときの手がかり)

開いた瞬間に、保存されているテキストファイルの内容を入力欄に入れる (本体が読み直して渡す)。
行数が多くてもスクロールして編集できる。

保存・集計は本体 (score_app_v3.py) が行う。この画面は入力と表示だけを担当する。
"""

import tkinter as tk

_FONT = ("Consolas", 9)


class ListsWindow(tk.Toplevel):
    def __init__(self, master, theme, fix_text, dict_text, help_fixes, help_dict,
                 on_save, get_unmatched, on_close):
        """
        theme               {"bg","bg2","fg","fg2","btnb","btnf"}
        fix_text, dict_text 保存されている本文 (空のときは help_* を最初に表示する)
        on_save(fix, dict)  SAVE が押されたときに呼ぶ。戻り値の文字列をメッセージ欄に出す
        get_unmatched()     今マッチしていない名前の説明文 (str) を返す
        on_close()          画面を閉じたときに呼ぶ
        """
        super().__init__(master)
        self._t = theme
        self._on_save = on_save
        self._get_unmatched = get_unmatched
        self._on_close = on_close

        self.title("Lists")
        self.configure(bg=theme["bg"])
        self.geometry("720x900")

        self._head("OCR MISREADS  (よくあるOCRミス)")
        self._note("書き方:  4 -> A  (OCRが4と出したら本当はA) /  0 <-> O  (どちら向きにも間違える)。\n"
                   "名簿のどの人ともマッチしなかった行にだけ当てはめ、マッチしたら集計に反映します。")
        self.txt_fix = self._box(fix_text or help_fixes, 8)

        self._head("DISPLAY NAMES  (lorenzi 画像用の表示名)")
        self._note("書き方:  PLAYERS の名前 = 画像に載せる名前。左側は PLAYERS の名前と一字一句同じに書きます"
                   "(似た名前は使われません)。画像出力だけに使い、集計や照合には使いません。\n"
                   "名前の後ろに [国コード] を付けると国旗が出ます:  Dahlia = Lemon [jp]  /  ATM = [us] (国旗だけ)")
        self.txt_dict = self._box(dict_text or help_dict, 13)

        row = tk.Frame(self, bg=theme["bg"])
        row.pack(pady=6)
        tk.Button(row, text="SAVE", command=self._save, bg=theme["btnb"], fg=theme["btnf"],
                  activebackground="#555555", font=("Consolas", 9, "bold"), relief="flat",
                  padx=14, pady=4, cursor="hand2").pack()

        self.var_info = tk.StringVar(value="")
        tk.Label(self, textvariable=self.var_info, bg=theme["bg"], fg=theme["fg2"],
                 font=("Consolas", 8), wraplength=680, justify="left"
                 ).pack(anchor="w", padx=16, pady=2)

        self._head("CHECK  (今マッチしていない名前 / 辞書に載っていない PLAYERS の名前)")
        self.txt_out = self._box("", 8, state="disabled", fill="both", expand=True, bottom=12)
        self.show_unmatched()

        self.protocol("WM_DELETE_WINDOW", self._close)

    # ── 部品 ──────────────────────────────────
    def _head(self, text):
        tk.Label(self, text=text, bg=self._t["bg"], fg=self._t["fg"],
                 font=("Consolas", 9, "bold")).pack(anchor="w", padx=16, pady=(10, 0))

    def _note(self, text):
        tk.Label(self, text=text, bg=self._t["bg"], fg=self._t["fg2"], font=("Consolas", 8),
                 justify="left", wraplength=680).pack(anchor="w", padx=16)

    def _box(self, text, height, state="normal", fill="x", expand=False, bottom=4):
        """スクロールバーつきの入力欄 (行数が多くても、スクロールして編集できる)。"""
        frame = tk.Frame(self, bg=self._t["bg"])
        frame.pack(fill=fill, expand=expand, padx=16, pady=(4, bottom))
        bar = tk.Scrollbar(frame)
        bar.pack(side="right", fill="y")
        box = tk.Text(frame, height=height, bg=self._t["bg2"], fg=self._t["fg"],
                      insertbackground=self._t["fg"], font=_FONT, relief="flat",
                      yscrollcommand=bar.set)
        box.pack(side="left", fill="both", expand=True)
        bar.config(command=box.yview)
        if text:
            box.insert("1.0", text)
        box.config(state=state)
        return box

    # ── 操作 ──────────────────────────────────
    def texts(self):
        return self.txt_fix.get("1.0", "end").rstrip("\n"), self.txt_dict.get("1.0", "end").rstrip("\n")

    def _save(self):
        fix, dic = self.texts()
        self.var_info.set(self._on_save(fix, dic) or "")
        self.show_unmatched()

    def show_unmatched(self):
        self.txt_out.config(state="normal")
        self.txt_out.delete("1.0", "end")
        self.txt_out.insert("end", self._get_unmatched())
        self.txt_out.config(state="disabled")

    def set_info(self, msg):
        self.var_info.set(msg)

    def _close(self):
        self._on_close()
        self.destroy()
