﻿#!/usr/bin/env python3
"""
Mario Kart Team Score Tool v3 (Google Cloud Vision OCR)
=======================================================
Ctrl+Shift+L : 読み取り -> 確認 -> 加算
Ctrl+Shift+K : スコアクリア

pip install mss pillow keyboard pywin32 tzdata --user

APIキーは .env (または環境変数 GOOGLE_VISION_API_KEY) に設定する。 .env.example 参照。
OCR は月間 1,000 ユニットまで (usage_guard.py / SQLite で管理)。
"""

import os
import tkinter as tk
from tkinter import ttk, filedialog
import threading
import time
import re
from datetime import datetime
import mss
from PIL import Image, ImageTk
import keyboard
from vision_ocr import (VisionOCR, get_expected_rows, get_window_capture_method,
                        get_window_half_crop, save_debug_image)
from window_capture import grab_printwindow, raise_window
from tag_match import TAG_MAX_LEN, closest_tag
from race_log import (SessionLog, compute_player_totals, default_log_dir, delta_diff,
                      format_report, rebuild_rows, team_delta)
from leaderboard import save_png_atomic, write_leaderboard
from leaderboard_adapter import ExportError, build_model, to_lorenzi_text
from leaderboard_render import STYLES as LB_STYLES
from leaderboard_render import default_assets_dir, flag_code
from leaderboard_render import font_warnings as lb_font_warnings
from leaderboard_render import render_table
from players_window import PlayersWindow
from lists_window import ListsWindow
from name_lists import (HELP_DICT, HELP_FIXES, NameLists, load_lists, save_lists, split_flag,
                        unlisted_names)
from races_window import RacesWindow
from usage_guard import WARN_RATIO

try:
    import win32gui
    WIN32 = True
except ImportError:
    WIN32 = False

# ── 定数 ──────────────────────────────────────
POINTS        = [10, 8, 6, 5, 4, 3, 2, 1]
HOTKEY_CAP    = "ctrl+shift+l"
HOTKEY_CLR    = "ctrl+shift+k"
PLUS_DURATION = 3000
ROW_MARGIN    = 30

# ── モノクロ配色 ──────────────────────────────
BG   = "#111111"
BG2  = "#1e1e1e"
BG3  = "#2e2e2e"
FG   = "#ffffff"
FG2  = "#aaaaaa"
FG3  = "#555555"
BTNB = "#3a3a3a"
BTNF = "#ffffff"

# ── タグマッチング ────────────────────────────
# ── Windowsウィンドウ一覧 ─────────────────────
def get_window_list():
    if not WIN32:
        return []
    result = []
    def _cb(hwnd, _):
        if win32gui.IsWindowVisible(hwnd):
            t = win32gui.GetWindowText(hwnd).strip()
            if t:
                result.append((hwnd, t))
    win32gui.EnumWindows(_cb, None)
    return result

def get_client_region(hwnd):
    rect = win32gui.GetClientRect(hwnd)
    pt   = win32gui.ClientToScreen(hwnd, (0, 0))
    return {"left": pt[0], "top": pt[1],
            "width": rect[2], "height": rect[3]}

# ── 領域選択オーバーレイ ──────────────────────
class RegionSelector:
    def __init__(self):
        self.region = None

    def select(self, parent):
        parent.withdraw()
        time.sleep(0.25)
        self.root = tk.Toplevel()
        self.root.attributes("-fullscreen", True)
        self.root.attributes("-alpha", 0.3)
        self.root.configure(bg="black")
        self.root.attributes("-topmost", True)
        self.canvas = tk.Canvas(self.root, cursor="cross",
                                bg="black", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        tk.Label(self.root,
                 text="リザルト画面の領域をドラッグして選択  (ESC でキャンセル)",
                 bg="black", fg="white",
                 font=("Consolas", 13)).place(relx=0.5, rely=0.05, anchor="center")
        self.sx = self.sy = 0
        self.rect = None
        self.canvas.bind("<ButtonPress-1>",   self._press)
        self.canvas.bind("<B1-Motion>",        self._drag)
        self.canvas.bind("<ButtonRelease-1>",  self._release)
        self.root.bind("<Escape>", lambda _: self.root.destroy())
        self.root.wait_window()
        parent.deiconify()
        return self.region

    def _press(self, e):
        self.sx, self.sy = e.x, e.y
        self.rect = self.canvas.create_rectangle(
            e.x, e.y, e.x, e.y, outline="white", width=2)

    def _drag(self, e):
        self.canvas.coords(self.rect, self.sx, self.sy, e.x, e.y)

    def _release(self, e):
        x1, y1 = min(self.sx, e.x), min(self.sy, e.y)
        x2, y2 = max(self.sx, e.x), max(self.sy, e.y)
        if x2 - x1 > 20 and y2 - y1 > 20:
            self.region = {"left": x1, "top": y1,
                           "width": x2 - x1, "height": y2 - y1}
        self.root.destroy()

# ── スコアボード (OBS用) ──────────────────────
class ScoreBoard(tk.Toplevel):
    def __init__(self, master, tags):
        super().__init__(master)
        self.title("ScoreBoard")
        self.configure(bg="black")
        self.resizable(True, True)
        self.attributes("-topmost", True)
        self.tags   = tags
        self.scores = {t: 0 for t in tags}
        self._jobs  = {}
        self._build()

    def _build(self):
        top = tk.Frame(self, bg="black")
        top.pack(fill="x", padx=30, pady=(20, 0))

        self.lbl_lt = tk.Label(top, text=self.tags[0], bg="black", fg="white",
                               font=("Consolas", 22, "bold"), anchor="w")
        self.lbl_lt.pack(side="left")
        self.lbl_pl = tk.Label(top, text="", bg="black", fg="#FF4444",
                               font=("Consolas", 18, "bold"))
        self.lbl_pl.pack(side="left", padx=(20, 0))
        self.lbl_pr = tk.Label(top, text="", bg="black", fg="#FF4444",
                               font=("Consolas", 18, "bold"))
        self.lbl_pr.pack(side="right", padx=(0, 20))
        self.lbl_rt = tk.Label(top, text=self.tags[1], bg="black", fg="white",
                               font=("Consolas", 22, "bold"), anchor="e")
        self.lbl_rt.pack(side="right")

        bot = tk.Frame(self, bg="black")
        bot.pack(padx=30, pady=(4, 24))
        self.lbl_sl = tk.Label(bot, text="000", bg="black", fg="white",
                               font=("Consolas", 56, "bold"))
        self.lbl_sl.pack(side="left")
        tk.Label(bot, text=" - ", bg="black", fg="white",
                 font=("Consolas", 56, "bold")).pack(side="left")
        self.lbl_sr = tk.Label(bot, text="000", bg="black", fg="white",
                               font=("Consolas", 56, "bold"))
        self.lbl_sr.pack(side="left")

    def update_scores(self, delta):
        for tag, pts in delta.items():
            if tag in self.scores:
                self.scores[tag] += pts
        self.lbl_sl.config(text=str(self.scores[self.tags[0]]).zfill(3))
        self.lbl_sr.config(text=str(self.scores[self.tags[1]]).zfill(3))
        for lbl, tag in [(self.lbl_pl, self.tags[0]), (self.lbl_pr, self.tags[1])]:
            pts = delta.get(tag, 0)
            if pts > 0:
                lbl.config(text=f"+{str(pts).zfill(2)}")
                if tag in self._jobs:
                    self.after_cancel(self._jobs[tag])
                self._jobs[tag] = self.after(
                    PLUS_DURATION, lambda l=lbl: l.config(text=""))

    def adjust_scores(self, diff):
        """読み取り結果を直したときの訂正用。合計だけを増減する (+N の表示は出さない)。"""
        for tag, pts in diff.items():
            if tag in self.scores:
                self.scores[tag] = max(0, self.scores[tag] + pts)
        self.lbl_sl.config(text=str(self.scores[self.tags[0]]).zfill(3))
        self.lbl_sr.config(text=str(self.scores[self.tags[1]]).zfill(3))

    def clear(self):
        for t in self.tags:
            self.scores[t] = 0
        self.lbl_sl.config(text="000")
        self.lbl_sr.config(text="000")
        self.lbl_pl.config(text="")
        self.lbl_pr.config(text="")

    def update_tags(self, tags):
        self.tags = tags
        self.scores = {t: 0 for t in tags}
        self.lbl_lt.config(text=tags[0])
        self.lbl_rt.config(text=tags[1])
        self.clear()


# ── スコアボード 4グループ版 (OBS用) ────────────
class ScoreBoard4(tk.Toplevel):
    """
    縦4行 x 左(タグ) / 右(ポイント) のレイアウト。
    文字数に応じてフォントサイズを自動調整。
    """
    BASE_SIZE = 72   # 1文字時のフォントサイズ

    def __init__(self, master, tags):
        super().__init__(master)
        self.title("ScoreBoard")
        self.configure(bg="black")
        self.resizable(True, True)
        self.attributes("-topmost", True)
        self.tags   = tags
        self.scores = {t: 0 for t in tags}
        self._build()

    def _font_size(self, n_chars):
        """文字数に応じてフォントサイズを返す"""
        return max(10, self.BASE_SIZE // max(n_chars, 1))

    def _build(self):
        self.row_frames  = []
        self.lbl_tags    = []
        self.lbl_scores  = []

        for i, tag in enumerate(self.tags):
            frame = tk.Frame(self, bg="black")
            frame.pack(fill="both", expand=True, padx=20, pady=6)
            frame.columnconfigure(0, weight=1)
            frame.columnconfigure(1, weight=1)

            fs_tag = self._font_size(len(tag))
            lbl_t = tk.Label(frame, text=tag, bg="black", fg="white",
                             font=("Consolas", fs_tag, "bold"), anchor="w")
            lbl_t.grid(row=0, column=0, sticky="nsew")

            score_str = str(self.scores[tag])
            fs_pts = self._font_size(len(score_str))
            lbl_s = tk.Label(frame, text=score_str, bg="black", fg="white",
                             font=("Consolas", fs_pts, "bold"), anchor="e")
            lbl_s.grid(row=0, column=1, sticky="nsew")

            # 区切り線（最後の行以外）
            if i < len(self.tags) - 1:
                tk.Frame(self, bg="#333333", height=1).pack(fill="x", padx=20)

            self.row_frames.append(frame)
            self.lbl_tags.append(lbl_t)
            self.lbl_scores.append(lbl_s)

    def _rebuild(self):
        for w in self.winfo_children():
            w.destroy()
        self.lbl_tags   = []
        self.lbl_scores = []
        self.row_frames = []
        self._build()

    def update_scores(self, delta):
        for tag, pts in delta.items():
            if tag in self.scores:
                self.scores[tag] += pts
        for i, tag in enumerate(self.tags):
            score_str = str(self.scores[tag])
            fs = self._font_size(len(score_str))
            self.lbl_scores[i].config(text=score_str,
                                      font=("Consolas", fs, "bold"))

    def adjust_scores(self, diff):
        """読み取り結果を直したときの訂正用。合計だけを増減する。"""
        for tag, pts in diff.items():
            if tag in self.scores:
                self.scores[tag] = max(0, self.scores[tag] + pts)
        for i, tag in enumerate(self.tags):
            score_str = str(self.scores[tag])
            fs = self._font_size(len(score_str))
            self.lbl_scores[i].config(text=score_str,
                                      font=("Consolas", fs, "bold"))

    def clear(self):
        for t in self.tags:
            self.scores[t] = 0
        for i, tag in enumerate(self.tags):
            self.lbl_scores[i].config(text="0",
                                      font=("Consolas", self.BASE_SIZE, "bold"))

    def update_tags(self, tags):
        self.tags   = tags
        self.scores = {t: 0 for t in tags}
        self._rebuild()

# ── コントロールパネル ────────────────────────
class ControlPanel(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Score Tool")
        self.configure(bg=BG)
        self.geometry("560x700")
        self.resizable(False, True)

        self.group_mode   = tk.IntVar(value=2)   # 2 or 4
        self.ocr          = None
        self.ocr_ready    = False
        self.scoreboard   = None
        self.tags         = []
        self.region       = None
        self.capture_mode = tk.StringVar(value="region")
        self.image_path   = tk.StringVar(value="")
        self._win_map     = {}
        self.history      = []
        self.capturing    = False
        self._pending     = None
        self._usage_msg   = ""
        self.session      = None   # 現在のセッション (最初の読み取りでフォルダを作る)
        self._pending_seq = None   # 読み取り済みで、まだ add score していないレース
        self._last_img    = None
        self._last_rows   = []     # 直近の読み取り結果 (名簿の自動入力用)
        self.roster       = []     # プレイヤー名簿
        self.players_win  = None
        self.races_win    = None
        self.lists_win    = None
        self.lists        = self._load_lists()   # OCRミスのリスト / 表示名の辞書 (settings フォルダのテキスト)
        self.roster_flags = {}     # 名簿の名前 -> 国コード (入力手段は未実装。空なら国旗なし)
        self._exporting   = False  # 画像出力の実行中
        self._export_thread = None

        self._setup_scroll()
        self._build()
        self._init_ocr()

    # ── スクロール設定 ────────────────────────
    def _setup_scroll(self):
        self._canvas = tk.Canvas(self, bg=BG, highlightthickness=0)
        self._vsb    = tk.Scrollbar(self, orient="vertical",
                                    command=self._canvas.yview)
        self._canvas.configure(yscrollcommand=self._vsb.set)
        self._vsb.pack(side="right", fill="y")
        self._canvas.pack(side="left", fill="both", expand=True)

        self._inner = tk.Frame(self._canvas, bg=BG)
        self._win_id = self._canvas.create_window(
            (0, 0), window=self._inner, anchor="nw")

        self._inner.bind("<Configure>", self._on_frame_configure)
        self._canvas.bind("<Configure>", self._on_canvas_configure)
        self._canvas.bind("<MouseWheel>",
                          lambda e: self._canvas.yview_scroll(
                              -1 * (e.delta // 120), "units"))

    def _on_frame_configure(self, _=None):
        self._canvas.configure(scrollregion=self._canvas.bbox("all"))

    def _on_canvas_configure(self, e):
        self._canvas.itemconfig(self._win_id, width=e.width)

    # ── ヘルパー ──────────────────────────────
    def _lbl(self, parent, text, size=9, bold=False, color=None, **kw):
        bg = parent.cget("bg") if hasattr(parent, "cget") else BG
        return tk.Label(parent, text=text, bg=bg,
                        fg=color or FG2,
                        font=("Consolas", size, "bold" if bold else "normal"), **kw)

    def _btn(self, parent, text, cmd, width=None):
        kw = dict(text=text, command=cmd,
                  bg=BTNB, fg=BTNF, activebackground="#555555",
                  font=("Consolas", 9, "bold"),
                  relief="flat", padx=8, pady=4, cursor="hand2")
        if width:
            kw["width"] = width
        return tk.Button(parent, **kw)

    def _sep(self):
        tk.Frame(self._inner, bg=BG3, height=1).pack(fill="x", padx=16, pady=6)

    # ── UI 構築 ───────────────────────────────
    def _build(self):
        S = self._inner  # スクロール内フレームを親に使う
        self._lbl(S, "SCORE TOOL", size=17, bold=True, color=FG).pack(pady=(16, 2))
        self._lbl(S, "Mario Kart team score aggregator", color=FG3).pack(pady=(0, 8))

        self.var_status = tk.StringVar(value="initializing OCR...")
        self.lbl_status = tk.Label(S, textvariable=self.var_status,
                                   bg=BG2, fg=FG2,
                                   font=("Consolas", 8), pady=5)
        self.lbl_status.pack(fill="x", padx=16, pady=2)

        # グループ数選択
        tk.Frame(S, bg=BG3, height=1).pack(fill="x", padx=16, pady=6)
        self._lbl(S, "GROUP MODE", bold=True, color=FG).pack(anchor="w", padx=20)
        grp_row = tk.Frame(S, bg=BG)
        grp_row.pack(fill="x", padx=20, pady=4)
        for val, label in [(2, "2 groups"), (4, "4 groups")]:
            tk.Radiobutton(grp_row, text=label, variable=self.group_mode, value=val,
                           command=self._on_group_change,
                           bg=BG, fg=FG2, selectcolor=BG3,
                           activebackground=BG, activeforeground=FG,
                           font=("Consolas", 9)).pack(side="left", padx=8)

        # タグ入力エリア（グループ数に応じて切り替わる）
        tk.Frame(S, bg=BG3, height=1).pack(fill="x", padx=16, pady=6)
        self._lbl(S, "TAGS", bold=True, color=FG).pack(anchor="w", padx=20)
        self.tag_frame = tk.Frame(S, bg=BG)
        self.tag_frame.pack(fill="x", padx=20, pady=4)
        self.tag_entries = []
        self._build_tag_entries()

        # キャプチャモード
        tk.Frame(S, bg=BG3, height=1).pack(fill="x", padx=16, pady=6)
        self._lbl(S, "CAPTURE MODE", bold=True, color=FG).pack(anchor="w", padx=20)
        modes = [
            ("drag region",        "region"),
            ("window  lower half", "window_half"),
            ("window  full",       "window_full"),
            ("image file",         "image"),
        ]
        mode_frame = tk.Frame(S, bg=BG)
        mode_frame.pack(fill="x", padx=20, pady=4)
        for i, (label, val) in enumerate(modes):
            tk.Radiobutton(mode_frame, text=label,
                           variable=self.capture_mode, value=val,
                           command=self._on_mode_change,
                           bg=BG, fg=FG2, selectcolor=BG3,
                           activebackground=BG, activeforeground=FG,
                           font=("Consolas", 9)).grid(
                               row=i // 2, column=i % 2,
                               sticky="w", padx=4, pady=2)

        self.mode_config = tk.Frame(S, bg=BG2)
        self.mode_config.pack(fill="x", padx=16, pady=4)
        self._build_mode_region()

        row0 = tk.Frame(S, bg=BG)
        row0.pack(pady=6)
        self._btn(row0, "START", self._start).pack(side="left", padx=6)
        # ホットキーが効かない状況でもクリックで読み取れるボタン
        self.btn_read = self._btn(row0, "READ  (Ctrl+Shift+L)", self._capture)
        self.btn_read.pack(side="left", padx=6)

        # プレビュー
        tk.Frame(S, bg=BG3, height=1).pack(fill="x", padx=16, pady=6)
        self._lbl(S, "PREVIEW", bold=True, color=FG).pack(anchor="w", padx=20)
        self.lbl_preview = tk.Label(S, bg=BG2,
                                    text="( READボタン / Ctrl+Shift+L で読み取り )",
                                    fg=FG3, font=("Consolas", 8))
        self.lbl_preview.pack(padx=16, pady=4)

        # OCR結果
        self._lbl(S, "RESULT", bold=True, color=FG).pack(anchor="w", padx=20)
        wrap = tk.Frame(S, bg=BG2)
        wrap.pack(fill="x", padx=16, pady=4)
        self.txt_result = tk.Text(wrap, height=7, bg=BG2, fg=FG,
                                  font=("Consolas", 9), relief="flat",
                                  state="disabled")
        self.txt_result.pack(fill="x", padx=4, pady=4)

        # 確認ボタン
        row = tk.Frame(S, bg=BG)
        row.pack(pady=6)
        self.btn_ok = self._btn(row, "add score", self._confirm, width=12)
        self.btn_ok.config(state="disabled")
        self.btn_ok.pack(side="left", padx=6)
        self.btn_retry = self._btn(row, "retry", self._retry, width=12)
        self.btn_retry.config(state="disabled")
        self.btn_retry.pack(side="left", padx=6)

        # 履歴
        tk.Frame(S, bg=BG3, height=1).pack(fill="x", padx=16, pady=6)
        self._lbl(S, "HISTORY", bold=True, color=FG).pack(anchor="w", padx=20)
        hw = tk.Frame(S, bg=BG2)
        hw.pack(fill="both", expand=True, padx=16, pady=4)
        self.lst_hist = tk.Listbox(hw, bg=BG2, fg=FG2,
                                   font=("Consolas", 8), relief="flat",
                                   selectbackground=BG3, height=4)
        sb = tk.Scrollbar(hw, orient="vertical", command=self.lst_hist.yview)
        self.lst_hist.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.lst_hist.pack(side="left", fill="both", expand=True)

        # 下部
        bot = tk.Frame(S, bg=BG)
        bot.pack(pady=6)
        self._btn(bot, "CLEAR  (Ctrl+Shift+K)", self._clear).pack(side="left", padx=6)
        self._btn(bot, "PLAYERS", self._open_players).pack(side="left", padx=6)
        self._btn(bot, "EDIT RACES", self._open_races).pack(side="left", padx=6)
        self._btn(bot, "LISTS", self._open_lists).pack(side="left", padx=6)
        self._lbl(S, "Ctrl+Shift+L: read    Ctrl+Shift+K: clear",
                  color=FG3, size=7).pack(pady=(0, 8))

    # ── グループ数切り替え ────────────────────────
    def _build_tag_entries(self):
        for w in self.tag_frame.winfo_children():
            w.destroy()
        self.tag_entries = []
        n = self.group_mode.get()
        labels = ["Left", "Right"] if n == 2 else ["Tag 1", "Tag 2", "Tag 3", "Tag 4"]
        defaults = ["East", "West"] if n == 2 else ["A", "B", "C", "D"]
        for i, (lbl, default) in enumerate(zip(labels, defaults)):
            row = i // 2
            col = (i % 2) * 2
            self._lbl(self.tag_frame, f"{lbl}:").grid(row=row, column=col, sticky="w", padx=(0, 4), pady=2)
            var = tk.StringVar(value=default)
            tk.Entry(self.tag_frame, textvariable=var, width=9,
                     font=("Consolas", 12, "bold"),
                     bg=BG3, fg=FG, insertbackground=FG,
                     relief="flat").grid(row=row, column=col+1, padx=(0, 16), pady=2)
            self.tag_entries.append(var)

    def _on_group_change(self):
        self._build_tag_entries()
        # スコアボードが開いていれば閉じる
        if self.scoreboard and self.scoreboard.winfo_exists():
            self.scoreboard.destroy()
            self.scoreboard = None

    # ── モード別設定 ──────────────────────────
    def _clear_mode_config(self):
        for w in self.mode_config.winfo_children():
            w.destroy()

    def _on_mode_change(self):
        self._clear_mode_config()
        m = self.capture_mode.get()
        if m == "region":
            self._build_mode_region()
        elif m in ("window_half", "window_full"):
            self._build_mode_window()
        else:
            self._build_mode_image()

    def _build_mode_region(self):
        row = tk.Frame(self.mode_config, bg=BG2)
        row.pack(fill="x", padx=8, pady=6)
        self._btn(row, "select region", self._select_region).pack(side="left", padx=4)
        self.var_region_info = tk.StringVar(value="not set")
        tk.Label(row, textvariable=self.var_region_info,
                 bg=BG2, fg=FG3, font=("Consolas", 8)).pack(side="left", padx=8)

    def _build_mode_window(self):
        row = tk.Frame(self.mode_config, bg=BG2)
        row.pack(fill="x", padx=8, pady=6)
        self._btn(row, "refresh", self._refresh_windows).pack(side="left", padx=4)
        self.var_win = tk.StringVar()
        self.cmb_win = ttk.Combobox(row, textvariable=self.var_win,
                                    width=34, font=("Consolas", 8), state="readonly")
        self.cmb_win.pack(side="left", padx=6)
        self.cmb_win.bind("<<ComboboxSelected>>", lambda e: self.focus())
        self._refresh_windows()

    def _build_mode_image(self):
        row = tk.Frame(self.mode_config, bg=BG2)
        row.pack(fill="x", padx=8, pady=6)
        self._btn(row, "select file", self._select_image).pack(side="left", padx=4)
        tk.Label(row, textvariable=self.image_path,
                 bg=BG2, fg=FG3, font=("Consolas", 8),
                 wraplength=300).pack(side="left", padx=6)

    def _select_region(self):
        sel = RegionSelector()
        r = sel.select(self)
        if r:
            self.region = r
            self.var_region_info.set(f"{r['width']}x{r['height']} @ ({r['left']},{r['top']})")
        else:
            self._set_status("region not selected")

    def _refresh_windows(self):
        wins = get_window_list()
        self._win_map = {t: h for h, t in wins}
        titles = list(self._win_map.keys())
        self.cmb_win["values"] = titles
        if titles:
            self.cmb_win.current(0)

    def _select_image(self):
        p = filedialog.askopenfilename(
            filetypes=[("image", "*.png *.jpg *.jpeg *.bmp")])
        if p:
            self.image_path.set(p)

    # ── OCR 初期化 ────────────────────────────
    def _init_ocr(self):
        def _run():
            try:
                self.ocr = VisionOCR()
                st = self.ocr.check_ready()   # APIキーと利用量DBの確認
                self.ocr_ready = True
                msg = f"ready  [{self._usage_text(st)}]"
                self.after(0, lambda m=msg: self._set_status(m))
                self.after(0, self._register_hotkeys)
            except Exception as e:
                msg = f"OCR error: {e}"
                self.after(0, lambda m=msg: self._set_status(m))
        threading.Thread(target=_run, daemon=True).start()

    @staticmethod
    def _usage_text(st):
        text = f"usage {st['used']}/{st['limit']}"
        if st["limit"] and st["used"] >= st["limit"] * WARN_RATIO:
            text += " !"
        return text

    def _set_status(self, msg):
        self.var_status.set(msg)

    def _register_hotkeys(self):
        keyboard.add_hotkey(HOTKEY_CAP, lambda: self.after(0, self._capture))
        keyboard.add_hotkey(HOTKEY_CLR, lambda: self.after(0, self._clear))

    # ── スタート ──────────────────────────────
    def _start(self):
        tags = [v.get().strip()[:TAG_MAX_LEN] for v in self.tag_entries]
        if not all(tags):
            self._set_status("error: enter all tags")
            return
        mode = self.capture_mode.get()
        if mode == "region" and not self.region:
            self._set_status("error: select region first")
            return
        if mode in ("window_half", "window_full") and not self.var_win.get():
            self._set_status("error: select window first")
            return
        if mode == "image" and not self.image_path.get():
            self._set_status("error: select image first")
            return

        self.tags = tags
        n = self.group_mode.get()
        if self.scoreboard and self.scoreboard.winfo_exists():
            self.scoreboard.update_tags(self.tags)
        else:
            if n == 2:
                self.scoreboard = ScoreBoard(self, self.tags)
            else:
                self.scoreboard = ScoreBoard4(self, self.tags)
        self._set_status(f"running  {' / '.join(tags)}")

    # ── キャプチャ ────────────────────────────
    def _capture(self):
        if self.capturing or not self.ocr_ready:
            return
        if not self.tags:
            self._set_status("error: press START first")
            return
        self.capturing = True
        self._discard_pending_race()
        self._pending = None
        self.btn_ok.config(state="disabled")
        self.btn_retry.config(state="disabled")
        self._set_status("reading...")
        threading.Thread(target=self._do_capture, daemon=True).start()

    def _do_capture(self):
        try:
            mode = self.capture_mode.get()
            img  = None

            if mode == "region":
                if not self.region:
                    raise ValueError("region not set")
                with mss.mss() as sct:
                    shot = sct.grab(self.region)
                    img  = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")

            elif mode in ("window_half", "window_full"):
                hwnd = self._win_map.get(self.var_win.get())
                if not hwnd:
                    raise ValueError("window not found")
                # 撮り方: screen(従来) / printwindow / raise  (.env: MK7_WINDOW_CAPTURE)
                method = get_window_capture_method()
                if method == "printwindow":
                    img = grab_printwindow(hwnd)
                else:
                    if method == "raise":
                        raise_window(hwnd)
                    reg = get_client_region(hwnd)
                    with mss.mss() as sct:
                        shot = sct.grab(reg)
                        img  = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")
                if mode == "window_half":
                    save_debug_image(img, "last_client.png")   # 切り抜き調整用 (ocr_debug設定時のみ)
                    c_left, c_top, c_right, c_bot = get_window_half_crop()   # .env で調整可
                    w, h  = img.size
                    img   = img.crop((int(w * c_left), int(h * c_top),
                                      int(w * c_right), int(h * c_bot)))

            elif mode == "image":
                p = self.image_path.get()
                if not p:
                    raise ValueError("no image selected")
                img = Image.open(p).convert("RGB")

            # プレビュー（アスペクト比を保ってリサイズ）
            preview = img.copy()
            max_w, max_h = 500, 160
            ratio   = min(max_w / preview.width, max_h / preview.height)
            new_w   = max(1, int(preview.width  * ratio))
            new_h   = max(1, int(preview.height * ratio))
            preview = preview.resize((new_w, new_h), Image.LANCZOS)

            # OCR (Cloud Vision: 1画像=1ユニット。送信前に利用量を予約し、
            # 上限到達 / 記録失敗 / キー未設定なら例外で停止する)
            results = self.ocr.read(img)
            self._last_img = img
            # Vision は1回の応答で全体を読むため、ストリップOCR(2回目)は廃止
            strip_results = []
            self._usage_msg = self._usage_text(self.ocr.last_status)

            self.after(0, lambda: self._on_captured(results, strip_results, preview))

        except Exception as e:
            msg = f"error: {e}"
            self.after(0, lambda m=msg: self._set_status(m))
        finally:
            self.capturing = False

    def _on_captured(self, results, strip_results, preview_img):
        self._tk_preview = ImageTk.PhotoImage(preview_img)
        self.lbl_preview.config(image=self._tk_preview, text="",
                                width=preview_img.width, height=preview_img.height)

        # ストリップ結果をy座標でインデックス化（タグ候補）
        strip_by_y = sorted(strip_results, key=lambda r: r[0][0][1])

        results_sorted = sorted(results, key=lambda r: r[0][0][1])
        rows = []
        for bbox, text, conf in results_sorted:
            y = bbox[0][1]
            if rows and abs(y - rows[-1]["y"]) < ROW_MARGIN:
                rows[-1]["texts"].append((text, conf))
            else:
                rows.append({"y": y, "texts": [(text, conf)], "strip_texts": []})

        # ストリップ結果を対応する行に紐付け
        for bbox, text, conf in strip_by_y:
            y = bbox[0][1]
            best_row = min(rows, key=lambda r: abs(r["y"] - y), default=None)
            if best_row and abs(best_row["y"] - y) < ROW_MARGIN * 2:
                best_row["strip_texts"].append(text)

        matched = []
        shown = []     # 結果欄に出す行: (順位, タグ or None, ポイント or None, 生テキスト)
        rank = 0
        valid_rows = 0
        for row in rows:
            combined  = "".join(t for t, _ in row["texts"])
            max_conf  = max(c for _, c in row["texts"])
            if max_conf < 0.05:
                continue
            valid_rows += 1
            if rank < len(POINTS):
                # まず1パス目のテキストだけでタグ判定
                tag = closest_tag(combined, self.tags)
                # タグが見つからず1文字タグが存在する場合のみストリップで再試行
                if tag is None:
                    has_single = any(len(re.sub(r"[^a-zA-Z0-9]", "", t)) == 1 for t in self.tags)
                    if has_single and row["strip_texts"]:
                        strip_prefix = "".join(row["strip_texts"])
                        tag = closest_tag(strip_prefix + combined, self.tags)
                if tag:
                    matched.append((rank + 1, tag, POINTS[rank], combined))
                    shown.append((rank + 1, tag, POINTS[rank], combined))
                else:
                    shown.append((rank + 1, None, 0, combined))   # タグ不一致 (点数なし)
                rank += 1
            else:
                shown.append((valid_rows, None, None, combined))  # 9行目以降 (対象外)

        delta = {t: 0 for t in self.tags}
        for _, tag, pts, _ in matched:
            delta[tag] += pts
        self._pending = delta

        # 読み取り行数が期待値(既定8)と違えば警告 (1行読み落とすと順位がずれるため)
        expected = get_expected_rows()
        warn = ""
        if expected and valid_rows != expected:
            warn = f"WARNING: {valid_rows} rows read (expected {expected})"

        lines = []
        if warn:
            lines.append("!! " + warn)
            lines.append("!! check the ranks before adding")
            lines.append("-" * 36)
        for rn, tag, pts, raw in shown:
            if tag:
                lines.append(f"{rn}  [{tag}]  +{pts}pts   {raw[:16]}")
            elif pts is None:
                lines.append(f"{rn}  [extra row: ignored]   {raw[:16]}")
            else:
                lines.append(f"{rn}  [no tag]   {raw[:16]}")
        lines.append("-" * 36)
        for t in self.tags:
            lines.append(f"  {t:<6}  +{str(delta[t]).zfill(2)} pts")

        # 行数に合わせて欄の高さを広げる (固定7行だと8位以降が隠れていた)
        self.txt_result.config(state="normal", height=max(7, len(lines)))
        self.txt_result.delete("1.0", "end")
        self.txt_result.insert("end", "\n".join(lines))
        self.txt_result.config(state="disabled")

        note = self._log_capture(shown, valid_rows, expected)

        self.btn_ok.config(state="normal")
        self.btn_retry.config(state="normal")
        if warn:
            self._set_status(f"{warn} -- check  [{self._usage_msg}]{note}")
        else:
            self._set_status(f"done -- confirm to add score  [{self._usage_msg}]{note}")

    # ── 確認 / リトライ / クリア ──────────────
    def _confirm(self):
        if not self._pending or not self.scoreboard:
            return
        self.scoreboard.update_scores(self._pending)
        now = datetime.now().strftime("%H:%M:%S")
        summary = "  ".join(f"{t}:+{str(v).zfill(2)}" for t, v in self._pending.items())
        self.lst_hist.insert(0, f"[{now}]  {summary}")
        self.history.append(self._pending.copy())
        self._pending = None
        self._mark_race("added")
        self._refresh_players()
        self._refresh_races()
        self.btn_ok.config(state="disabled")
        self.btn_retry.config(state="disabled")
        self._set_status("added")

    def _retry(self):
        self._pending = None
        self.btn_ok.config(state="disabled")
        self.btn_retry.config(state="disabled")
        self._capture()

    def _clear(self):
        self.history.clear()
        self.lst_hist.delete(0, "end")
        self._pending = None
        self._discard_pending_race()
        self.session = None        # 次の読み取りから、新しいセッション(フォルダ)を作る
        self.roster = []
        self._last_rows = []
        self._refresh_players()
        self._refresh_races()
        self.btn_ok.config(state="disabled")
        self.btn_retry.config(state="disabled")
        if self.scoreboard and self.scoreboard.winfo_exists():
            self.scoreboard.clear()
        self._set_status("cleared")

    # ── 記録 / プレイヤー別集計 ───────────────
    def _log_capture(self, shown, valid_rows, expected):
        """読み取り結果と画像をセッションのフォルダに保存する。
        失敗しても集計は止めない (空文字 or 失敗メッセージを返す)。"""
        self._pending_seq = None
        self._last_rows = [s[3] for s in shown if s[2] is not None]
        try:
            if self._last_img is None:
                return ""
            if self.session is None:
                self.session = SessionLog.create()
                if self.roster:
                    self.session.save_roster(self.roster)
            rows = [{"rank": rn if pts is not None else None,
                     "text": raw,
                     "tag": tag,
                     "points": pts if tag else None}
                    for rn, tag, pts, raw in shown]
            meta = {"mode": self.capture_mode.get(), "tags": list(self.tags),
                    "row_count": valid_rows, "expected_rows": expected}
            self._pending_seq = self.session.save_capture(self._last_img, rows, meta)
            return ""
        except Exception as e:
            return f"  (log failed: {e})"

    def _mark_race(self, status):
        """直近の読み取りレースの状態 (added / discarded) を記録に反映する。"""
        if self.session is None or self._pending_seq is None:
            return
        try:
            self.session.set_status(self._pending_seq, status)
        except Exception as e:
            self._set_status(f"log error: {e}")
        self._pending_seq = None

    def _discard_pending_race(self):
        self._mark_race("discarded")

    def _players_win_alive(self):
        return self.players_win is not None and self.players_win.winfo_exists()

    def _open_players(self):
        if self._players_win_alive():
            self.players_win.lift()
            return
        theme = {"bg": BG, "bg2": BG2, "fg": FG, "fg2": FG2, "btnb": BTNB, "btnf": BTNF}
        self.players_win = PlayersWindow(self, theme, self.roster, self._apply_roster,
                                         lambda: list(self._last_rows),
                                         self._on_players_closed,
                                         on_export=self._export_image,
                                         styles=[(k, v["name"]) for k, v in LB_STYLES.items()])
        self._refresh_players()

    def _write_leaderboard(self, races, report):
        """結果画像 (leaderboard.png) を作る。OBS の画像ソース用に、保存先の直下の
        leaderboard_latest.png にも同じものを書く。失敗しても集計は止めない。"""
        try:
            title = os.environ.get("MK7_EVENT_TITLE", "").strip() or "MK7 Mogi"
            subtitle = datetime.now().strftime("%d %b %Y")
            paths = [self.session.folder / "leaderboard_live.png",
                     default_log_dir() / "leaderboard_latest.png"]
            write_leaderboard(races, report, paths, title, subtitle)
            return ""
        except Exception as e:
            return f"leaderboard failed: {e}"

    def _lorenzi_text(self):
        """現在のレース結果を、lorenzi の入力欄に貼るテキストにする (得点は4レースごとの和)。
        作れないときは、その理由を返す。画像出力と同じ model から作る。"""
        try:
            races = self.session.load_races() if self.session else []
            model = build_model(races, self.roster, POINTS, flags=self.roster_flags,
                                title=os.environ.get("MK7_EVENT_TITLE", "").strip(),
                                ocr_rules=self.lists.rules, name_dict=self.lists.names)
            return to_lorenzi_text(model)
        except ExportError as e:
            return str(e)
        except Exception as e:
            return f"(テキストを作れませんでした: {e})"

    def _export_image(self, style_key):
        """順位表 (チーム別・プレイヤー別) の画像を、現在のセッションのフォルダに
        leaderboard.png として保存する。描画に時間がかかることがあるので別スレッドで行い、
        結果はステータスと名簿画面のメッセージ欄に出す。失敗してもアプリは止めない。
        戻り値は名簿画面にすぐ出すメッセージ。"""
        if self._exporting:
            return "画像を作成中です。終わるまでお待ちください。"
        self._reload_lists()
        try:
            races = self.session.load_races() if self.session else []
            model = build_model(races, self.roster, POINTS, flags=self.roster_flags,
                                title=os.environ.get("MK7_EVENT_TITLE", "").strip(),
                                ocr_rules=self.lists.rules,        # 照合は名簿画面の集計と同じ
                                name_dict=self.lists.names)        # 表示名の辞書は、この画像だけに使う
        except ExportError as e:
            self._set_status(str(e))
            return str(e)
        except Exception as e:
            msg = f"画像の準備に失敗しました: {e}"
            self._set_status(msg)
            return msg
        path = self.session.folder / "leaderboard.png"
        self._exporting = True

        def _run():
            try:
                img = render_table(model, style_key or "dark", 2, True, "")
                save_png_atomic(img, path)
                msg = f"画像を保存しました: {path}"
                warn = lb_font_warnings()
                if warn:
                    msg += "  (代用フォントを使用: assets/fonts を確認してください)"
            except Exception as e:
                msg = f"画像出力に失敗しました: {e}"
            self.after(0, lambda m=msg: self._export_done(m))

        self._export_thread = threading.Thread(target=_run, daemon=True)
        self._export_thread.start()
        return "画像を作成中です…"

    def _export_done(self, msg):
        self._exporting = False
        self._set_status(msg)
        if self._players_win_alive():
            self.players_win.set_info(msg)

    # ── OCRミスのリスト / 表示名の辞書 ───────────
    def _load_lists(self):
        try:
            return load_lists()
        except Exception:
            return NameLists()

    def _reload_lists(self):
        """settings フォルダの2つのテキストを読み直す。テキストエディタで直した内容も反映される。
        読めなかったときは、直前の内容のまま。"""
        try:
            self.lists = load_lists()
        except Exception:
            pass

    def _lists_win_alive(self):
        return self.lists_win is not None and self.lists_win.winfo_exists()

    def _open_lists(self):
        if self._lists_win_alive():
            self.lists_win.lift()                    # 開いている間は、編集中の内容を消さない
            return
        self._reload_lists()                         # 開いた瞬間に、テキストファイルの現在の内容を入れる
        theme = {"bg": BG, "bg2": BG2, "fg": FG, "fg2": FG2, "btnb": BTNB, "btnf": BTNF}
        self.lists_win = ListsWindow(self, theme, self.lists.fix_text, self.lists.dict_text,
                                     HELP_FIXES, HELP_DICT, self._save_lists,
                                     self._unmatched_text, self._on_lists_closed)

    def _on_lists_closed(self):
        self.lists_win = None

    def _save_lists(self, fix_text, dict_text):
        """2つのリストを保存し、名簿の集計をやり直す (OCRミスのリストは過去のレースにも効く)。
        戻り値は画面に出すメッセージ。"""
        try:
            self.lists = save_lists(fix_text, dict_text)
        except Exception as e:
            msg = f"保存に失敗しました: {e}"
            self._set_status(msg)
            return msg
        self._refresh_players()
        msg = (f"保存しました (OCRミス {len(self.lists.rules)} 件 / "
               f"表示名 {len(self.lists.names)} 件)")
        self._set_status(msg)
        missing = self._unknown_flag_codes()
        if missing:
            msg += "\n国旗の画像が見つからないコード: " + ", ".join(missing) + " (灰色の箱に表示されます)"
        errs = self.lists.errors
        if errs:
            first = "; ".join(f"{kind} {no}行目: {reason}" for kind, no, _raw, reason in errs[:3])
            msg += f"\n無視した行が {len(errs)} 件あります: {first}" + (" ..." if len(errs) > 3 else "")
        return msg

    def _unknown_flag_codes(self):
        """表示名の辞書で使われた国コードのうち、国旗の画像 (assets/flags) が無いもの。"""
        missing = []
        for value in self.lists.names.values():
            code = split_flag(value)[1]
            if not code:
                continue
            norm = flag_code(code)
            if not norm or not (default_assets_dir() / "flags" / f"{norm}.png").is_file():
                if code not in missing:
                    missing.append(code)
        return missing

    def _unmatched_text(self):
        """今、名簿のどの人ともマッチしていない名前と、辞書に載っていない PLAYERS の名前
        (リストを作る手がかり)。"""
        if not self.roster:
            return "(名簿を適用すると、マッチしなかった名前がここに出ます)"
        lines = []
        if self.session is None:
            lines.append("(確定済みのレースがまだありません)")
        else:
            try:
                report = compute_player_totals(self.session.load_races(), self.roster, POINTS,
                                               rules=self.lists.rules)
            except Exception as e:
                report = None
                lines.append(f"(取得に失敗しました: {e})")
            if report is not None:
                if not report["issues"]:
                    lines.append("(マッチしていない名前はありません)")
                for it in report["issues"]:
                    if it["missing_players"]:
                        lines.append(f"race {it['race']}  名簿にいるが見つからない: "
                                     + ", ".join(it["missing_players"]))
                    if it["unmatched_rows"]:
                        lines.append(f"race {it['race']}  どの名簿ともマッチしない行: "
                                     + ", ".join(f"{r['rank']}位 {r['text']}" for r in it["unmatched_rows"]))
        # 辞書は PLAYERS の名前との完全一致だけで引く。見出しが無い名前は、画像に試合中の名前のまま出る
        unlisted = unlisted_names(self.roster, self.lists.names) if self.lists.names else []
        if unlisted:
            shown = ", ".join(unlisted[:15]) + (f" ... ほか {len(unlisted) - 15} 件" if len(unlisted) > 15 else "")
            lines.append("")
            lines.append("辞書に載っていない PLAYERS の名前 (画像には、そのままの名前で出ます): " + shown)
        return "\n".join(lines)

    def _on_players_closed(self):
        self.players_win = None

    def _apply_roster(self, names):
        """名簿を適用する。確定済みの過去レースも遡って集計される。"""
        self.roster = names
        if self.session is not None and names:
            try:
                self.session.save_roster(names)
            except Exception as e:
                self._set_status(f"log error: {e}")
        self._refresh_players()

    def _refresh_players(self):
        """名簿があれば、確定済みレースからプレイヤー別に集計して表示・保存する。"""
        self._reload_lists()
        win = self.players_win if self._players_win_alive() else None
        if win:
            win.show_lorenzi(self._lorenzi_text())
        if not self.roster:
            if win:
                win.show("")
                win.set_info("Enter the player names and press APPLY.")
            return
        if self.session is None:
            if win:
                win.show("")
                win.set_info("No race yet. Totals appear after the first 'add score'.")
            return
        try:
            races = self.session.load_races()
            report = compute_player_totals(races, self.roster, POINTS, rules=self.lists.rules)
            self.session.export_players(report)
            lb_error = self._write_leaderboard(races, report)
            if lb_error:
                self._set_status(lb_error)
            if win:
                win.show(format_report(report))
                notes = []
                if lb_error:
                    notes.append(lb_error)
                if len(self.roster) != 8:
                    notes.append(f"{len(self.roster)} names (expected 8)")
                if self._pending_seq is not None:
                    notes.append("latest read not added yet")
                extra = ("  [" + ", ".join(notes) + "]") if notes else ""
                win.set_info(f"{len(races)} race(s) counted{extra}\n{self.session.folder}")
        except Exception as e:
            self._set_status(f"players error: {e}")
            if win:
                win.set_info(f"error: {e}")

    # ── 過去レースの読み取り結果の編集 ───────────
    def _races_win_alive(self):
        return self.races_win is not None and self.races_win.winfo_exists()

    def _open_races(self):
        if self.session is None:
            self._set_status("no race yet (nothing to edit)")
            return
        if self._races_win_alive():
            self.races_win.lift()
            self.races_win.refresh_list()
            return
        theme = {"bg": BG, "bg2": BG2, "fg": FG, "fg2": FG2, "btnb": BTNB, "btnf": BTNF}
        self.races_win = RacesWindow(self, theme, self._races_list, self._races_load,
                                     self._races_save, self._races_revert,
                                     self._on_races_closed)

    def _on_races_closed(self):
        self.races_win = None

    def _refresh_races(self):
        if self._races_win_alive():
            self.races_win.refresh_list()

    def _races_list(self):
        """編集画面の一覧 (確定済みと、除外したレース。確認待ちのレースは出さない)。"""
        if self.session is None:
            return []
        out = []
        for r in self.session.load_races(statuses=("added", "discarded")):
            out.append({"seq": r["seq"], "status": r["status"],
                        "time": r.get("captured_at", "")[-8:],
                        "rows": len(r.get("rows", [])), "edited": bool(r.get("edited"))})
        return out

    def _races_load(self, seq):
        race = self.session.load_race(seq) if self.session else None
        if not race:
            return None
        names = [row.get("text", "") for row in race.get("rows", [])]
        info = f"race {seq:02d}   captured {race.get('captured_at', '')}   {len(names)} rows"
        if race.get("edited"):
            info += "   (edited; REVERT restores the original)"
        return {"names": names, "counted": race.get("status") == "added",
                "image": str(self.session.folder / race.get("image", "")), "info": info}

    def _apply_race_change(self, race, new_rows, new_status, tags):
        """行・状態を保存し、チーム点の増減分をスコアボードへ反映する。
        戻り値: (増減分, 説明メモ)"""
        seq = race["seq"]
        before = team_delta(race.get("rows", [])) if race.get("status") == "added" else {}
        after = team_delta(new_rows) if new_status == "added" else {}
        diff = delta_diff(before, after)
        self.session.update_race(seq, rows=new_rows, status=new_status)
        note = ""
        if diff:
            board_ok = self.scoreboard is not None and self.scoreboard.winfo_exists()
            if list(tags) == list(self.tags) and board_ok:
                self.scoreboard.adjust_scores(diff)
                note = "scoreboard adjusted"
            else:
                note = "scoreboard NOT changed (this race used different tags)"
            text = "  ".join(f"{t}:{v:+d}" for t, v in diff.items())
            now = datetime.now().strftime("%H:%M:%S")
            self.lst_hist.insert(0, f"[{now}]  edit race {seq:02d}: {text}")
        self._refresh_players()
        return diff, note

    def _result_text(self, rows, diff, note, new_status):
        lines = []
        for r in rows:
            rn = r["rank"] if r["rank"] is not None else "-"
            if r["tag"]:
                lines.append(f"{rn}  [{r['tag']}]  +{r['points']}pts   {r['text']}")
            elif r["rank"] is None:
                lines.append(f"{rn}  [extra row: ignored]   {r['text']}")
            else:
                lines.append(f"{rn}  [no tag]   {r['text']}")
        lines.append("-" * 36)
        lines.append("counted" if new_status == "added" else "NOT counted (excluded)")
        if diff:
            lines.append("team change: " + "  ".join(f"{t}:{v:+d}" for t, v in diff.items()))
        else:
            lines.append("team change: none")
        if note:
            lines.append(note)
        return "\n".join(lines)

    def _races_save(self, seq, names, counted):
        race = self.session.load_race(seq) if self.session else None
        if not race:
            return f"race {seq} not found"
        tags = race.get("tags") or self.tags
        rows = rebuild_rows(names, tags, closest_tag, POINTS)
        new_status = "added" if counted else "discarded"
        try:
            diff, note = self._apply_race_change(race, rows, new_status, tags)
        except Exception as e:
            return f"error: {e}"
        self._set_status(f"race {seq:02d} saved")
        return self._result_text(rows, diff, note, new_status)

    def _races_revert(self, seq):
        race = self.session.load_race(seq) if self.session else None
        if not race:
            return f"race {seq} not found"
        original = race.get("rows_original")
        if original is None:
            return "This race has not been edited."
        tags = race.get("tags") or self.tags
        try:
            diff, note = self._apply_race_change(race, original, race.get("status"), tags)
            self.session.revert_race(seq)      # rows_original を消して元の状態に戻す
        except Exception as e:
            return f"error: {e}"
        self._set_status(f"race {seq:02d} reverted")
        return "reverted to the original read.\n" + self._result_text(
            original, diff, note, race.get("status"))

# ── エントリポイント ──────────────────────────
if __name__ == "__main__":
    app = ControlPanel()
    app.mainloop()