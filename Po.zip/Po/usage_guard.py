#!/usr/bin/env python3
"""
usage_guard.py -- Cloud Vision API 月間ユニット管理 (SQLite)
==========================================================
* 月間上限 (既定 1,000) に達したら reserve() が UsageLimitReached を送出する。
* 「上限チェック」と「加算」は 1 つの UPDATE 文 (BEGIN IMMEDIATE 内) で行うため、
  アプリを複数同時に起動しても上限を超えない。
* DB を開けない / 書き込めない場合は UsageRecordError を送出する (= 呼び出し側は
  API を呼ばない。安全側に倒す)。
* 月が変わると新しい月のレコードが作られるので、リセット処理は不要。
* 月の境界は米国太平洋時間 (Google Cloud Billing のレポートが太平洋時間基準のため)。
  zoneinfo が使えない環境では UTC-8 固定で代用する。これは「リセットが最大1時間遅れる」
  側にしか誤差が出ないので、上限超過にはならない。

コマンド:
    python usage_guard.py status      今月の使用量を表示
    python usage_guard.py add 4       アプリ外で消費した分を記録 (負数で訂正)
"""

import os
import sqlite3
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

DEFAULT_MONTHLY_LIMIT = 1000
WARN_RATIO = 0.8
BILLING_TZ = "America/Los_Angeles"


class UsageError(Exception):
    """利用量管理に関するエラーの基底クラス"""


class UsageLimitReached(UsageError):
    """月間上限に達した (API は呼ばない)"""


class UsageRecordError(UsageError):
    """利用量を記録 / 読み取りできない (API は呼ばない)"""


def current_month_key(now=None):
    now = now or datetime.now(timezone.utc)
    try:
        from zoneinfo import ZoneInfo
        local = now.astimezone(ZoneInfo(BILLING_TZ))
    except Exception:
        local = now.astimezone(timezone(timedelta(hours=-8)))
    return local.strftime("%Y-%m")


def default_db_path():
    env = os.environ.get("MK7_USAGE_DB", "").strip()
    if env:
        return Path(env)
    base = os.environ.get("LOCALAPPDATA") or str(Path.home())
    return Path(base) / "MK7ScoreOCR" / "usage.db"


def get_monthly_limit():
    raw = os.environ.get("MK7_MONTHLY_LIMIT", "").strip()
    if not raw:
        return DEFAULT_MONTHLY_LIMIT
    try:
        value = int(raw)
        if value < 1:
            raise ValueError
        return value
    except ValueError:
        raise UsageRecordError(f"invalid MK7_MONTHLY_LIMIT: {raw!r}") from None


class UsageGuard:
    def __init__(self, db_path=None, limit=None, month_fn=current_month_key):
        self.db_path = Path(db_path) if db_path else default_db_path()
        self.limit = limit if limit is not None else get_monthly_limit()
        self._month_fn = month_fn

    # ── 内部 ──────────────────────────────────
    def _connect(self):
        try:
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            con = sqlite3.connect(str(self.db_path), timeout=10.0,
                                  isolation_level=None)   # 明示的に BEGIN する
            con.execute("PRAGMA busy_timeout=10000")
            try:
                con.execute("PRAGMA journal_mode=WAL")
            except sqlite3.Error:
                pass   # WAL 非対応の場所でも動作は可能
            con.execute("CREATE TABLE IF NOT EXISTS usage ("
                        " month TEXT PRIMARY KEY,"
                        " used  INTEGER NOT NULL CHECK (used >= 0))")
            con.execute("CREATE TABLE IF NOT EXISTS usage_log ("
                        " id INTEGER PRIMARY KEY AUTOINCREMENT,"
                        " ts INTEGER NOT NULL, month TEXT NOT NULL,"
                        " units INTEGER NOT NULL, feature TEXT NOT NULL)")
            return con
        except (OSError, sqlite3.Error) as e:
            raise UsageRecordError(f"usage DB unavailable: {e}") from None

    @staticmethod
    def _rollback(con):
        try:
            con.execute("ROLLBACK")
        except sqlite3.Error:
            pass

    # ── 公開 API ──────────────────────────────
    def reserve(self, units=1, feature=""):
        """units を予約 (加算) し、加算後の月間使用量を返す。
        上限を超える場合は UsageLimitReached、記録できなければ UsageRecordError。
        API 呼び出しの「前」に必ず呼ぶこと。"""
        if units < 1:
            raise ValueError("units must be >= 1")
        month = self._month_fn()
        con = self._connect()
        try:
            try:
                con.execute("BEGIN IMMEDIATE")   # 書き込みロックを先に取る
                con.execute("INSERT OR IGNORE INTO usage(month, used) VALUES (?, 0)",
                            (month,))
                cur = con.execute(
                    "UPDATE usage SET used = used + ? "
                    "WHERE month = ? AND used + ? <= ?",
                    (units, month, units, self.limit))
                if cur.rowcount != 1:
                    used = con.execute("SELECT used FROM usage WHERE month = ?",
                                       (month,)).fetchone()[0]
                    con.execute("ROLLBACK")
                    raise UsageLimitReached(
                        f"monthly limit reached ({used}/{self.limit}, {month})")
                con.execute("INSERT INTO usage_log(ts, month, units, feature) "
                            "VALUES (?, ?, ?, ?)",
                            (int(time.time()), month, units, feature))
                used = con.execute("SELECT used FROM usage WHERE month = ?",
                                   (month,)).fetchone()[0]
                con.execute("COMMIT")
                return used
            except UsageLimitReached:
                raise
            except sqlite3.Error as e:
                self._rollback(con)
                raise UsageRecordError(f"cannot record usage: {e}") from None
        finally:
            con.close()

    def status(self):
        month = self._month_fn()
        con = self._connect()
        try:
            row = con.execute("SELECT used FROM usage WHERE month = ?",
                              (month,)).fetchone()
        except sqlite3.Error as e:
            raise UsageRecordError(f"cannot read usage: {e}") from None
        finally:
            con.close()
        used = row[0] if row else 0
        return {"month": month, "used": used, "limit": self.limit,
                "remaining": max(0, self.limit - used)}

    def adjust(self, delta):
        """アプリ外で消費した分の記録 / 訂正。上限チェックはしない (実態を記録するため)。"""
        month = self._month_fn()
        con = self._connect()
        try:
            try:
                con.execute("BEGIN IMMEDIATE")
                con.execute("INSERT OR IGNORE INTO usage(month, used) VALUES (?, 0)",
                            (month,))
                con.execute("UPDATE usage SET used = MAX(0, used + ?) WHERE month = ?",
                            (delta, month))
                con.execute("INSERT INTO usage_log(ts, month, units, feature) "
                            "VALUES (?, ?, ?, 'manual')",
                            (int(time.time()), month, delta))
                con.execute("COMMIT")
            except sqlite3.Error as e:
                self._rollback(con)
                raise UsageRecordError(f"cannot adjust usage: {e}") from None
        finally:
            con.close()
        return self.status()


def format_status(st):
    pct = st["used"] * 100 // st["limit"] if st["limit"] else 0
    return f"usage {st['used']}/{st['limit']} ({pct}%) [{st['month']}]"


def main(argv):
    try:
        guard = UsageGuard()
        if len(argv) >= 2 and argv[1] == "add" and len(argv) == 3:
            st = guard.adjust(int(argv[2]))
        elif len(argv) == 2 and argv[1] == "status":
            st = guard.status()
        else:
            print(__doc__)
            return 1
    except UsageError as e:
        print(f"error: {e}")
        return 2
    print(format_status(st))
    print(f"DB: {guard.db_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
