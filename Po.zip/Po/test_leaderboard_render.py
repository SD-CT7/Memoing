#!/usr/bin/env python3
"""
leaderboard_render.py のテスト (実行: python test_leaderboard_render.py)  ※ APIは使いません

基準:
  tests_data/js_reference.json            参考実装 (leaderboard-table-maker.html) を node で実行して得た値
                                          (順位・合計・色・国旗コード・画像サイズ)
  tests_data/chrome_new_light_sandbox.png 同じ HTML を Chrome 153 (ヘッドレス) で描いた画像 (light / 倍率2)
  tests_data/chrome_names_sandbox.png     名前の長さがばらばらの表 (短い / 中くらい / 非常に長い / 日本語 /
                                          長いチーム名) を同じ Chrome で描いた画像 (light / 倍率2)
                                          ※ 文字の縦位置は OS・フォントの測り方で数 px ずれるため、
                                            横方向の位置と幅だけを厳密に比べる
"""
import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from PIL import Image, ImageChops, ImageStat

import leaderboard_render as lr

DATA = Path(__file__).resolve().parent / "tests_data"
REF = json.loads((DATA / "js_reference.json").read_text(encoding="utf-8"))
CASES = REF["cases"]


class TestHelpersMatchJs(unittest.TestCase):
    def test_auto_color(self):
        for tag, expected in REF["autoColor"].items():
            self.assertEqual(lr.auto_color(tag), expected, repr(tag))

    def test_flag_code(self):
        for raw, url in REF["flagUrl"].items():
            expected = None if url is None else url[len("flags/"):].rsplit(".", 1)[0]
            self.assertEqual(lr.flag_code(raw), expected, repr(raw))

    def test_rank_str(self):
        for r, expected in REF["rankStr"].items():
            self.assertEqual(lr.rank_str(int(r)), expected, r)

    def test_hsv_roundtrip_and_hex(self):
        for hexcol in ("#3a86ff", "#ef476f", "#007f86", "#fd4d44"):
            h, s, v = lr.rgb2hsv(*lr.hex2rgb(hexcol))
            self.assertEqual(lr.rgb2hex(lr.hsv2rgb(h, s, v)), hexcol)
        self.assertIsNone(lr.hex2rgb("not a colour"))
        self.assertIsNone(lr.hex2rgb("#12345"))
        self.assertEqual(lr.parse_css_color("#fffa"), (255, 255, 255, 170))
        self.assertEqual(lr.parse_css_color("#4444"), (68, 68, 68, 68))
        self.assertEqual(lr.parse_css_color("#3a86ff"), (58, 134, 255, 255))

    def test_css_font_match(self):
        self.assertEqual([lr.css_font_match(w, (300, 400, 900)) for w in (300, 400, 500, 600, 700, 900)],
                         [300, 400, 400, 900, 900, 900])
        self.assertEqual(lr.css_font_match(900, (400,)), 400)

    def test_gradient_stops(self):
        g = lr._Gradient(["#000000", "#ff0000", "#0000ff"], 100, 200)
        self.assertEqual(g.color_at(50), (0, 0, 0))          # 範囲の外は端の色
        self.assertEqual(g.color_at(200), (255, 0, 0))       # 3色は等間隔 (中央が2色目)
        self.assertEqual(g.color_at(400), (0, 0, 255))
        self.assertEqual(g.color_at(150), (128, 0, 0))


class TestExpandAndLayoutMatchJs(unittest.TestCase):
    def test_expand(self):
        for name, case in CASES.items():
            ex = lr.expand(case["model"])
            py = [(t["tag"], t["finalScore"], t["ranking"], t["autoColor"],
                   [(p["name"], p["ranking"], p["finalScore"], p["finalScoreWithoutBonus"]) for p in t["players"]])
                  for t in ex["teams"]]
            js = [(t["tag"], t["finalScore"], t["ranking"], t["autoColor"],
                   [(p["name"], p["ranking"], p["finalScore"], p["finalScoreWithoutBonus"]) for p in t["players"]])
                  for t in case["js"]["teams"]]
            self.assertEqual(py, js, name)

    def test_layout_sizes(self):
        for name, case in CASES.items():
            ex = lr.expand(case["model"])
            for key, (jw, jh) in case["js"]["sizes"].items():
                style, scale = key.split("@")
                L = lr.compute_layout(ex, lr.resolve_style(style), True)
                self.assertEqual((int(L["W"] * int(scale)), int(L["H"] * int(scale))), (jw, jh), f"{name} {key}")

    def test_sample_is_1094_by_582(self):
        L = lr.compute_layout(lr.expand(lr.SAMPLE_MODEL), lr.STYLES["light"], True)
        self.assertEqual((L["W"], L["H"]), (1094, 582))

    def test_hide_flags_removes_column(self):
        ex = lr.expand(lr.SAMPLE_MODEL)
        with_f = lr.compute_layout(ex, lr.STYLES["dark"], True)["W"]
        without = lr.compute_layout(ex, lr.STYLES["dark"], False)["W"]
        self.assertEqual(with_f - without, 54)

    def test_empty_model(self):
        ex = lr.expand({"teams": []})
        self.assertEqual(lr.compute_layout(ex, lr.STYLES["dark"], True)["H"], 528)
        img = lr.render_table({"teams": []}, "dark", 1)
        self.assertEqual(img.size[1], 528)


class TestRenderSample(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.images = {k: lr.render_table(lr.SAMPLE_MODEL, k, 2, True, "gb.hlorenzi.com") for k in lr.STYLES}

    def test_all_five_styles_have_browser_size(self):
        self.assertEqual(set(self.images), {"light", "dark", "darkThin", "atlasLeague", "mku"})
        for k, img in self.images.items():
            self.assertEqual(img.size, (2188, 1164), k)
            self.assertEqual(img.mode, "RGB")

    @staticmethod
    def _xsegs(im, y0, y1, x0, x1, thr=70, gap=18):
        """帯 (y0..y1) の中で、暗い文字の横方向のまとまり (x の範囲) を返す。"""
        c = im.convert("L").crop((x0, y0, x1, y1)).point(lambda v: 255 if v < thr else 0)
        cols = [c.crop((x, 0, x + 1, c.height)).getbbox() is not None for x in range(c.width)]
        out, s, last = [], None, None
        for x, on in enumerate(cols + [False] * (gap + 1)):
            if on:
                if s is None:
                    s = x
                last = x
            elif s is not None and x - last > gap:
                out.append((x0 + s, x0 + last))
                s = None
        return out

    def test_horizontal_text_positions_match_chrome(self):
        """新しい HTML を Chrome で描いた画像と、文字の横方向の位置・幅が 2px 以内で一致すること
        (最大幅の圧縮が無いこと、Rubik Mono One が 0.78 倍で描かれることの確認を兼ねる)。"""
        chrome = Image.open(DATA / "chrome_new_light_sandbox.png").convert("RGB")
        ours = self.images["light"]
        self.assertEqual(chrome.size, ours.size)
        items = {"Alpha tag": (140, 320, 120, 640), "player name": (112, 135, 640, 920),
                 "team score 313": (170, 340, 1620, 2188), "diff": (400, 440, 1900, 2100),
                 "Bravo tag": (560, 780, 120, 640), "Charlie tag (はみ出す)": (900, 1130, 0, 640)}
        for name, (y0, y1, x0, x1) in items.items():
            a = self._xsegs(chrome, y0 - 24, y1 + 24, x0, x1)     # Chrome は縦に数 px ずれるので広めに取る
            b = self._xsegs(ours, y0, y1, x0, x1)
            self.assertEqual(len(a), len(b), name)
            for (a0, a1), (b0, b1) in zip(a, b):
                self.assertLessEqual(abs(a0 - b0), 2, f"{name}: {a} vs {b}")
                self.assertLessEqual(abs(a1 - b1), 2, f"{name}: {a} vs {b}")

    def test_overall_image_is_close_to_chrome(self):
        """全体の平均差の上限 (緩め)。Chrome との文字の縦位置の差 (環境差) を含むので 12 未満とする。"""
        chrome = Image.open(DATA / "chrome_new_light_sandbox.png").convert("RGB")
        diff = ImageChops.difference(chrome, self.images["light"])
        self.assertLess(sum(ImageStat.Stat(diff).mean) / 3, 12.0)

    def test_scale_1_is_half_size(self):
        img = lr.render_table(lr.SAMPLE_MODEL, "light", 1)
        self.assertEqual(img.size, (1094, 582))

    def test_unknown_style(self):
        with self.assertRaises(KeyError):
            lr.render_table(lr.SAMPLE_MODEL, "nope", 1)

    def test_header_is_black_and_bands_are_coloured(self):
        img = self.images["light"]
        self.assertEqual(img.getpixel((5, 5)), (0, 0, 0))
        self.assertNotEqual(img.getpixel((1600, 260)), (0, 0, 0))

    def test_watermark_is_off_by_default_and_only_touches_header(self):
        plain = lr.render_table(lr.SAMPLE_MODEL, "light", 2)
        diff = ImageChops.difference(plain, self.images["light"]).getbbox()
        self.assertIsNotNone(diff)                                   # 透かしあり/なしで違いが出る
        self.assertLessEqual(diff[3], 80)                            # 変わるのはヘッダー (高さ40 x 倍率2) だけ
        self.assertGreater(diff[0], 1800)                            # 右端

    def test_polka_dots_present(self):
        img = self.images["light"]
        best = 0
        for y in range(90, 160, 2):                                # 水玉の周期 (論理 10px) より広い範囲で見る
            row = [img.getpixel((x, y))[2] for x in range(1580, 1660)]
            best = max(best, max(row) - min(row))
        self.assertGreater(best, 20)

    def test_sample_cli(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(lr.main(["--sample", d, "--scale", "1", "--styles", "dark,mku"]), 0)
            names = sorted(p.name for p in Path(d).iterdir())
            self.assertEqual(names, ["sample_dark.png", "sample_mku.png"])
            with Image.open(Path(d) / "sample_dark.png") as im:
                self.assertEqual(im.size, (1094, 582))


class TestEdgeCases(unittest.TestCase):
    def test_every_case_renders_with_expected_size(self):
        for name, case in CASES.items():
            for key in ("light@1", "atlasLeague@2"):
                style, scale = key.split("@")
                img = lr.render_table(case["model"], style, int(scale))
                self.assertEqual(img.size, tuple(case["js"]["sizes"][key]), f"{name} {key}")

    def _two_players(self, flag2):
        return {"title": "F", "date": "2026-11-04", "teams": [{"tag": "T", "players": [
            {"name": "a", "flag": "jp", "scores": [10]}, {"name": "b", "flag": flag2, "scores": [5]}]}]}

    def test_invalid_flag_code_draws_nothing_but_keeps_column(self):
        none = lr.render_table(self._two_players(None), "light", 1)
        bad = lr.render_table(self._two_players("a.b"), "light", 1)
        self.assertEqual(none.size, bad.size)
        self.assertIsNone(ImageChops.difference(none, bad).getbbox())

    def test_missing_flag_file_shows_grey_box_with_code(self):
        missing = lr.render_table(self._two_players("zz"), "light", 1)
        bad = lr.render_table(self._two_players("a.b"), "light", 1)
        grey = lambda im: dict((c, n) for n, c in im.getcolors(maxcolors=1 << 20)).get((85, 85, 85), 0)
        self.assertGreater(grey(missing) - grey(bad), 100)             # #555 の箱ぶんだけ増える

    def test_no_players_with_flags_means_no_flag_column(self):
        with_flag = lr.render_table(self._two_players("jp"), "light", 1)
        no_flag = lr.render_table({"teams": [{"tag": "T", "players": [
            {"name": "a", "scores": [10]}, {"name": "b", "scores": [5]}]}]}, "light", 1)
        self.assertEqual(with_flag.size[0] - no_flag.size[0], 54)

    def test_medal_falls_back_to_text_when_image_is_missing(self):
        orig = lr._Canvas._image
        with mock.patch.object(lr._Canvas, "_image",
                               lambda self, rel: None if rel.startswith("ranking") else orig(self, rel)):
            img = lr.render_table(lr.SAMPLE_MODEL, "light", 1)
        normal = lr.render_table(lr.SAMPLE_MODEL, "light", 1)
        self.assertEqual(img.size, normal.size)
        self.assertIsNotNone(ImageChops.difference(img, normal).getbbox())

    def test_long_text_is_squeezed_to_max_width(self):
        cv = lr._Canvas(600, 120, 2, lr.default_assets_dir())
        cv.im.paste((0, 0, 0, 255), (0, 0, 600, 120))
        cv.text("This is a very long text that cannot fit", 150, 30, 100, 20, (255, 255, 255, 255),
                {"name": "Roboto", "weight": 900})
        box = cv.im.convert("L").point(lambda v: 255 if v > 128 else 0).getbbox()
        self.assertLessEqual(box[2] - box[0], 100 * 2 + 4)             # 最大幅 100 (論理) = 200 px 以内
        self.assertGreater(box[2] - box[0], 150)                       # 縮めてもほぼ最大幅いっぱいまで使う

    def test_text_fom_no_longer_squeezes_long_text(self):
        """更新後の text() は最大幅で縮めない (Charlie がはみ出すのが正しい挙動)。"""
        cv = lr._Canvas(900, 140, 2, lr.default_assets_dir())
        cv.im.paste((0, 0, 0, 255), (0, 0, 900, 140))
        cv.text_fom("This is a very long text that cannot fit", 225, 40, 100, 20,
                    (255, 255, 255, 255), {"name": "Roboto", "weight": 900})
        box = cv.im.convert("L").point(lambda v: 255 if v > 128 else 0).getbbox()
        self.assertGreater(box[2] - box[0], (100 - 10) * 2 * 2)        # 最大幅 (w-10) x k を超えて描く

    def test_rubik_text_is_scaled_horizontally_by_078(self):
        def ink_width(x_scale):
            cv = lr._Canvas(900, 140, 2, lr.default_assets_dir())
            cv.im.paste((0, 0, 0, 255), (0, 0, 900, 140))
            cv.text("2025 1234", 225, 40, None, 30, (255, 255, 255, 255),
                    {"name": "Rubik Mono One", "weight": 400}, x_scale=x_scale)
            box = cv.im.convert("L").point(lambda v: 255 if v > 128 else 0).getbbox()
            return box[2] - box[0]
        ratio = ink_width(lr.RUBIK_X_SCALE) / ink_width(1.0)
        self.assertAlmostEqual(ratio, 0.78, delta=0.03)

    def test_score_fonts_are_rubik_regular_in_every_style(self):
        for key, st in lr.STYLES.items():
            for f in ("playerScoreFont", "teamScoreFont"):
                self.assertEqual(st[f], {"name": "Rubik Mono One", "weight": 400}, f"{key}.{f}")

    def test_rubik_digits_are_narrower_than_unscaled(self):
        """text_fom 経由 (= JS の text()) では Rubik だけ 0.78 倍になり、Roboto は等倍のまま。"""
        calls = []
        orig = lr._Canvas.text
        def spy(self, *a, **k):
            calls.append((a[6]["name"], k.get("x_scale", 1.0)))
            return orig(self, *a, **k)
        with mock.patch.object(lr._Canvas, "text", spy):
            lr.render_table(lr.SAMPLE_MODEL, "dark", 1)
        self.assertIn(("Rubik Mono One", lr.RUBIK_X_SCALE), calls)
        self.assertTrue(all(xs == 1.0 for name, xs in calls if name != "Rubik Mono One"))

    def test_japanese_uses_fallback_font(self):
        chain = lr._library(lr.default_assets_dir()).chain("Roboto", 900)
        self.assertTrue(chain[0].covers("A"))
        self.assertFalse(chain[0].covers("あ"))
        self.assertTrue(chain[1].covers("あ"))
        self.assertFalse(chain[0].covers("◇"))                          # 記号も日本語フォントで描く

    def test_fake_bold_only_for_rubik(self):
        lib = lr._library(lr.default_assets_dir())
        self.assertTrue(lib.chain("Rubik Mono One", 900)[0].fake_bold)
        self.assertFalse(lib.chain("Rubik Mono One", 400)[0].fake_bold)
        self.assertFalse(lib.chain("Roboto", 900)[0].fake_bold)

    def test_hidden_parts(self):
        full = lr.render_table(lr.SAMPLE_MODEL, "dark", 1)
        for key in ("hide_team_names", "hide_team_scores", "hide_player_scores"):
            img = lr.render_table({**lr.SAMPLE_MODEL, key: True}, "dark", 1)
            self.assertIsNotNone(ImageChops.difference(full.resize(img.size), img).getbbox(), key)

    def test_many_players_and_teams(self):
        teams = [{"tag": f"T{i}", "players": [{"name": f"p{i}{j}", "flag": "jp", "scores": [i + j, 3 * j]}
                                              for j in range(3)]} for i in range(4)]
        img = lr.render_table({"title": "big", "teams": teams}, "light", 1)
        self.assertGreater(img.size[1], 400)


class TestMissingAssets(unittest.TestCase):
    def test_check_assets_lists_what_is_missing(self):
        with tempfile.TemporaryDirectory() as d:
            missing = lr.check_assets(d)
            self.assertIn("fonts/Roboto[wdth,wght].ttf", missing)
            self.assertIn("fonts/RubikMonoOne-Regular.ttf", missing)
            self.assertIn("fonts/NotoSansJP[wght].ttf", missing)
            self.assertIn("ranking1.png", missing)
        self.assertEqual(lr.check_assets(), [])                        # 同梱の assets は全部そろっている

    def test_renders_with_fallback_fonts_when_assets_are_missing(self):
        with tempfile.TemporaryDirectory() as d:
            img = lr.render_table(lr.SAMPLE_MODEL, "dark", 1, True, "", assets_dir=d)
            self.assertEqual(img.size, (1094, 582))
            warnings = lr.font_warnings(d)
            self.assertTrue(any("Roboto" in w for w in warnings), warnings)



class TestLayoutInternalsMatchJs(unittest.TestCase):
    """名前の幅から決まるレイアウト (compactNames / pnW / psW / tsW2 …) が、JS の値と一致すること"""

    def test_internals_for_every_case_and_style(self):
        checked = 0
        for name, case in CASES.items():
            ex = lr.expand(case["model"])
            for style, jl in case["js"]["layout"].items():
                L = lr.compute_layout(ex, lr.resolve_style(style), True)
                pairs = (("W", L["W"], jl["W"]), ("nmW", L["nm_w"], jl["nmW"]), ("pnW", L["pn_w"], jl["pnW"]),
                         ("psW", L["ps_w"], jl["psW"]), ("tsW2", L["ts_w2"], jl["tsW2"]),
                         ("plW", L["pl_w"], jl["plW"]), ("nameExtraW", L["name_extra_w"], jl["nameExtraW"]),
                         ("baseTsW2", L["base_ts_w2"], jl["baseTsW2"]))
                for label, py, js in pairs:
                    self.assertAlmostEqual(py, js, delta=0.6, msg=f"{name}/{style}/{label}")
                self.assertAlmostEqual(L["widest_name"], jl["widestPlayerName"], delta=0.8, msg=f"{name}/{style}")
                self.assertEqual(bool(L["compact_names"]), bool(jl["compactNames"]), f"{name}/{style}")
                checked += 1
        self.assertGreaterEqual(checked, 50)

    def test_measure_text_is_close_to_canvas_measuretext(self):
        for name, case in CASES.items():
            ex = lr.expand(case["model"])
            jl = case["js"]["layout"]["dark"]
            if jl["widestPlayerName"] > 0:
                L = lr.compute_layout(ex, lr.STYLES["dark"], True)
                self.assertAlmostEqual(L["widest_name"], jl["widestPlayerName"], delta=0.8, msg=name)

    def test_short_names_compact_the_name_cell_and_widen_the_score_columns(self):
        ex = lr.expand(CASES["names_short"]["model"])
        L = lr.compute_layout(ex, lr.STYLES["dark"], True)
        self.assertTrue(L["compact_names"])
        self.assertEqual(L["pn_w"], 152)                                  # 名前のセルは 152 に広がる
        self.assertGreater(L["ps_w"], L["ps_base_w"])                     # 余った幅はスコア列へ
        plain = lr.compute_layout(ex, lr.STYLES["dark"], True)
        self.assertEqual(plain["W"], L["W"])

    def test_very_long_names_leave_no_slack(self):
        ex = lr.expand(CASES["names_very_long"]["model"])
        L = lr.compute_layout(ex, lr.STYLES["dark"], True)
        self.assertEqual(L["ps_w"], L["ps_base_w"])                       # 詰められないのでスコア列は広がらない
        self.assertEqual(L["pn_w"], 152)

    def test_compact_layout_is_off_when_scores_or_team_scores_are_hidden(self):
        base = CASES["sample"]["model"]
        for key in ("hide_player_scores", "hide_team_scores", "hide_team_names"):
            L = lr.compute_layout(lr.expand({**base, key: True}), lr.STYLES["dark"], True)
            self.assertEqual(bool(L["compact_names"]), key == "hide_team_names", key)

    def test_width_is_the_same_whatever_the_names(self):
        sample = lr.compute_layout(lr.expand(CASES["sample"]["model"]), lr.STYLES["dark"], True)["W"]
        self.assertEqual(sample, 1094)


class TestFitWidth(unittest.TestCase):
    """JS の text(..., fitWidth): チームのタグ・チーム名・選手名だけ、max(0, w-10) に収まるよう横に縮める"""

    @staticmethod
    def _ink_width(draw, font=None):
        cv = lr._Canvas(1200, 160, 2, lr.default_assets_dir())
        cv.im.paste((0, 0, 0, 255), (0, 0, 1200, 160))
        draw(cv, font or {"name": "Roboto", "weight": 900})
        box = cv.im.convert("L").point(lambda v: 255 if v > 128 else 0).getbbox()
        return 0 if box is None else box[2] - box[0]

    LONG = "This is a very long text that cannot fit"

    def test_fit_true_squeezes_to_w_minus_10(self):
        width = self._ink_width(lambda cv, f: cv.text_fom(self.LONG, 300, 40, 150, 24, (255, 255, 255, 255), f, fit=True))
        self.assertLessEqual(width, (150 - 10) * 2 + 4)
        self.assertGreater(width, (150 - 10) * 2 - 12)                    # 縮めたあとは、ほぼ最大幅いっぱい

    def test_fit_false_does_not_squeeze(self):
        width = self._ink_width(lambda cv, f: cv.text_fom(self.LONG, 300, 40, 150, 24, (255, 255, 255, 255), f))
        self.assertGreater(width, (150 - 10) * 2 * 1.5)

    def test_short_text_is_not_stretched(self):
        a = self._ink_width(lambda cv, f: cv.text_fom("Al", 300, 40, 400, 24, (255, 255, 255, 255), f, fit=True))
        b = self._ink_width(lambda cv, f: cv.text_fom("Al", 300, 40, 400, 24, (255, 255, 255, 255), f))
        self.assertEqual(a, b)

    def test_nothing_is_drawn_when_the_max_width_is_zero_or_less(self):
        for w in (10, 5, 0, -20):
            width = self._ink_width(lambda cv, f: cv.text_fom("Hello", 300, 40, w, 24, (255, 255, 255, 255), f, fit=True))
            self.assertEqual(width, 0, w)
        self.assertEqual(self._ink_width(lambda cv, f: cv.text("Hello", 300, 40, 0, 24, (255, 255, 255, 255), f)), 0)

    def test_rubik_is_measured_in_the_scaled_coordinates(self):
        rubik = {"name": "Rubik Mono One", "weight": 400}
        width = self._ink_width(lambda cv, f: cv.text_fom("12345678901234", 300, 40, 150, 30, (255, 255, 255, 255), f, fit=True), rubik)
        self.assertLessEqual(width, (150 - 10) * 2 + 4)                   # 画面上の幅が w-10 に収まる

    def test_which_texts_use_fit_width(self):
        """fit=True にするのは、チームのタグ・チーム名・選手名だけ (スコア・±・ヘッダー・順位は縮めない)。"""
        calls = []
        orig = lr._Canvas.text_fom
        def spy(self, s, *a, **k):
            calls.append((s, k.get("fit", False)))
            return orig(self, s, *a, **k)
        with mock.patch.object(lr._Canvas, "text_fom", spy):
            lr.render_table(lr.SAMPLE_MODEL, "dark", 1)
        fit = {s for s, f in calls if f}
        self.assertTrue({"Alpha", "Team Alpha", "Bravo", "Charlie", "Ren", "Sam", "Aki"} <= fit)
        self.assertTrue(all(not f for s, f in calls if s in ("313", "272", "250", "28", "94", "Mogi 12v12 Finals    •    4 Nov 2026")))

    def test_atlas_league_no_longer_has_a_title(self):
        self.assertEqual(lr.STYLES["atlasLeague"]["title"], "")
        self.assertEqual(lr.STYLES["mku"]["title"], "Mario Kart Universal")


class TestMixedNamesMatchChrome(unittest.TestCase):
    """名前の長さがばらばらの表 (短い / 中くらい / 非常に長い / 日本語 / 長いチーム名) を Chrome と比べる"""

    @classmethod
    def setUpClass(cls):
        cls.model = json.loads((DATA / "names_case_model.json").read_text(encoding="utf-8"))
        cls.chrome = Image.open(DATA / "chrome_names_sandbox.png").convert("RGB")
        cls.ours = lr.render_table(cls.model, "light", 2)
        cls.ex = lr.expand(cls.model)
        cls.L = lr.compute_layout(cls.ex, lr.STYLES["light"], True)

    @staticmethod
    def _extent(im, x0, y0, x1, y1, thr=70):
        c = im.convert("L").crop((x0, y0, x1, y1)).point(lambda v: 255 if v < thr else 0)
        box = c.getbbox()
        return None if box is None else (x0 + box[0], x0 + box[2] - 1)

    def test_images_have_the_same_size(self):
        self.assertEqual(self.chrome.size, self.ours.size)

    def test_every_player_name_is_at_the_same_horizontal_position(self):
        L, sc = self.L, 2
        px = L["rk_w"] + L["nm_w"]
        checked = 0
        for g, team in zip(L["T"], self.ex["teams"]):
            for i, p in enumerate(team["players"]):
                cy = (g["y"] + 10 + g["tp"] / 2 + i * 38 + 17) * sc
                x0, x1 = int(px * sc), int((px + L["pn_w"]) * sc)
                a = self._extent(self.chrome, x0, int(cy - 32), x1, int(cy + 32))
                b = self._extent(self.ours, x0, int(cy - 26), x1, int(cy + 26))
                self.assertIsNotNone(a, p["name"])
                self.assertIsNotNone(b, p["name"])
                self.assertLessEqual(abs(a[0] - b[0]), 3, f"{p['name']}: {a} vs {b}")
                self.assertLessEqual(abs(a[1] - b[1]), 3, f"{p['name']}: {a} vs {b}")
                checked += 1
        self.assertEqual(checked, 7)

    def test_team_tag_and_team_name_are_squeezed_the_same_way(self):
        L, sc = self.L, 2
        x0, x1 = int(L["rk_w"] * sc), int((L["rk_w"] + L["nm_w"]) * sc)
        for g in L["T"]:
            y0, y1 = int(g["y"] * sc), int((g["y"] + g["h"]) * sc)
            a = self._extent(self.chrome, x0, y0 + 4, x1, y1 - 4)
            b = self._extent(self.ours, x0, y0 + 4, x1, y1 - 4)
            self.assertIsNotNone(a)
            self.assertIsNotNone(b)
            self.assertLessEqual(abs(a[0] - b[0]), 4, f"{a} vs {b}")
            self.assertLessEqual(abs(a[1] - b[1]), 4, f"{a} vs {b}")

    def test_very_long_name_is_squeezed_into_the_name_cell(self):
        L, sc = self.L, 2
        px = L["rk_w"] + L["nm_w"]
        g = L["T"][0]
        cy = (g["y"] + 10 + g["tp"] / 2 + 3 * 38 + 17) * sc            # 4人目 (非常に長い名前)
        a = self._extent(self.ours, int(px * sc), int(cy - 26), int((px + L["pn_w"]) * sc), int(cy + 26))
        self.assertLessEqual(a[1] - a[0], (L["pn_w"] - 14) * sc + 4)    # 縮めて max(0, pnW-4-10) に収まる



def _ink_color(im, box, threshold=110):
    """範囲内の「文字の色」(背景より十分明るい画素) の平均を返す。"""
    data = im.convert("RGB").crop(box).tobytes()
    px = [(data[i], data[i + 1], data[i + 2]) for i in range(0, len(data), 3)]
    sel = [p for p in px if max(p) > threshold]
    if len(sel) < 50:
        return None
    return tuple(round(sum(p[c] for p in sel) / len(sel)) for c in range(3))


class TestGradientOnRubikText(unittest.TestCase):
    """Canvas のグラデーションは「塗る時点の座標系」で解釈される。Rubik Mono One のスコアは translate してから
    描くので、グラデーションも一緒にずれ、文字の位置ではほぼ最初の色になる (Chrome の出力で確認)。"""

    # Chrome 153 で描いたサンプル (倍率2) の、チーム合計の数字の平均色 (チームの順: Alpha, Bravo, Charlie)
    CHROME_SCORE_COLORS = {
        "dark": [(55, 181, 239), (226, 70, 153), (77, 189, 240)],
        "darkThin": [(55, 181, 239), (225, 68, 152), (74, 188, 239)],
        "atlasLeague": [(103, 194, 232), (175, 221, 225), (105, 195, 233)],
    }

    def test_team_score_colours_match_chrome(self):
        ex = lr.expand(lr.SAMPLE_MODEL)
        for style, expected in self.CHROME_SCORE_COLORS.items():
            L = lr.compute_layout(ex, lr.STYLES[style], True)
            img = lr.render_table(lr.SAMPLE_MODEL, style, 2)
            sx = (L["W"] - L["ts_w2"]) * 2
            for g, want in zip(L["T"], expected):
                box = (int(sx), int(g["y"] * 2 + 14), int(L["W"] * 2) - 10, int((g["y"] + g["h"]) * 2 - 30))
                got = _ink_color(img, box)
                self.assertIsNotNone(got, style)
                for a, b in zip(got, want):
                    self.assertLessEqual(abs(a - b), 4, f"{style}: {got} vs Chrome {want}")

    def _draw(self, font):
        cv = lr._Canvas(500, 220, 2, lr.default_assets_dir())
        cv.im.paste((17, 17, 17, 255), (0, 0, 500, 220))
        grad = lr._Gradient(["#ff0000", "#0000ff"], 40, 100)             # 帯: y=40〜140、赤 → 青
        cv.text_fom("1234", 125, 90, 200, 40, grad, font)                # 文字の中心は y=90 (帯の真ん中)
        return _ink_color(cv.im, (0, 0, 500, 220), 80)

    def test_rubik_text_takes_the_first_gradient_colour(self):
        r, g, b = self._draw({"name": "Rubik Mono One", "weight": 400})
        self.assertGreater(r, 200)                                       # ほぼ赤 (最初の色)
        self.assertLess(b, 60)

    def test_roboto_text_uses_the_real_gradient_position(self):
        r, g, b = self._draw({"name": "Roboto", "weight": 900})
        self.assertAlmostEqual(r, b, delta=60)                           # 帯の真ん中 = 赤と青の中間 (紫)
        self.assertGreater(r, 90)
        self.assertGreater(b, 90)

    def test_shifted_gradient(self):
        g = lr._Gradient(["#000000", "#ff0000"], 100, 50)
        h = g.shifted(30)
        self.assertEqual((h.y0, h.h), (130, 50))
        self.assertEqual(h.color_at(130), g.color_at(100))
        self.assertEqual(g.y0, 100)                                      # 元のグラデーションは変えない


if __name__ == "__main__":
    unittest.main(verbosity=2)
