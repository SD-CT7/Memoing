#!/usr/bin/env python3
"""leaderboard.py のテスト (実行: python test_leaderboard.py)  ※ APIは使いません"""
import tempfile
import unittest
from pathlib import Path

from PIL import Image

from leaderboard import (HEADER_H, MAX_RACES, W, build_board, ordinal, render_board,
                         save_png_atomic, write_leaderboard)


def make_player(name, team, per_race_points, ranks=None):
    per = {}
    for i, pts in enumerate(per_race_points, 1):
        if pts is not None:
            per[str(i)] = {"rank": (ranks or [0] * 99)[i - 1], "points": pts, "tag": team}
    return {"name": name, "points": sum(p for p in per_race_points if p), "races": len(per),
            "per_race": per, "team": team}


def make_races(n, tags=("A", "B", "C", "D"), team_points=None):
    races = []
    for i in range(1, n + 1):
        rows = [{"rank": k + 1, "text": f"p{k}", "tag": t, "points": pts}
                for k, (t, pts) in enumerate(team_points or [("A", 10), ("B", 8)])]
        races.append({"seq": i, "status": "added", "tags": list(tags), "rows": rows})
    return races


def report_of(players):
    return {"players": sorted(players, key=lambda p: -p["points"]), "issues": [], "races": []}


class TestBuildBoard(unittest.TestCase):
    def test_teams_sorted_by_total_with_stable_colors(self):
        races = make_races(2, team_points=[("A", 5), ("B", 13), ("C", 10)])
        players = [make_player("a1", "A", [5, 5]), make_player("b1", "B", [13, 13]),
                   make_player("c1", "C", [10, 10])]
        board = build_board(races, report_of(players))
        self.assertEqual([t["tag"] for t in board["teams"]], ["B", "C", "A"])   # 合計の多い順
        self.assertEqual([t["total"] for t in board["teams"]], [26, 20, 10])
        # 色はタグの並び (A,B,C,D) で固定: 順位が変わっても A は 0 のまま
        self.assertEqual({t["tag"]: t["color_index"] for t in board["teams"]},
                         {"A": 0, "B": 1, "C": 2})

    def test_team_total_includes_players_not_in_roster(self):
        races = make_races(1, team_points=[("A", 10), ("A", 8), ("B", 6)])
        board = build_board(races, report_of([make_player("a1", "A", [10])]))
        totals = {t["tag"]: t["total"] for t in board["teams"]}
        self.assertEqual(totals, {"A": 18, "B": 6})            # 名簿に無い人の分も含む
        self.assertEqual([t["players"] for t in board["teams"] if t["tag"] == "B"], [[]])

    def test_tied_players_share_place(self):
        races = make_races(1)
        players = [make_player("x", "A", [10]), make_player("y", "B", [10]),
                   make_player("z", "A", [5])]
        board = build_board(races, report_of(players))
        places = {pl["name"]: pl["place"]
                  for t in board["teams"] for pl in t["players"]}
        self.assertEqual(places, {"x": 1, "y": 1, "z": 3})

    def test_players_without_team_go_to_others(self):
        races = make_races(1)
        board = build_board(races, report_of([make_player("nobody", None, [3])]))
        self.assertEqual([p["name"] for p in board["others"]], ["nobody"])

    def test_only_last_12_races_are_columns(self):
        races = make_races(15)
        players = [make_player("a1", "A", [1] * 15)]
        board = build_board(races, report_of(players))
        self.assertEqual(board["race_count"], MAX_RACES)
        self.assertEqual(board["races_total"], 15)
        self.assertEqual(len(board["teams"][0]["players"][0]["per_race"]), MAX_RACES)
        self.assertEqual(board["teams"][0]["players"][0]["total"], 15)   # 合計は全レース分

    def test_missing_race_is_none(self):
        races = make_races(3)
        board = build_board(races, report_of([make_player("a1", "A", [10, None, 10])]))
        self.assertEqual(board["teams"][0]["players"][0]["per_race"], [10, None, 10])

    def test_ordinal(self):
        self.assertEqual([ordinal(n) for n in (1, 2, 3, 4, 11, 12, 13, 21, 22)],
                         ["1st", "2nd", "3rd", "4th", "11th", "12th", "13th", "21st", "22nd"])


class TestRender(unittest.TestCase):
    def _board(self, n_races=3, n_players=4, long_name=False):
        races = make_races(n_races)
        players = [make_player(("very long player name " * 3 if long_name and i == 0 else f"p{i}"),
                               "A" if i % 2 == 0 else "B", [i + 1] * n_races)
                   for i in range(n_players)]
        return build_board(races, report_of(players))

    def test_basic_image(self):
        img = render_board(self._board(), "Title", "6 Nov 2026")
        self.assertEqual(img.size[0], W)
        self.assertEqual(img.mode, "RGB")
        self.assertEqual(img.getpixel((5, 5)), (0, 0, 0))               # ヘッダーは黒
        self.assertNotEqual(img.getpixel((5, HEADER_H + 60)), (0, 0, 0))  # 帯には色がある

    def test_height_grows_with_players(self):
        small = render_board(self._board(n_players=2)).size[1]
        big = render_board(self._board(n_players=12)).size[1]
        self.assertGreater(big, small)

    def test_edge_cases_do_not_crash(self):
        empty = build_board([], {"players": [], "issues": []})
        self.assertGreater(render_board(empty).size[1], HEADER_H)         # "No data yet"
        for n in (0, 1, 12, 15):
            render_board(self._board(n_races=max(n, 1) if n else 1))
        render_board(self._board(long_name=True))
        render_board(self._board(n_players=12))

    def test_write_to_multiple_paths_atomically(self):
        with tempfile.TemporaryDirectory() as d:
            a, b = Path(d) / "x" / "leaderboard.png", Path(d) / "latest.png"
            races = make_races(2)
            report = report_of([make_player("a1", "A", [10, 10])])
            write_leaderboard(races, report, [a, b], "T", "S")
            for p in (a, b):
                with Image.open(p) as im:
                    self.assertEqual(im.size[0], W)
            self.assertEqual(list(Path(d).rglob("*.tmp")), [])
            write_leaderboard(races, report, [b], "T2", "S")                # 上書きできる
            self.assertTrue(b.is_file())

    def test_save_png_atomic_creates_folder(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "a" / "b" / "c.png"
            save_png_atomic(Image.new("RGB", (4, 4)), p)
            self.assertTrue(p.is_file())


if __name__ == "__main__":
    unittest.main(verbosity=2)
