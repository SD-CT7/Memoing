#!/usr/bin/env python3
"""
races_window.py -- 過去レースの読み取り結果を手で直す画面 (画面のみ)
====================================================================
左: 読み取り済みのレース一覧 / 右: そのレースの画像
下: 名前の編集欄 (1行目 = 1位)。SAVE で保存して再集計する。

  * 読み間違いは、その行の文字を直す
  * 順位が違うときは、行を上下に入れ替える
  * 余分な行は削除、読み落とした行は挿入する
  * 名前が分からないプレイヤーは空行にする (順位は数えられる)

集計・保存は本体 (score_app_v3.py) が行う。この画面は入力と表示だけを担当する。
"""

import tkinter as tk

from PIL import Image, ImageTk

from race_log import parse_names_text

_FONT = ("Consolas", 9)
_PREVIEW_MAX = (300, 260)


class RacesWindow(tk.Toplevel):
    def __init__(self, master, theme, list_races, load_race, save_race,
                 revert_race, on_close):
        """
        theme                        {"bg","bg2","fg","fg2","btnb","btnf"}
        list_races()  -> [{"seq","status","time","rows","edited"}]
        load_race(seq) -> {"names":[...], "counted":bool, "image":path|None, "info":str}
        save_race(seq, names, counted) -> 結果の説明文 (str)
        revert_race(seq) -> 結果の説明文 (str)
        on_close()                   画面を閉じたときに呼ぶ
        """
        super().__init__(master)
        self._t = theme
        self._list = list_races
        self._load = load_race
        self._save_cb = save_race
        self._revert_cb = revert_race
        self._on_close = on_close
        self._seqs = []
        self._photo = None

        self.title("Edit races")
        self.configure(bg=theme["bg"])
        self.geometry("760x700")

        top = tk.Frame(self, bg=theme["bg"])
        top.pack(fill="x", padx=14, pady=(12, 4))

        left = tk.Frame(top, bg=theme["bg"])
        left.pack(side="left", fill="y")
        self._label(left, "RACES", bold=True, color=theme["fg"]).pack(anchor="w")
        self.lst = tk.Listbox(left, width=34, height=14, bg=theme["bg2"], fg=theme["fg"],
                              font=_FONT, relief="flat", exportselection=False,
                              selectbackground="#555555")
        self.lst.pack(side="left", fill="y")
        self.lst.bind("<<ListboxSelect>>", self._on_select)

        right = tk.Frame(top, bg=theme["bg"])
        right.pack(side="left", fill="both", expand=True, padx=(14, 0))
        self._label(right, "IMAGE", bold=True, color=theme["fg"]).pack(anchor="w")
        self.lbl_img = tk.Label(right, bg=theme["bg2"], fg=theme["fg2"], text="(select a race)")
        self.lbl_img.pack(fill="both", expand=True)

        self._label(self, "PLAYER NAMES IN RANK ORDER  (1st line = 1st place)",
                    bold=True, color=theme["fg"]).pack(anchor="w", padx=14, pady=(8, 0))
        self._label(self, "Fix a misread name / move lines to change ranks / delete or insert "
                          "lines. A blank line = unknown player (keeps the rank).",
                    size=8).pack(anchor="w", padx=14)
        self.txt_names = tk.Text(self, height=10, bg=theme["bg2"], fg=theme["fg"],
                                 insertbackground=theme["fg"], font=_FONT, relief="flat")
        self.txt_names.pack(fill="x", padx=14, pady=4)

        row = tk.Frame(self, bg=theme["bg"])
        row.pack(pady=2)
        self.var_counted = tk.BooleanVar(value=True)
        tk.Checkbutton(row, text="Count this race", variable=self.var_counted,
                       bg=theme["bg"], fg=theme["fg"], selectcolor=theme["bg2"],
                       activebackground=theme["bg"], activeforeground=theme["fg"],
                       font=_FONT).pack(side="left", padx=8)
        self._button(row, "SAVE", self._save).pack(side="left", padx=6)
        self._button(row, "REVERT TO ORIGINAL", self._revert).pack(side="left", padx=6)

        self.var_info = tk.StringVar(value="")
        tk.Label(self, textvariable=self.var_info, bg=theme["bg"], fg=theme["fg2"],
                 font=("Consolas", 8), wraplength=720, justify="left"
                 ).pack(anchor="w", padx=14, pady=2)

        self._label(self, "RESULT", bold=True, color=theme["fg"]).pack(anchor="w", padx=14, pady=(6, 0))
        self.txt_out = tk.Text(self, height=9, bg=theme["bg2"], fg=theme["fg"],
                               font=_FONT, relief="flat", state="disabled")
        self.txt_out.pack(fill="both", expand=True, padx=14, pady=(2, 12))

        self.protocol("WM_DELETE_WINDOW", self._close)
        self.refresh_list()

    # ── 部品 ──────────────────────────────────
    def _label(self, parent, text, size=9, bold=False, color=None):
        return tk.Label(parent, text=text, bg=self._t["bg"], fg=color or self._t["fg2"],
                        font=("Consolas", size, "bold" if bold else "normal"))

    def _button(self, parent, text, cmd):
        return tk.Button(parent, text=text, command=cmd, bg=self._t["btnb"],
                         fg=self._t["btnf"], activebackground="#555555",
                         font=("Consolas", 9, "bold"), relief="flat",
                         padx=8, pady=4, cursor="hand2")

    # ── 一覧 ──────────────────────────────────
    def refresh_list(self, select=None):
        """一覧を読み直す。select にレース番号を渡すと、それを選び直す。"""
        races = self._list()
        self._seqs = [r["seq"] for r in races]
        self.lst.delete(0, "end")
        for r in races:
            mark = "*" if r.get("edited") else " "
            state = "ok " if r["status"] == "added" else "off"
            self.lst.insert("end", f"{r['seq']:02d} {state}{mark} {r.get('time', '')}  {r['rows']} rows")
        if not races:
            self._clear_view()
            self.var_info.set("No race to edit yet.")
            return
        if select in self._seqs:
            idx = self._seqs.index(select)
            self.lst.selection_clear(0, "end")
            self.lst.selection_set(idx)
            self._show(select)

    def _selected_seq(self):
        sel = self.lst.curselection()
        if not sel or sel[0] >= len(self._seqs):
            return None
        return self._seqs[sel[0]]

    def _on_select(self, _event=None):
        seq = self._selected_seq()
        if seq is not None:
            self._show(seq)

    # ── 表示 ──────────────────────────────────
    def _clear_view(self):
        self.lbl_img.config(image="", text="(select a race)")
        self._photo = None
        self.txt_names.delete("1.0", "end")
        self.set_output("")

    def _show(self, seq):
        data = self._load(seq)
        if not data:
            self.var_info.set(f"race {seq} could not be loaded.")
            return
        self.txt_names.delete("1.0", "end")
        self.txt_names.insert("1.0", "\n".join(data["names"]))
        self.var_counted.set(bool(data["counted"]))
        self.var_info.set(data.get("info", ""))
        self.set_output("")
        self._show_image(data.get("image"))

    def _show_image(self, path):
        try:
            img = Image.open(path).convert("RGB")
            img.thumbnail(_PREVIEW_MAX, Image.LANCZOS)
            self._photo = ImageTk.PhotoImage(img)
            self.lbl_img.config(image=self._photo, text="")
        except Exception:
            self._photo = None
            self.lbl_img.config(image="", text="(image not available)")

    def set_output(self, text):
        self.txt_out.config(state="normal")
        self.txt_out.delete("1.0", "end")
        self.txt_out.insert("end", text)
        self.txt_out.config(state="disabled")

    # ── 操作 ──────────────────────────────────
    def names(self):
        return parse_names_text(self.txt_names.get("1.0", "end"))

    def _save(self):
        seq = self._selected_seq()
        if seq is None:
            self.var_info.set("Select a race first.")
            return
        text = self._save_cb(seq, self.names(), bool(self.var_counted.get()))
        self.refresh_list(select=seq)
        self.set_output(text)

    def _revert(self):
        seq = self._selected_seq()
        if seq is None:
            self.var_info.set("Select a race first.")
            return
        text = self._revert_cb(seq)
        self.refresh_list(select=seq)
        self.set_output(text)

    def _close(self):
        self._on_close()
        self.destroy()
