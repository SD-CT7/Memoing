#!/usr/bin/env python3
"""
tag_match.py -- プレイヤー名の先頭部分から、チームのタグを判定する
=================================================================
* タグがすべて ASCII (A, B, East など) のときは、従来の判定 (_closest_tag_ascii) を
  そのまま使う。既存の動作は変わらない。
* 日本語など ASCII 以外を含むタグがあるときは、日本語対応の判定を使う。
    - 全角/半角の違い、大文字/小文字の違いを吸収 (NFKC + casefold)
    - ◇ ◆ ☆ ★ などの記号・空白・句読点は無視
    - カタカナ → ひらがな、小さい仮名 (ょ っ ゃ…) → 大きい仮名にそろえる
      (OCR で ょ/よ、カ/か などが揺れても一致させるため)
    - 3文字以上のタグは判定をやや厳しくする (タグのないプレイヤーを誤判定しないため)
"""

import re
import unicodedata
from difflib import SequenceMatcher

TAG_MAX_LEN = 8             # タグ入力の最大文字数 (従来は 4)
_THRESHOLD_SHORT = 0.4      # 1-2文字のタグ (従来どおり)
_THRESHOLD_LONG = 0.6       # 3文字以上のタグ

_SMALL_TO_LARGE = str.maketrans("ぁぃぅぇぉっゃゅょゎ", "あいうえおつやゆよわ")


def _closest_tag_ascii(text, tags):
    """従来の判定 (英数字のみで比較)。動作を変えないため元の実装のまま。"""
    clean = re.sub(r"[^a-zA-Z0-9]", "", text).upper()
    best_tag, best_score = None, 0.0
    for tag in tags:
        t = re.sub(r"[^a-zA-Z0-9]", "", tag).upper()
        n = len(t)
        if n == 0:
            continue
        candidate = clean[:max(n, 1)]
        score = SequenceMatcher(None, t, candidate[:n]).ratio()
        # 1文字タグは先頭1文字が含まれていれば高スコア
        if n == 1 and t in clean[:4]:
            score = max(score, 0.8)
        if score > best_score:
            best_score, best_tag = score, tag
    return best_tag if best_score >= 0.4 else None


def normalize(text):
    """比較用に正規化する: 文字(英数・かな・漢字)だけを残し、表記ゆれをそろえる。"""
    s = unicodedata.normalize("NFKC", text).casefold()
    s = "".join(ch for ch in s if unicodedata.category(ch)[0] in ("L", "N"))
    # カタカナ -> ひらがな
    s = "".join(chr(ord(ch) - 0x60) if "\u30a1" <= ch <= "\u30f6" else ch for ch in s)
    return s.translate(_SMALL_TO_LARGE)


def _closest_tag_unicode(text, tags):
    clean = normalize(text)
    best_tag, best_score = None, 0.0
    for tag in tags:
        t = normalize(tag)
        n = len(t)
        if n == 0:
            continue
        score = SequenceMatcher(None, t, clean[:n]).ratio()
        if n == 1 and t in clean[:4]:
            score = max(score, 0.8)
        threshold = _THRESHOLD_SHORT if n <= 2 else _THRESHOLD_LONG
        if score >= threshold and score > best_score:
            best_tag, best_score = tag, score
    return best_tag


def closest_tag(text, tags):
    """text (1行分の読み取り結果) に最も合うタグを返す。無ければ None。"""
    if all(t.isascii() for t in tags):
        return _closest_tag_ascii(text, tags)
    return _closest_tag_unicode(text, tags)
