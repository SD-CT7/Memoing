#!/usr/bin/env python3
"""
window_capture.py -- 他のウィンドウが上に重なっていても読み取るための補助 (Windows専用)
=====================================================================================
既定の方法 (screen) は「画面に表示されているピクセル」をそのまま撮るため、読み取りたい
ウィンドウの上に別のウィンドウが重なっていると、その別のウィンドウが写ってしまう。

MK7_WINDOW_CAPTURE (.env) で方法を選べる:
    screen       画面のピクセルを撮る (従来どおり。重なりには対応しない)
    printwindow  Windows の PrintWindow でウィンドウ自身に描画させる
                 (重なっていても撮れるが、アプリによっては真っ黒になる)
    raise        読み取りの直前に、そのウィンドウを最前面に出してから画面を撮る
                 (確実だが、一瞬ウィンドウが前に出る)

注意:
  * PrintWindow は「ウィンドウを所有するアプリが自分で描画して返す」仕組み
    (Microsoft Learn の PrintWindow のリファレンスより)。そのため描画内容は
    ゲーム画面を表示するアプリの実装次第で、真っ黒な画像が返ることがある。
    その場合はユニットを無駄にしないよう、OCR の前にエラーとして止める。
  * PW_RENDERFULLCONTENT (0x2) は公式リファレンスの表には載っていないが、
    広く使われているフラグ。失敗した場合は PW_CLIENTONLY だけでやり直す。
"""

import ctypes
import time
from ctypes import wintypes

from PIL import Image

PW_CLIENTONLY = 0x1
PW_RENDERFULLCONTENT = 0x2
RAISE_DELAY_SEC = 0.3        # 最前面に出してから描画されるまで待つ時間


class CaptureError(Exception):
    """ウィンドウの取得に失敗した"""


def is_blank(img, threshold=3):
    """ほぼ単色 (全黒など) の画像か。PrintWindow が描画できなかったことの検出に使う。"""
    lo, hi = img.convert("L").getextrema()
    return (hi - lo) <= threshold


def grab_printwindow(hwnd):
    """PrintWindow でクライアント領域を取得して PIL 画像で返す。"""
    import win32gui
    import win32ui

    left, top, right, bottom = win32gui.GetClientRect(hwnd)
    w, h = right - left, bottom - top
    if w <= 0 or h <= 0:
        raise CaptureError("window has no client area (minimized?)")

    user32 = ctypes.windll.user32
    user32.PrintWindow.argtypes = [wintypes.HWND, wintypes.HDC, wintypes.UINT]
    user32.PrintWindow.restype = wintypes.BOOL

    hwnd_dc = win32gui.GetWindowDC(hwnd)
    mfc_dc = win32ui.CreateDCFromHandle(hwnd_dc)
    save_dc = mfc_dc.CreateCompatibleDC()
    bmp = win32ui.CreateBitmap()
    try:
        bmp.CreateCompatibleBitmap(mfc_dc, w, h)
        save_dc.SelectObject(bmp)
        ok = user32.PrintWindow(hwnd, save_dc.GetSafeHdc(),
                                PW_CLIENTONLY | PW_RENDERFULLCONTENT)
        if not ok:
            ok = user32.PrintWindow(hwnd, save_dc.GetSafeHdc(), PW_CLIENTONLY)
        if not ok:
            raise CaptureError("PrintWindow failed")
        info = bmp.GetInfo()
        bits = bmp.GetBitmapBits(True)
        img = Image.frombuffer("RGB", (info["bmWidth"], info["bmHeight"]),
                               bits, "raw", "BGRX", 0, 1)
    finally:
        win32gui.DeleteObject(bmp.GetHandle())
        save_dc.DeleteDC()
        mfc_dc.DeleteDC()
        win32gui.ReleaseDC(hwnd, hwnd_dc)

    if is_blank(img):
        raise CaptureError(
            "PrintWindow returned a blank image (this window cannot be captured "
            "while covered). Set MK7_WINDOW_CAPTURE=raise or screen in .env")
    return img


def raise_window(hwnd):
    """ウィンドウを最前面に出す (最小化されていれば元に戻す)。失敗しても例外は出さない。"""
    import win32con
    import win32gui
    try:
        if win32gui.IsIconic(hwnd):
            win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
        win32gui.SetForegroundWindow(hwnd)
    except Exception:            # 権限などで失敗した場合は次善策
        try:
            win32gui.BringWindowToTop(hwnd)
        except Exception:
            pass
    time.sleep(RAISE_DELAY_SEC)
