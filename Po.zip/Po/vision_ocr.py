#!/usr/bin/env python3
"""
vision_ocr.py -- Google Cloud Vision API による OCR (EasyOCR の置き換え)
=====================================================================
* APIキーは環境変数 GOOGLE_VISION_API_KEY、または .env ファイルから読む。
  (ソースコードには書かない)
* 1回の OCR = 画像1枚 x 機能1つ = 1ユニット (公式の課金単位)。
  必ず「API を呼ぶ前」に usage_guard で予約し、上限なら送信しない。
* 利用量を記録できない / キーが無い場合も送信しない (安全側)。
* 送信後に失敗しても返金しない (失敗リクエストが課金されるか未確認のため保守的に扱う)。
* 戻り値は EasyOCR の readtext(detail=1) 互換 [(bbox, text, conf)]。
  座標は「4倍拡大画像」相当に正規化しているので score_app 側の ROW_MARGIN 等は
  そのまま使える。

設定 (環境変数 or .env, すべて任意):
    MK7_OCR_FEATURE   TEXT_DETECTION (既定) / DOCUMENT_TEXT_DETECTION
    MK7_OCR_HINTS     languageHints (既定 ja,en / 空で無指定)
    MK7_MONTHLY_LIMIT 月間上限ユニット (既定 1000)
    MK7_USAGE_DB      利用量DBの場所
    MK7_OCR_DEBUG_DIR 指定すると、送信画像とVision応答(JSON)をそのフォルダに保存する
                      (精度調査用。ユニットは消費しない)。window_half モードでは
                      切り抜き前の画像 last_client.png も保存する (calibrate_crop.py 用)
    MK7_CROP_LEFT / MK7_CROP_TOP / MK7_CROP_RIGHT / MK7_CROP_BOTTOM
                      window_half モードの切り抜き範囲 (クライアント領域に対する 0〜1 の比率)
    MK7_EXPECTED_ROWS 読み取り行数の期待値 (既定 8, 0 で警告なし)
    MK7_WINDOW_CAPTURE ウィンドウの撮り方 screen(既定) / printwindow / raise
                      (他のウィンドウが上に重なる場合の対策。window_capture.py 参照)

画像は拡大せず、そのまま送信する (検証で 2倍拡大は ◇ の取りこぼしが増えたため)。
"""

import base64
import io
import json
import os
import re
import statistics
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

from usage_guard import UsageGuard

API_URL = "https://vision.googleapis.com/v1/images:annotate"
ALLOWED_FEATURES = ("TEXT_DETECTION", "DOCUMENT_TEXT_DETECTION")
DEFAULT_FEATURE = "TEXT_DETECTION"
UNITS_PER_CALL = 1                      # 1画像 x 1機能
MAX_PNG_BYTES = 7 * 1024 * 1024         # JSON上限10MB (base64で約1.37倍) に収める
COORD_FACTOR = 4.0                      # 旧実装(4倍拡大)相当の座標系に合わせる倍率
DEFAULT_CROP = (0.245, 0.570, 0.612, 0.930)   # window_half: left, top, right, bottom
DEFAULT_EXPECTED_ROWS = 8
WINDOW_CAPTURE_METHODS = ("screen", "printwindow", "raise")


class VisionError(Exception):
    """Vision API 呼び出しに関するエラー"""


class MissingApiKey(VisionError):
    pass


# ── .env 読み込み ─────────────────────────────
def _app_dir():
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent


_FILE_KEYS = set()      # .env から設定したキー (再読み込み時に更新してよい)


def load_env_file(path=None):
    """KEY=VALUE 形式の .env を読む。
    本物の環境変数 (set コマンド等) で設定済みのキーは上書きしない。
    以前 .env から読んだキーは、再度呼ぶと最新の値に更新する。"""
    p = Path(path) if path else _app_dir() / ".env"
    if not p.is_file():
        return
    for line in p.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if key.startswith("export "):
            key = key[7:].strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        if key and (not os.environ.get(key) or key in _FILE_KEYS):
            os.environ[key] = value
            _FILE_KEYS.add(key)


# ── 応答 -> (bbox, text, conf) ────────────────
def _box(vertices):
    xs = [v.get("x", 0) for v in vertices]
    ys = [v.get("y", 0) for v in vertices]
    return min(xs), min(ys), max(xs), max(ys)


def extract_words(response0, feature):
    """[(text, x0, y0, x1, y1, conf|None)]"""
    words = []
    if feature == "TEXT_DETECTION":
        for a in (response0.get("textAnnotations") or [])[1:]:   # [0] は全文
            x0, y0, x1, y1 = _box(a["boundingPoly"]["vertices"])
            words.append((a["description"], x0, y0, x1, y1, None))
    else:
        full = response0.get("fullTextAnnotation") or {}
        for page in full.get("pages", []):
            for block in page.get("blocks", []):
                for para in block.get("paragraphs", []):
                    for w in para.get("words", []):
                        text = "".join(s.get("text", "") for s in w.get("symbols", []))
                        x0, y0, x1, y1 = _box(w["boundingBox"]["vertices"])
                        words.append((text, x0, y0, x1, y1, w.get("confidence")))
    return words


def words_to_rows(words, factor=1.0):
    """単語を Y 中心で行にまとめ、行内は X 順に連結して 1 要素にする。
    戻り値は EasyOCR 互換 [(bbox, text, conf)] (座標は factor 倍)。"""
    if not words:
        return []
    median_h = statistics.median(max(1, w[4] - w[2]) for w in words)
    margin = max(4.0, median_h * 0.6)
    rows = []
    for w in sorted(words, key=lambda w: (w[2] + w[4]) / 2):
        yc = (w[2] + w[4]) / 2
        if rows and abs(yc - rows[-1]["y"]) < margin:
            rows[-1]["words"].append(w)
            rows[-1]["y"] = (rows[-1]["y"] + yc) / 2
        else:
            rows.append({"y": yc, "words": [w]})
    out = []
    for row in rows:
        ws = sorted(row["words"], key=lambda w: w[1])
        text = "".join(w[0] for w in ws)
        x0 = min(w[1] for w in ws) * factor
        y0 = min(w[2] for w in ws) * factor
        x1 = max(w[3] for w in ws) * factor
        y1 = max(w[4] for w in ws) * factor
        conf = max((1.0 if w[5] is None else w[5]) for w in ws)
        out.append(([[x0, y0], [x1, y0], [x1, y1], [x0, y1]], text, conf))
    return out


# ── 画面読み取り設定 (.env) ───────────────────
def get_window_half_crop():
    """window_half モードの切り抜き比率 (left, top, right, bottom) を返す。
    呼ぶたびに .env を読み直すので、アプリを再起動せずに調整できる。"""
    load_env_file()
    names = ("MK7_CROP_LEFT", "MK7_CROP_TOP", "MK7_CROP_RIGHT", "MK7_CROP_BOTTOM")
    vals = []
    for name, default in zip(names, DEFAULT_CROP):
        raw = os.environ.get(name, "").strip()
        try:
            vals.append(float(raw) if raw else default)
        except ValueError:
            raise VisionError(f"{name} must be a number between 0 and 1") from None
    left, top, right, bottom = vals
    if not (0 <= left < right <= 1 and 0 <= top < bottom <= 1):
        raise VisionError("crop must satisfy 0<=LEFT<RIGHT<=1 and 0<=TOP<BOTTOM<=1")
    return left, top, right, bottom


def get_expected_rows():
    """読み取り行数の期待値。0 なら警告しない。不正な値は既定 (8) に戻す。"""
    load_env_file()
    raw = os.environ.get("MK7_EXPECTED_ROWS", "").strip()
    if not raw:
        return DEFAULT_EXPECTED_ROWS
    try:
        value = int(raw)
        return value if value >= 0 else DEFAULT_EXPECTED_ROWS
    except ValueError:
        return DEFAULT_EXPECTED_ROWS


def get_window_capture_method():
    """ウィンドウモードの撮り方。呼ぶたびに .env を読み直す。"""
    load_env_file()
    raw = os.environ.get("MK7_WINDOW_CAPTURE", "").strip().lower() or "screen"
    if raw not in WINDOW_CAPTURE_METHODS:
        raise VisionError("MK7_WINDOW_CAPTURE must be one of: "
                          + ", ".join(WINDOW_CAPTURE_METHODS))
    return raw


def save_debug_image(img, name):
    """MK7_OCR_DEBUG_DIR が設定されていれば画像を保存する (失敗しても無視)。"""
    d = os.environ.get("MK7_OCR_DEBUG_DIR", "").strip()
    if not d:
        return
    try:
        os.makedirs(d, exist_ok=True)
        img.convert("RGB").save(os.path.join(d, name), format="PNG")
    except OSError:
        pass


# ── MK7 結果画面向けの後処理 ──────────────────
_RANK_COL_MIN_HITS = 4          # 順位列ありと判定する最小一致行数
_NOISE_HEAD = "■□▪▫●○ \u3000"    # キャラアイコンの誤認識などの先頭ゴミ


def postprocess_rows(rows):
    """Vision の行結果から、MK7 の順位表として不要な部分を取り除く。
    1) 見出し行 "RESULT" を除去 (残すと順位が1つずれる)
    2) 左端の順位列 (1-8) がある場合は先頭の数字を除去
       (残すと "3DC..." のように 1文字タグ判定で D と C が同点になる)
    3) 右端の "☆☆☆ 10pts" 等のポイント列を除去
    4) 先頭の ■ などキャラアイコン由来のゴミを除去
    タグ判定は名前の先頭文字で行うので、◇◆☆ は取りこぼしても判定には影響しない。"""
    rows = [r for r in rows
            if re.sub(r"[^A-Za-z]", "", r[1]).upper() not in ("RESULT", "RESULTS")]
    hits = sum(1 for i, r in enumerate(rows) if r[1].lstrip().startswith(str(i + 1)))
    has_rank_col = hits >= _RANK_COL_MIN_HITS
    out = []
    for bbox, text, conf in rows:
        t = text.strip()
        if has_rank_col and t[:1].isdigit():
            t = t[1:]
        t = re.sub(r"[☆★\s]*\d{1,2}\s*pts?\s*$", "", t, flags=re.I)
        t = t.lstrip(_NOISE_HEAD)
        out.append((bbox, t, conf))
    return out


# ── クライアント ──────────────────────────────
class VisionOCR:
    def __init__(self, guard=None, feature=None, hints=None, timeout=30.0):
        load_env_file()
        self.guard = guard or UsageGuard()

        self.feature = (feature or os.environ.get("MK7_OCR_FEATURE")
                        or DEFAULT_FEATURE).strip().upper()
        if self.feature not in ALLOWED_FEATURES:
            raise VisionError(f"unsupported feature: {self.feature}")

        if hints is None:
            hints = os.environ.get("MK7_OCR_HINTS", "ja,en")
        if isinstance(hints, str):
            hints = [h.strip() for h in hints.split(",") if h.strip()]
        self.hints = list(hints)

        self.timeout = timeout
        self.last_status = None     # 直近の {"used":..,"limit":..}

    @staticmethod
    def _api_key():
        return os.environ.get("GOOGLE_VISION_API_KEY", "").strip()

    def check_ready(self):
        """起動時チェック: APIキーがあり、利用量DBが読めること。状態を返す。"""
        if not self._api_key():
            raise MissingApiKey("GOOGLE_VISION_API_KEY is not set "
                                "(set env var or create .env)")
        st = self.guard.status()
        self.last_status = st
        return st

    # ── OCR 本体 ──────────────────────────────
    def read(self, img):
        """PIL 画像を OCR し、[(bbox, text, conf)] を返す。"""
        key = self._api_key()
        if not key:
            raise MissingApiKey("GOOGLE_VISION_API_KEY is not set")
        png = self._encode(img)

        # 送信前に必ず予約。上限 / 記録失敗なら例外で、ここから先 (API) へ進まない。
        used = self.guard.reserve(UNITS_PER_CALL, self.feature)
        self.last_status = {"used": used, "limit": self.guard.limit}

        resp = self._post(png, key)
        r0 = (resp.get("responses") or [{}])[0]
        if "error" in r0:
            msg = self._redact(str(r0["error"].get("message", r0["error"])), key)
            raise VisionError(f"Vision API error: {msg[:200]}")
        self._debug_dump(png, resp)
        words = extract_words(r0, self.feature)
        rows = words_to_rows(words, COORD_FACTOR)
        return postprocess_rows(rows)

    @staticmethod
    def _debug_dump(png, resp):
        """MK7_OCR_DEBUG_DIR が設定されていれば、送信画像と応答を保存する。
        失敗してもOCR自体は止めない。"""
        d = os.environ.get("MK7_OCR_DEBUG_DIR", "").strip()
        if not d:
            return
        try:
            os.makedirs(d, exist_ok=True)
            stem = os.path.join(d, time.strftime("%Y%m%d_%H%M%S") + f"_{int(time.time()*1000)%1000:03d}")
            with open(stem + ".png", "wb") as f:
                f.write(png)
            with open(stem + ".json", "w", encoding="utf-8") as f:
                json.dump(resp, f, ensure_ascii=False)
        except OSError:
            pass

    def _encode(self, img):
        img = img.convert("RGB")           # 拡大などの加工はせず、そのまま送る
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        png = buf.getvalue()
        if len(png) > MAX_PNG_BYTES:
            raise VisionError("image too large (crop the capture area)")
        return png

    def _post(self, png, key):
        request_body = {"requests": [{
            "image": {"content": base64.b64encode(png).decode("ascii")},
            "features": [{"type": self.feature}],       # 機能は常に1つ
        }]}
        if self.hints:
            request_body["requests"][0]["imageContext"] = {"languageHints": self.hints}
        # 課金ユニット = 画像数 x 機能数。ここで 1 であることを保証する。
        assert len(request_body["requests"]) == 1
        assert len(request_body["requests"][0]["features"]) == 1

        req = urllib.request.Request(
            f"{API_URL}?key={key}",
            data=json.dumps(request_body).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                raw = r.read()
        except urllib.error.HTTPError as e:
            raise VisionError(f"Vision API HTTP {e.code}: "
                              f"{self._http_error_message(e, key)}") from None
        except (urllib.error.URLError, OSError) as e:      # TimeoutError は OSError
            raise VisionError("Vision API connection failed: "
                              f"{self._redact(str(e), key)[:200]}") from None
        try:
            return json.loads(raw.decode("utf-8"))
        except ValueError:
            raise VisionError("Vision API returned invalid JSON") from None

    @staticmethod
    def _redact(text, key):
        return text.replace(key, "***") if key else text

    def _http_error_message(self, err, key):
        try:
            body = json.loads(err.read().decode("utf-8", errors="replace"))
            msg = body.get("error", {}).get("message", "")
        except Exception:
            msg = ""
        return self._redact(msg, key)[:200] or "request failed"
