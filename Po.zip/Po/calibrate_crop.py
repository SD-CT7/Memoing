#!/usr/bin/env python3
"""
calibrate_crop.py -- window_half の切り抜き比率を、お手本の切り抜き画像から割り出す
=====================================================================
オフライン動作 (APIは呼びません / ユニットは消費しません)。Pillow だけで動きます。

手順:
  1. .env に MK7_OCR_DEBUG_DIR=... を設定し、アプリで window_half モードの読み取りを1回行う。
     → そのフォルダに切り抜き前の画像 last_client.png が保存される。
  2. 残したい範囲だけを切り抜いたお手本画像を用意する
     (例: 順位・アイコン・名前だけを残し、RESULT の見出し・星・pts を除いた画像)。
     ※ お手本は last_client.png と同じ拡大率の画面から切り抜いたものであること。
  3. 実行:
         python calibrate_crop.py ocr_debug\\last_client.png お手本.jpeg
  4. 表示された MK7_CROP_* を .env に貼り付ける。
     (アプリを再起動しなくても、次の読み取りから反映される)

オプション:
  --margin N   切り抜き範囲を上下左右に N ピクセル広げる (ずれへの余裕。既定 0)
"""

import argparse
import sys

from PIL import Image, ImageChops, ImageStat

MAX_MEAN_DIFF = 15.0     # これより大きければ「見つからない」と判断 (JPEG劣化分は許容)


def _score(client, tpl, x, y):
    patch = client.crop((x, y, x + tpl.width, y + tpl.height))
    return ImageStat.Stat(ImageChops.difference(patch, tpl)).mean[0]


def find_box(client, tpl):
    """client (L) の中で tpl (L) に最も一致する位置 (x, y, 平均差) を返す。"""
    W, H = client.size
    w, h = tpl.size
    if w > W or h > H:
        raise ValueError("お手本画像のほうが大きいです (拡大率が違う可能性があります)")

    # 1) 粗探索: 1/4 に縮小して全位置を調べる
    s = 4
    c_small = client.resize((max(1, W // s), max(1, H // s)), Image.BOX)
    t_small = tpl.resize((max(1, w // s), max(1, h // s)), Image.BOX)
    best = (1e18, 0, 0)
    for y in range(0, c_small.height - t_small.height + 1):
        for x in range(0, c_small.width - t_small.width + 1):
            v = _score(c_small, t_small, x, y)
            if v < best[0]:
                best = (v, x, y)
    cx, cy = best[1] * s, best[2] * s

    # 2) 精密探索: 元の大きさで ±s*2 ピクセル
    best = (1e18, cx, cy)
    for y in range(max(0, cy - 2 * s), min(H - h, cy + 2 * s) + 1):
        for x in range(max(0, cx - 2 * s), min(W - w, cx + 2 * s) + 1):
            v = _score(client, tpl, x, y)
            if v < best[0]:
                best = (v, x, y)
    return best[1], best[2], best[0]


def main():
    ap = argparse.ArgumentParser(description="window_half の切り抜き比率を割り出す")
    ap.add_argument("client", help="切り抜き前の画像 (last_client.png)")
    ap.add_argument("sample", help="お手本の切り抜き画像")
    ap.add_argument("--margin", type=int, default=0, help="範囲を広げるピクセル数")
    args = ap.parse_args()

    client_rgb = Image.open(args.client).convert("RGB")
    sample_rgb = Image.open(args.sample).convert("RGB")
    W, H = client_rgb.size
    w, h = sample_rgb.size
    print(f"切り抜き前: {W}x{H}   お手本: {w}x{h}")

    x, y, diff = find_box(client_rgb.convert("L"), sample_rgb.convert("L"))
    print(f"一致位置: x={x}, y={y}  (平均差 {diff:.1f})")
    if diff > MAX_MEAN_DIFF:
        print("お手本が切り抜き前の画像の中に見つかりませんでした。")
        print("  - お手本は last_client.png と同じ拡大率の画面から切り抜いたものですか?")
        print("  - ゲーム画面のウィンドウサイズを変えていませんか?")
        return 1

    m = args.margin
    x0, y0 = max(0, x - m), max(0, y - m)
    x1, y1 = min(W, x + w + m), min(H, y + h + m)

    # アプリは int(幅 x 比率) で切り抜くので、+0.5px 分を足して境界ぴったりにする
    left, top = (x0 + 0.5) / W, (y0 + 0.5) / H
    right, bottom = (x1 + 0.5) / W, (y1 + 0.5) / H
    right, bottom = min(right, 1.0), min(bottom, 1.0)

    got = (int(W * left), int(H * top), int(W * right), int(H * bottom))
    print(f"この設定でアプリが切り抜く範囲: {got}  (サイズ {got[2]-got[0]}x{got[3]-got[1]})")
    print()
    print("↓ .env に貼り付け")
    print(f"MK7_CROP_LEFT={left:.4f}")
    print(f"MK7_CROP_TOP={top:.4f}")
    print(f"MK7_CROP_RIGHT={right:.4f}")
    print(f"MK7_CROP_BOTTOM={bottom:.4f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
