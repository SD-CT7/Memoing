#!/usr/bin/env python3
"""tag_match.py のテスト (実行: python test_tag_match.py)"""
import unittest

from tag_match import _closest_tag_ascii, closest_tag, normalize

# game_-_コピー.png の8人 (従来の英数字タグ A-D の動作確認用)
ASCII_NAMES = ["B◇SD", "Cじゃなくてd", "DCだけはこめん", "Ayaneko",
               "D☆Dekasugi", "B◆よめない", "C◆うお", "D◇どわー"]
ASCII_EXPECTED = ["B", "C", "D", "A", "D", "B", "C", "D"]

# サンプル画像 (日本語タグ) の8人
JP_NAMES = ["Dahlia", "ATM", "みつりょう☆サザエ☆", "Arcahv",
            "Miel JJG<3", "Mielodrome", "Dette", "みつりょう★イセエビ"]


class TestAsciiUnchanged(unittest.TestCase):
    def test_same_as_legacy_function(self):
        tags = ["A", "B", "C", "D"]
        for name in ASCII_NAMES + JP_NAMES + ["", "???", "xD", "3DC"]:
            self.assertEqual(closest_tag(name, tags), _closest_tag_ascii(name, tags), name)

    def test_expected_tags(self):
        got = [closest_tag(n, ["A", "B", "C", "D"]) for n in ASCII_NAMES]
        self.assertEqual(got, ASCII_EXPECTED)


class TestNormalize(unittest.TestCase):
    def test_symbols_and_spaces_dropped(self):
        self.assertEqual(normalize("みつりょう☆サザエ☆"), "みつりようさざえ")
        self.assertEqual(normalize("B◇ SD"), "bsd")

    def test_width_case_kana_unified(self):
        self.assertEqual(normalize("ＡＢＣ"), "abc")                    # 全角英数
        self.assertEqual(normalize("ﾐﾂﾘｮｳ"), normalize("みつりょう"))      # 半角カナ
        self.assertEqual(normalize("ミツリョウ"), normalize("みつりょう"))  # カタカナ
        self.assertEqual(normalize("みつりよう"), normalize("みつりょう"))  # 小さい仮名
        self.assertEqual(normalize("ラーメン"), normalize("らーめん"))      # 長音記号は残る
        self.assertTrue(normalize("ラーメン").startswith("らー"))


class TestJapaneseTags(unittest.TestCase):
    TAGS = ["みつりょう", "Miel"]

    def test_sample_image_rows(self):
        got = [closest_tag(n, self.TAGS) for n in JP_NAMES]
        # タグのないプレイヤー (Dahlia, ATM, Arcahv, Dette) は None
        self.assertEqual(got, [None, None, "みつりょう", None,
                               "Miel", "Miel", None, "みつりょう"])

    def test_ocr_variations_still_match(self):
        tags = ["みつりょう"]
        for text in ["みつりようサザエ", "ミツリョウ★イセエビ", "ﾐﾂﾘｮｳ☆x",
                     "Qみつりょう☆サ", "みつりょラ☆サザエ", "みつりょう"]:
            self.assertEqual(closest_tag(text, tags), "みつりょう", text)

    def test_unrelated_names_not_matched(self):
        for text in ["Dahlia", "ATM", "Arcahv", "Dette", "", "☆★◇"]:
            self.assertIsNone(closest_tag(text, ["みつりょう"]), text)

    def test_mixed_ascii_and_japanese_tags(self):
        tags = ["A", "みつりょう"]
        self.assertEqual(closest_tag("Ayaneko", tags), "A")
        self.assertEqual(closest_tag("みつりょう☆サザエ", tags), "みつりょう")


if __name__ == "__main__":
    unittest.main(verbosity=2)
