assets/  --  順位表の画像出力 (leaderboard_render.py) が読み込む素材
=======================================================================
fonts/Roboto[wdth,wght].ttf          Roboto (可変フォント。太さ 300 / 400 / 900 を使用)
fonts/RubikMonoOne-Regular.ttf       Rubik Mono One (スコアの数字)
fonts/NotoSansJP[wght].ttf           Noto Sans JP (可変フォント。日本語・記号のフォールバック)
fonts/licenses/OFL-*.txt             各フォントのライセンス (SIL Open Font License 1.1)
flags/<国コード小文字>.png            国旗 (270枚。例: jp.png, us.png, gb-eng.png)
ranking1.png ranking2.png ranking3.png   順位メダル (1〜3位)

入手元 (フォント): https://github.com/google/fonts  ofl/roboto, ofl/rubikmonoone, ofl/notosansjp
フォントが無いときは Windows 標準 (游ゴシック / メイリオ / Segoe UI など) で代用して描画します。
不足している素材は  python -c "import leaderboard_render as r; print(r.check_assets())"  で確認できます。
別の場所に置く場合は、環境変数 MK7_ASSETS にフォルダを指定します。
