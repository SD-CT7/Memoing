#!/usr/bin/env python3
"""
leaderboard_render.py -- チーム別・プレイヤー別の順位表を PNG にする (Pillow のみ)
=================================================================================
参考実装 index.html (Canvas 2D) の drawTable / expand / teamColors / dots / ranking /
drawFlagBox / text と、色計算 (autoColor / hsv2rgb / rgb2hsv / lum)、5つのスタイル
(light / dark / darkThin / atlasLeague / mku) を Pillow に移植したもの。
座標・サイズ・係数は JS 側の数値をそのまま使っている。
テキストからチームを推定する部分 (parse / parsePlayer / extractClans / assign) は移植しない。

使い方:
    from leaderboard_render import render_table, SAMPLE_MODEL
    img = render_table(SAMPLE_MODEL, style="dark", scale=2)      # PIL.Image (RGB)
    img.save("leaderboard.png")

入力 (model) は、JS の expand() に渡す前の構造:
    {"title": "", "date": date|datetime|"YYYY-MM-DD"|None,
     "hide_team_names": False, "hide_team_scores": False, "hide_player_scores": False,
     "teams": [{"tag": "Alpha", "name": "Team Alpha", "color": "#3a86ff"|None, "bonus": 0,
                "players": [{"name": "Ren", "flag": "jp", "scores": [28, 31, 35], "bonus": 0}]}]}
(ランキング・合計・同点順位・自動配色は expand() が計算する)

素材 (assets/):
    fonts/Roboto[wdth,wght].ttf   fonts/RubikMonoOne-Regular.ttf   fonts/NotoSansJP[wght].ttf
    flags/<国コード小文字>.png    ranking1.png ranking2.png ranking3.png
フォントが無い場合は Windows 標準 (游ゴシック / メイリオ / Segoe UI ...) で代用して動く。
不足している素材は check_assets() で調べられる。

CLI:
    python leaderboard_render.py --sample out_dir [--scale 2] [--watermark TEXT] [--styles dark,light]
"""

import argparse
import datetime as _dt
import math
import os
import re
import sys
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageFont

SS = 2                 # 内部の描画は 2 倍の解像度で行い、LANCZOS で縮小する
FOM = 0.1              # 文字の縦位置の補正係数 (JS の FOM)
HH = 40                # ヘッダーの高さ
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
FALLBACK_FAMILY = "Noto Sans JP"
RUBIK_X_SCALE = .78    # Rubik Mono One は横に 0.78 倍に縮めて描く (text() の ctx.scale(.78, 1))
# 擬似太字 (太字の字体が無いフォントに 600 以上を要求したときのブラウザの挙動):
# 実測では「文字を右に少しずらして2回描く」(縦には太らず、1文字ごとに送り幅が増え、
# 透明度を指定すると重なった部分が濃くなる)。ずらす量は Skia の補間 (size 9 → 1/24,
# size 36 以上 → 1/32) に FAKE_BOLD_FACTOR を掛けたもの。
FAKE_BOLD_FACTOR = 0.9      # ブラウザの出力 (light / scale 2) との比較で合わせた値


# ══════════════════════════════════════════════
#  スタイル (index.html の styles)
# ══════════════════════════════════════════════
def _F(name, weight):
    return {"name": name, "weight": weight}


_LIGHT = {
    "name": "Light", "title": "", "showDate": True, "useRankingIcons": True,
    "showTeamRankings": True, "baseTextColor": "#000000", "invertColors": False,
    "autoGradient": .2, "useForcedColors": False, "forcedColor1": "#fd4d44",
    "forcedColor2": "#98fb56", "forcedGradient1": [], "forcedGradient2": [],
    "useRankingColors": False, "rankingColor1": "#ffc800", "rankingColor2": "#d4d4d4",
    "rankingColor3": "#f77f2a", "rankingColor4": "#ffffff", "iconHeight": 40,
    "iconPlacement": "header_left", "bkgColor": "#000000", "bkgOpacity": 1,
    "playerBkgColor": "#000000", "playerBkgOpacity": .15, "showBkgPolkaDots": True,
    "hideTeamNames": False, "hideTeamScores": False, "hidePlayerScores": False,
    "headerFont": _F("Roboto", 900), "teamNameFont": _F("Roboto", 900),
    "playerNameFont": _F("Roboto", 900), "playerScoreFont": _F("Rubik Mono One", 400),
    "teamScoreFont": _F("Rubik Mono One", 400), "rankingFont": _F("Roboto", 900),
}
_DARK = {**_LIGHT, "name": "Dark", "baseTextColor": "#ffffff", "invertColors": True,
         "playerBkgColor": "#888888", "playerBkgOpacity": .05}
_THIN = {**_DARK, "name": "Dark (Thin)", "headerFont": _F("Roboto", 400),
         "teamNameFont": _F("Roboto", 300), "playerNameFont": _F("Roboto", 400),
         "playerScoreFont": _F("Rubik Mono One", 400), "teamScoreFont": _F("Rubik Mono One", 400),
         "rankingFont": _F("Roboto", 400)}
STYLES = {
    "light": _LIGHT,
    "dark": _DARK,
    "darkThin": _THIN,
    "atlasLeague": {**_THIN, "name": "Atlas League",
                    "showTeamRankings": False, "useRankingIcons": False,
                    "useForcedColors": True, "forcedColor1": "#5eb6ea",
                    "forcedColor2": "#ffffff", "forcedGradient1": ["#68c4eb", "#4d72e7"],
                    "forcedGradient2": ["#b0dfe3", "#ffffff"], "autoGradient": 0,
                    "playerBkgColor": "#000000", "playerBkgOpacity": .15},
    "mku": {**_THIN, "name": "MKU", "title": "Mario Kart Universal",
            "showTeamRankings": False, "useRankingIcons": False, "useForcedColors": True,
            "forcedColor1": "#007f86", "forcedColor2": "#cd4e00", "autoGradient": 0,
            "playerBkgColor": "#000000", "playerBkgOpacity": .15,
            "headerFont": _F("Roboto", 300), "teamNameFont": _F("Roboto", 300),
            "playerNameFont": _F("Roboto", 300), "playerScoreFont": _F("Rubik Mono One", 400),
            "teamScoreFont": _F("Rubik Mono One", 400), "rankingFont": _F("Roboto", 300)},
}
DEFAULT_STYLE = "dark"

# index.html の SAMPLE と同じ内容
SAMPLE_MODEL = {
    "title": "Mogi 12v12 Finals",
    "date": "2026-11-04",
    "teams": [
        {"tag": "Alpha", "name": "Team Alpha", "color": "#3a86ff", "bonus": 0, "players": [
            {"name": "Ren", "flag": "jp", "scores": [28, 31, 35], "bonus": 0},
            {"name": "Sam", "flag": "us", "scores": [25, 27, 30], "bonus": 5},
            {"name": "Lee", "flag": "kr", "scores": [22, 20, 28], "bonus": 0},
            {"name": "Max", "flag": "de", "scores": [19, 24, 21], "bonus": -2}]},
        {"tag": "Bravo", "name": "Team Bravo", "color": "#ef476f", "bonus": -10, "players": [
            {"name": "Aki", "flag": "jp", "scores": [30, 26, 24], "bonus": 0},
            {"name": "Eva", "flag": "br", "scores": [27, 25, 27], "bonus": 0},
            {"name": "Noa", "flag": "fr", "scores": [21, 23, 19], "bonus": 0},
            {"name": "Tom", "flag": "gb", "scores": [18, 20, 22], "bonus": 0}]},
        {"tag": "Charlie", "name": None, "color": None, "bonus": 0, "players": [
            {"name": "Yui", "flag": "jp", "scores": [24, 22, 26], "bonus": 0},
            {"name": "Leo", "flag": "it", "scores": [23, 21, 20], "bonus": 0},
            {"name": "Zoe", "flag": "es", "scores": [20, 19, 21], "bonus": 0},
            {"name": "Ian", "flag": "ca", "scores": [17, 18, 19], "bonus": 0}]},
    ],
}


# ══════════════════════════════════════════════
#  色の計算 (framework/utils.ts)
# ══════════════════════════════════════════════
def _jsround(x):
    """JS の Math.round (.5 は切り上げ)。"""
    return math.floor(x + 0.5)


def hsv2rgb(h, s, v):
    r = g = b = 0.0
    s = max(0.0, min(1.0, s))
    i = math.floor(h * 6)
    f = h * 6 - i
    p = v * (1 - s)
    q = v * (1 - f * s)
    t = v * (1 - (1 - f) * s)
    k = i % 6
    if k == 0:
        r, g, b = v, t, p
    elif k == 1:
        r, g, b = q, v, p
    elif k == 2:
        r, g, b = p, v, t
    elif k == 3:
        r, g, b = p, q, v
    elif k == 4:
        r, g, b = t, p, v
    elif k == 5:
        r, g, b = v, p, q
    return (_jsround(r * 255), _jsround(g * 255), _jsround(b * 255))


def rgb2hsv(r, g, b):
    r, g, b = r / 255, g / 255, b / 255
    mx, mn = max(r, g, b), min(r, g, b)
    d = mx - mn
    h = 0.0
    s = 0 if mx == 0 else d / mx
    if mx != mn:
        if mx == r:
            h = (g - b) / d + (6 if g < b else 0)
        elif mx == g:
            h = (b - r) / d + 2
        else:
            h = (r - g) / d + 4
        h /= 6
    return h, s, mx


def rgb2hex(c):
    return "#%02x%02x%02x" % (math.floor(c[0]), math.floor(c[1]), math.floor(c[2]))


_HEX6 = re.compile(r"^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$", re.I)


def hex2rgb(s):
    """JS の hex2rgb。不正な文字列は None。"""
    m = _HEX6.match(s) if isinstance(s, str) else None
    return tuple(int(m.group(i), 16) for i in (1, 2, 3)) if m else None


def lum(c):
    return math.pow(.299 * math.pow(c[0] / 255, 2.2) + .587 * math.pow(c[1] / 255, 2.2)
                    + .114 * math.pow(c[2] / 255, 2.2), 1 / 2.2)


def auto_color(tag):
    h = 122
    tag = tag.lower()
    for c in tag:
        if c == " ":
            continue
        h += ord(c) * 12
    h %= 256
    if tag == "":
        s = 0
    else:
        s = .1 + (((.4 if 165 <= h <= 200 else .6) if 150 <= h <= 215 else .8))
    return rgb2hex(hsv2rgb(h / 256, s, 1))


def parse_css_color(s):
    """'#rgb' '#rgba' '#rrggbb' '#rrggbbaa' を (r, g, b, a) (0-255) にする。"""
    if not isinstance(s, str) or not s.startswith("#"):
        raise ValueError(f"unsupported colour: {s!r}")
    h = s[1:]
    if len(h) in (3, 4):
        h = "".join(ch * 2 for ch in h)
    if len(h) == 6:
        h += "ff"
    if len(h) != 8:
        raise ValueError(f"unsupported colour: {s!r}")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4, 6))


# ══════════════════════════════════════════════
#  expand: 順位・合計の計算
# ══════════════════════════════════════════════
def expand(m):
    """チームごとの合計・プレイヤー順・同点順位・自動配色を付けた構造を返す。"""
    ex = dict(m)
    ex["teams"] = []
    all_players = []
    for t in m.get("teams", []):
        tag = t.get("tag") or ""
        nt = {"ranking": 0, "tag": tag, "name": t.get("name"), "finalScore": 0,
              "finalScoreWithoutBonus": 0, "bonus": t.get("bonus") or 0,
              "color": t.get("color"), "autoColor": auto_color(tag), "players": []}
        for p in t.get("players", []):
            scores = list(p.get("scores", []))
            bonus = p.get("bonus") or 0
            s = sum(scores)
            np_ = {"ranking": 0, "name": p.get("name", ""), "flag": p.get("flag"),
                   "scores": scores, "bonus": bonus,
                   "finalScore": s + bonus, "finalScoreWithoutBonus": s}
            nt["players"].append(np_)
            nt["finalScore"] += np_["finalScore"]
            nt["finalScoreWithoutBonus"] += np_["finalScoreWithoutBonus"]
            all_players.append(np_)
        nt["finalScore"] += nt["bonus"]
        nt["players"].sort(key=lambda p: -p["finalScoreWithoutBonus"])
        if nt["players"]:
            ex["teams"].append(nt)
    ex["teams"].sort(key=lambda t: -t["finalScore"])
    all_players.sort(key=lambda p: -p["finalScoreWithoutBonus"])
    for i, t in enumerate(ex["teams"]):
        t["ranking"] = (ex["teams"][i - 1]["ranking"]
                        if i > 0 and t["finalScore"] == ex["teams"][i - 1]["finalScore"] else i + 1)
    for i, p in enumerate(all_players):
        p["ranking"] = (all_players[i - 1]["ranking"] if i > 0 and p["finalScoreWithoutBonus"]
                        == all_players[i - 1]["finalScoreWithoutBonus"] else i + 1)
    ex["_expanded"] = True
    return ex


def rank_str(r):
    if r % 100 < 10 or r % 100 > 20:
        if r % 10 == 1:
            return f"{r}st"
        if r % 10 == 2:
            return f"{r}nd"
        if r % 10 == 3:
            return f"{r}rd"
    return f"{r}th"


# ══════════════════════════════════════════════
#  素材 (国旗・メダル・フォント)
# ══════════════════════════════════════════════
def default_assets_dir():
    env = os.environ.get("MK7_ASSETS", "").strip()
    if env:
        return Path(env)
    base = Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
    return base / "assets"


def flag_code(raw):
    """JS の flagUrl のコード正規化。無効なら None。"""
    if not isinstance(raw, str) or re.search(r"[.:/\\]", raw) or len(raw) > 8:
        return None
    f = ""
    for ch in raw:
        c = ord(ch)
        if 0xFF21 <= c <= 0xFF3A:
            f += chr(c - 0xFF21 + 65)
        elif 0xFF41 <= c <= 0xFF5A:
            f += chr(c - 0xFF41 + 97)
        else:
            f += ch
    f = f.lower().replace("_", "-")
    if f.startswith("uk"):
        f = "gb" + f[2:]
    return f if re.fullmatch(r"[a-z0-9-]+", f) else None


def css_font_match(desired, available):
    """CSS のフォント太さの選び方 (読み込まれている太さの中から選ぶ)。"""
    avail = sorted(available)
    if desired in avail:
        return desired
    if 400 < desired <= 500:
        order = [w for w in avail if desired <= w <= 500] + \
                [w for w in reversed(avail) if w < desired] + [w for w in avail if w > 500]
    elif desired < 400:
        order = [w for w in reversed(avail) if w <= desired] + [w for w in avail if w > desired]
    else:
        order = [w for w in avail if w >= desired] + [w for w in reversed(avail) if w < desired]
    return order[0]


_WIN = r"C:\Windows\Fonts"
_LINUX_NOTO = "/usr/share/fonts/opentype/noto/NotoSansCJK-%s.ttc"
_DEJAVU = "/usr/share/fonts/truetype/dejavu/%s"


def _fallback_candidates(family, weight):
    """素材が無いときの代用フォント (ファイル, TTC番号)。先に見つかったものを使う。"""
    bold = weight >= 600
    light = weight < 350
    if family == FALLBACK_FAMILY:
        yu = "YuGothB.ttc" if bold else ("YuGothL.ttc" if light else ("YuGothM.ttc" if weight >= 500 else "YuGothR.ttc"))
        mei = "meiryob.ttc" if bold else "meiryo.ttc"
        noto = "Black" if weight >= 800 else "Bold" if bold else "Light" if light else "Regular"
        return [(os.path.join(_WIN, yu), 0), (os.path.join(_WIN, mei), 0),
                (os.path.join(_WIN, "msgothic.ttc"), 0), (_LINUX_NOTO % noto, 0),
                (_LINUX_NOTO % "Regular", 0)]
    if family == "Rubik Mono One":
        return [(os.path.join(_WIN, "consolab.ttf"), 0), (os.path.join(_WIN, "courbd.ttf"), 0),
                (os.path.join(_WIN, "arialbd.ttf"), 0), (_DEJAVU % "DejaVuSansMono-Bold.ttf", 0)]
    segoe = "segoeuib.ttf" if bold else ("segoeuil.ttf" if light else "segoeui.ttf")
    arial = "arialbd.ttf" if bold else "arial.ttf"
    dej = "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"
    return [(os.path.join(_WIN, segoe), 0), (os.path.join(_WIN, arial), 0), (_DEJAVU % dej, 0)]


_PRIMARY_FILES = {"Roboto": ("Roboto[wdth,wght].ttf", (300, 400, 900)),
                  "Rubik Mono One": ("RubikMonoOne-Regular.ttf", (400,)),
                  FALLBACK_FAMILY: ("NotoSansJP[wght].ttf", None)}


def _axis_name(ax):
    n = ax.get("name", "")
    return (n.decode("latin-1") if isinstance(n, bytes) else str(n)).lower()


class _Face:
    """1つの物理フォント (可変フォントなら太さ指定つき)。"""

    def __init__(self, path, index=0, weight=None, fake_bold=False, universal=False, asset=True):
        self.path, self.index, self.weight = path, index, weight
        self.fake_bold, self.universal, self.asset = fake_bold, universal, asset
        self._fonts, self._cov, self._ratio = {}, {}, None
        self._notdef = None

    def _load(self, size):
        try:
            f = ImageFont.truetype(self.path, size, index=self.index)
        except TypeError:
            f = ImageFont.truetype(self.path, max(1, round(size)), index=self.index)
        if self.weight is not None:
            try:
                vals = []
                for ax in f.get_variation_axes():
                    if "weight" in _axis_name(ax):
                        vals.append(max(ax["minimum"], min(ax["maximum"], self.weight)))
                    else:
                        vals.append(ax["default"])
                f.set_variation_by_axes(vals)
            except Exception:
                pass                              # 可変フォント非対応なら既定の太さで描く
        return f

    def font(self, px):
        key = round(px, 2)
        if key not in self._fonts:
            self._fonts[key] = self._load(max(1.0, px))
        return self._fonts[key]

    def metrics(self):
        """(ascent比, descent比)。em に対する比率。"""
        if self._ratio is None:
            asc, desc = self.font(1000).getmetrics()
            self._ratio = (asc / 1000, desc / 1000)
        return self._ratio

    def covers(self, ch):
        if self.universal:
            return True
        if ch not in self._cov:
            f = self.font(48)
            if self._notdef is None:
                m = f.getmask("\U0010FFFF")
                self._notdef = (m.size, bytes(m))
            m = f.getmask(ch)
            self._cov[ch] = (m.size, bytes(m)) != self._notdef
        return self._cov[ch]


class FontLibrary:
    def __init__(self, assets_dir):
        self.fonts_dir = Path(assets_dir) / "fonts"
        self.warnings = []
        self._faces = {}

    def _face(self, family, weight):
        key = (family, weight)
        if key in self._faces:
            return self._faces[key]
        fname, avail = _PRIMARY_FILES[family]
        path = self.fonts_dir / fname
        universal = family == FALLBACK_FAMILY
        face = None
        if path.is_file():
            try:
                if avail is None:                       # Noto Sans JP: 太さは軸で指定
                    face = _Face(str(path), weight=weight, universal=universal)
                else:
                    use = css_font_match(weight, avail)
                    fake = weight >= 600 and use < 600 and avail == (400,)   # 太字が無い字体 = 擬似太字
                    face = _Face(str(path), weight=use if len(avail) > 1 else None,
                                 fake_bold=fake, universal=universal)
                face.font(20)
            except OSError:
                face = None
        if face is None:
            self.warnings.append(f"{family}: assets/fonts/{fname} が無いため代用フォントを使用")
            for p, idx in _fallback_candidates(family, weight):
                if os.path.isfile(p):
                    try:
                        face = _Face(p, index=idx, universal=universal, asset=False)
                        face.font(20)
                        break
                    except OSError:
                        face = None
        if face is None:
            face = _Face("", universal=True, asset=False)
            face._load = lambda size: ImageFont.load_default(size)      # 最終手段
        self._faces[key] = face
        return face

    def chain(self, family, weight):
        """[主フォント, 日本語フォールバック] (JS の 'family, "Noto Sans JP", sans-serif')。"""
        primary = self._face(family, weight)
        if family == FALLBACK_FAMILY:
            return [primary]
        return [primary, self._face(FALLBACK_FAMILY, weight)]


_LIBS = {}


def _library(assets_dir):
    key = str(assets_dir)
    if key not in _LIBS:
        _LIBS[key] = FontLibrary(assets_dir)
    return _LIBS[key]


def check_assets(assets_dir=None):
    """足りない素材ファイルの一覧を返す (空なら全部そろっている)。"""
    d = Path(assets_dir) if assets_dir else default_assets_dir()
    missing = [f"fonts/{f}" for f, _ in _PRIMARY_FILES.values() if not (d / "fonts" / f).is_file()]
    missing += [f"ranking{i}.png" for i in (1, 2, 3) if not (d / f"ranking{i}.png").is_file()]
    if not (d / "flags").is_dir():
        missing.append("flags/ (国旗の PNG)")
    return missing


def font_warnings(assets_dir=None):
    """直前までの描画で、代用フォントを使った素材の一覧。"""
    return list(_library(assets_dir or default_assets_dir()).warnings)


def _layout_runs(s, chain, px):
    """文字ごとに、グリフを持つ最初のフォントを選び、同じフォントが続く範囲をまとめる。
    戻り値: [(PIL のフォント, 文字列, 幅, フォント情報)]"""
    runs = []
    cur_face, buf = None, ""
    for ch in s:
        face = next((f for f in chain if f.covers(ch)), chain[-1])
        if face is not cur_face and buf:
            runs.append((cur_face.font(px), buf, cur_face.font(px).getlength(buf), cur_face))
            buf = ""
        cur_face = face
        buf += ch
    if buf:
        runs.append((cur_face.font(px), buf, cur_face.font(px).getlength(buf), cur_face))
    return runs


def measure_text(s, font, size, assets_dir=None):
    """Canvas の measureText(s).width 相当 (論理 px)。レイアウトで、最長の選手名の幅を求めるのに使う。
    大きなサイズで測って縮めることで、整数への丸めの影響を避ける。"""
    if not s:
        return 0.0
    lib = _library(Path(assets_dir) if assets_dir else default_assets_dir())
    chain = lib.chain(font["name"], font["weight"])
    big = 20.0
    return sum(w for _, _, w, _ in _layout_runs(s, chain, size * big)) / big


# ══════════════════════════════════════════════
#  キャンバス (Canvas 2D の必要な部分だけ)
# ══════════════════════════════════════════════
class _Gradient:
    """縦方向の線形グラデーション (色は等間隔)。座標は論理座標 (y0 から y0+h)。"""

    def __init__(self, hex_stops, y0, h):
        self.stops = [hex2rgb(c) or (255, 255, 255) for c in hex_stops]
        self.y0, self.h = y0, h

    def shifted(self, dy):
        """グラデーションの範囲を縦に dy だけずらしたもの。translate した座標系で塗るときに使う。"""
        g = _Gradient.__new__(_Gradient)
        g.stops, g.y0, g.h = self.stops, self.y0 + dy, self.h
        return g

    def color_at(self, y):
        n = len(self.stops)
        if n == 1:
            return self.stops[0]
        t = 0 if self.h <= 0 else min(1.0, max(0.0, (y - self.y0) / self.h))
        pos = t * (n - 1)
        i = min(int(pos), n - 2)
        f = pos - i
        a, b = self.stops[i], self.stops[i + 1]
        return tuple(int(a[k] + (b[k] - a[k]) * f + 0.5) for k in range(3))

    def column(self, k, py0, th):
        """キャンバスの行 py0 から th 行ぶんの色 (幅1の画像)。"""
        col = Image.new("RGB", (1, th))
        col.putdata([self.color_at((py0 + i + 0.5) / k) for i in range(th)])
        return col


def fake_bold_extra(size):
    """擬似太字で増やす幅 (論理 px)。"""
    t = min(1.0, max(0.0, (size - 9) / 27))
    return size * (1 / 24 + (1 / 32 - 1 / 24) * t) * FAKE_BOLD_FACTOR


def _alpha_mask(mask, factor):
    if factor >= 0.999:
        return mask
    return mask.point([int(i * factor + 0.5) for i in range(256)])


class _Canvas:
    def __init__(self, w, h, k, assets_dir):
        self.k = k
        self.im = Image.new("RGBA", (w, h), (0, 0, 0, 255))
        self.assets = Path(assets_dir)
        self.fonts = _library(assets_dir)
        self._imgs = {}

    # ── 合成の基本 ────────────────────────────
    def _composite(self, layer, x, y):
        """layer (RGBA) を (x, y) に重ねる。はみ出しは切る。"""
        W, H = self.im.size
        x0, y0 = max(0, x), max(0, y)
        x1, y1 = min(W, x + layer.width), min(H, y + layer.height)
        if x1 <= x0 or y1 <= y0:
            return
        if (x0, y0, x1, y1) != (x, y, x + layer.width, y + layer.height):
            layer = layer.crop((x0 - x, y0 - y, x1 - x, y1 - y))
        self.im.alpha_composite(layer, (x0, y0))

    def _paint(self, mask, x, y, fill, alpha=1.0):
        """マスク (L) の形を、色またはグラデーションで塗る。"""
        k = self.k
        if isinstance(fill, _Gradient):
            fill_img = fill.column(k, y, mask.height).resize(mask.size, Image.NEAREST).convert("RGBA")
            a = 1.0
        else:
            r, g, b, a255 = fill
            fill_img = Image.new("RGBA", mask.size, (r, g, b, 255))
            a = a255 / 255
        fill_img.putalpha(_alpha_mask(mask, a * alpha))
        self._composite(fill_img, x, y)

    def _px(self, v):
        return int(round(v * self.k))

    # ── 図形 ──────────────────────────────────
    def fill_rect(self, x, y, w, h, fill, alpha=1.0):
        px, py = self._px(x), self._px(y)
        pw, ph = self._px(x + w) - px, self._px(y + h) - py
        if pw <= 0 or ph <= 0:
            return
        self._paint(Image.new("L", (pw, ph), 255), px, py, fill, alpha)

    def round_rect(self, x, y, w, h, r, fill, alpha=1.0):
        px, py = self._px(x), self._px(y)
        pw, ph = self._px(x + w) - px, self._px(y + h) - py
        if pw <= 0 or ph <= 0:
            return
        m = Image.new("L", (pw, ph), 0)
        ImageDraw.Draw(m).rounded_rectangle((0, 0, pw - 1, ph - 1), radius=r * self.k, fill=255)
        self._paint(m, px, py, fill, alpha)

    def dots(self, x, y, w, h, color):
        """水玉模様 (JS の dots)。帯の矩形でクリップし、中心から離れるほど濃くする。"""
        k = self.k
        r, g, b, _ = parse_css_color(color)
        px0, py0 = self._px(x), self._px(y)
        pw, ph = self._px(x + w) - px0, self._px(y + h) - py0
        layer = Image.new("RGBA", (pw, ph), (0, 0, 0, 0))
        dr = ImageDraw.Draw(layer)
        yc = y + h / 2
        alt = True
        d = 0
        while d < h / 2 + 10:
            alt = not alt
            alpha = min(1.0, .25 * math.pow(d / (h / 2), 2.2))
            if alpha > 0:
                fill = (r, g, b, int(alpha * 255 + 0.5))
                px = 7.5 if alt else 0
                while px < w + 14:
                    cx = (px) * k
                    for cy_l in (yc + d, yc - d):
                        cy = (cy_l - y) * k
                        rad = 4 * k
                        dr.ellipse((cx - rad, cy - rad, cx + rad, cy + rad), fill=fill)
                    px += 14
            d += 10
        self._composite(layer, px0, py0)

    # ── 画像 (メダル・国旗) ───────────────────
    def _image(self, rel):
        if rel not in self._imgs:
            p = self.assets / rel
            try:
                self._imgs[rel] = Image.open(p).convert("RGBA") if p.is_file() else None
            except OSError:
                self._imgs[rel] = None
        return self._imgs[rel]

    def draw_fit(self, im, xc, yc, max_w, max_h):
        if max_w <= 0 or max_h <= 0:
            return
        w, h = im.size
        p = (max_w / w) if (w / h > max_w / max_h) else (max_h / h)
        w, h = w * p, h * p
        pw, ph = max(1, self._px(w)), max(1, self._px(h))
        self._composite(im.resize((pw, ph), Image.LANCZOS), self._px(xc - w / 2), self._px(yc - h / 2))

    def flag_box(self, code, rx, ry, rw, rh):
        c = flag_code(code)
        if not c:
            return
        im = self._image(f"flags/{c}.png")
        w, h = 400.0, 300.0
        max_w, max_h = rw - 8, rh - 8
        p = (max_w / w) if (w / h > max_w / max_h) else (max_h / h)
        w, h = w * p, h * p
        x, y = rx + rw / 2 - w / 2, ry + rh / 2 - h / 2
        self.round_rect(x - 2, y - 2, w + 4, h + 4, 6, (0, 0, 0, 255))
        px, py = self._px(x), self._px(y)
        pw, ph = self._px(x + w) - px, self._px(y + h) - py
        if pw <= 0 or ph <= 0:
            return
        if im is not None:
            tile = im.resize((pw, ph), Image.LANCZOS)
        else:
            tile = Image.new("RGBA", (pw, ph), (0x55, 0x55, 0x55, 255))
        m = Image.new("L", (pw, ph), 0)
        ImageDraw.Draw(m).rounded_rectangle((0, 0, pw - 1, ph - 1), radius=4 * self.k, fill=255)
        a = tile.getchannel("A")
        tile.putalpha(ImageChops.multiply(a, m))
        self._composite(tile, px, py)
        if im is None:
            self.text((code or "")[:2].upper(), rx + rw / 2, ry + rh / 2, None, h * .5,
                      (255, 255, 255, 255), {"name": "Roboto", "weight": 700})

    # ── 文字 ──────────────────────────────────
    def text(self, s, x, y, max_w, size, fill, font, align="center", alpha=1.0, x_scale=1.0):
        """JS: ctx.font=`${weight} ${size}px ${name}, "Noto Sans JP", sans-serif`;
        textBaseline='middle'; fillText(s, x, y[, max_w])。
        max_w を渡すと、幅が超えたときに横に縮める (None なら縮めない。0 以下なら何も描かない)。
        x_scale は ctx.scale(x_scale, 1) 相当 (文字全体を横に拡大・縮小)。"""
        if not s:
            return
        k = self.k
        px = size * k
        chain = self.fonts.chain(font["name"], font["weight"])
        runs = self._runs(s, chain, px)
        extra_px = 0.0
        if chain[0].fake_bold:
            extra_px = fake_bold_extra(size) * k          # 1文字ごとに増える送り幅 (px)
            runs = [(f, r, w + extra_px * len(r), face) for f, r, w, face in runs]
        total = sum(width for _, _, width, _ in runs)
        if total <= 0:
            return
        asc_r, desc_r = chain[0].metrics()
        # 'middle' = em の中央。アセント/ディセントは論理 px で整数に丸める (ブラウザと同じ)
        baseline = y + (_jsround(asc_r * size) - _jsround(desc_r * size)) / 2

        pad = int(math.ceil(px * 0.3 + extra_px)) + 2
        top_room = int(math.ceil(px * 1.15)) + pad
        bot_room = int(math.ceil(px * 0.5)) + pad
        mw, mh = int(math.ceil(total)) + 2 * pad, top_room + bot_room
        mask = Image.new("L", (mw, mh), 0)
        dr = ImageDraw.Draw(mask)
        cx = float(pad)
        for fnt, run, width, face in runs:
            if face.fake_bold:                   # 1文字ずつ置く (送り幅に extra_px を足す)
                for ch in run:
                    dr.text((cx, top_room), ch, font=fnt, fill=255, anchor="ls")
                    cx += fnt.getlength(ch) + extra_px
            else:
                dr.text((cx, top_room), run, font=fnt, fill=255, anchor="ls")
                cx += width

        limit = None if max_w is None else max_w * k
        if limit is not None and limit <= 0:
            return                                # maxWidth が 0 以下の fillText は何も描かない
        scale_x = x_scale
        if limit is not None and total > limit:
            scale_x *= limit / total
        if scale_x != 1.0:
            mask = mask.resize((max(1, round(mw * scale_x)), mh), Image.LANCZOS)
        out_w = mask.width
        if align == "center":
            left = x * k - out_w / 2
        elif align == "right":                   # 文字の右端を x に合わせる
            left = x * k - (pad + total) * scale_x
        else:                                    # left
            left = x * k - pad * scale_x
        top = baseline * k - top_room
        x0, y0 = int(round(left)), int(round(top))
        self._paint(mask, x0, y0, fill, alpha)
        if extra_px >= 1:                        # 擬似太字: 右にずらしてもう1回 (重なりは濃くなる)
            self._paint(mask, x0 + int(round(extra_px * scale_x)), y0, fill, alpha)

    def _runs(self, s, chain, px):
        return _layout_runs(s, chain, px)

    def text_fom(self, s, x, y, w, size, fill, font, alpha=1.0, fit=False):
        """JS の text(): y に size*FOM を足す。Rubik Mono One は横に 0.78 倍。
        fit=True (JS の fitWidth) のときだけ、幅が max(0, w-10) を超えると横に縮める
        (Rubik は 0.78 倍にした座標で測るので、最大幅を 0.78 で割る)。fit=False は縮めない。"""
        xs = RUBIK_X_SCALE if font["name"] == "Rubik Mono One" else 1.0
        max_w = (max(0, w - 10) / xs) if fit else None
        if xs != 1.0 and isinstance(fill, _Gradient):
            # Canvas のグラデーションは「塗る時点の座標系」で解釈される。Rubik は translate(x, y+size*FOM) して
            # から描くので、グラデーションも同じだけずれる (文字の位置では、ほぼ最初の色になる)。
            fill = fill.shifted(y + size * FOM)
        self.text(s, x, y + size * FOM, max_w, size, fill, font, "center", alpha, x_scale=xs)


# ══════════════════════════════════════════════
#  チームの色 (teamColors)
# ══════════════════════════════════════════════
def _team_colors(y1, h, ti, tc, team, st):
    col = team["color"] or team["autoColor"]
    if st["useForcedColors"]:
        col = st["forcedColor1"] if ti % 2 == 0 else st["forcedColor2"]
    elif st["useRankingColors"]:
        cols = [st["rankingColor1"], st["rankingColor2"], st["rankingColor3"]]
        r = team["ranking"]
        col = cols[r - 1] if 1 <= r <= 3 else st["rankingColor4"]
    gs = []
    if st["useForcedColors"]:
        gs = list(st["forcedGradient1"] if ti % 2 == 0 else st["forcedGradient2"])
    if st["autoGradient"] > 0:
        g = min(1, st["autoGradient"])

        def base():
            rgb = hex2rgb(col) or (255, 255, 255)
            return list(rgb2hsv(*rgb))                           # [h, s, v]
        if tc > 2:
            a = base(); a[0] = (a[0] + 1 - .25 * g) % 1; a[2] *= .95
            b = base(); b[1] *= .9
            c = base(); c[0] = (c[0] + .25 * g) % 1; c[2] *= .95
            gs = [rgb2hex(hsv2rgb(*x)) for x in (a, b, c)]
        else:
            v1 = .9 + .1 * math.sin(math.pi * ti / tc)
            v2 = .9 + .1 * math.sin(math.pi * (ti + 1) / tc)
            s1 = 1 - .2 * math.sin(math.pi * ti / tc)
            s2 = 1 - .2 * math.sin(math.pi * (ti + 1) / tc)
            a = base(); a[0] = (a[0] + 1 - .25 * g) % 1; a[2] *= v1; a[1] *= s1
            b = base(); b[0] = (b[0] + .25 * g) % 1; b[2] *= v2; b[1] *= s2
            gs = [rgb2hex(hsv2rgb(*a)), col, rgb2hex(hsv2rgb(*b))]
    grad = _Gradient(gs, y1, h) if gs else None
    tx = "#fff" if lum(hex2rgb(col) or (255, 255, 255)) < .25 else st["baseTextColor"]
    bg = grad if grad is not None else col
    if st["invertColors"]:
        tx = grad if grad is not None else col
        bg = "#111"
    return col, tx, bg


def _fill_of(v):
    """色文字列 / グラデーション → _Canvas の塗りつぶし指定。"""
    return v if isinstance(v, _Gradient) else parse_css_color(v)


# ══════════════════════════════════════════════
#  レイアウト (drawTable の前半)
# ══════════════════════════════════════════════
def compute_layout(m, st, show_flags=True, assets_dir=None):
    has_flags = has_pb = False
    rows, max_sc, t_d, p_d = 0, 1, 3, 3
    h_tn = bool(st["hideTeamNames"] or m.get("hide_team_names") or m.get("hideTeamNames"))
    h_ts = bool(st["hideTeamScores"] or m.get("hide_team_scores") or m.get("hideTeamScores"))
    h_ps = bool(st["hidePlayerScores"] or m.get("hide_player_scores") or m.get("hidePlayerScores"))
    h_both = h_tn and h_ts
    for t in m["teams"]:
        t_d = max(t_d, len(str(t["finalScore"])))
        if t["bonus"]:
            rows += 1
        for p in t["players"]:
            rows += 1
            if p["flag"] and show_flags:
                has_flags = True
            if p["bonus"]:
                has_pb = True
            max_sc = max(max_sc, len(p["scores"]))
            for s in p["scores"]:
                p_d = max(p_d, len(str(s)))
    pad = max(0, 480 - rows * 38 - len(m["teams"]) * 20)
    ts_w = 260 + 90 * (t_d - 3)
    ps_base_w = 12 + 14 * p_d
    pb_w = 60
    rk_w = 60 if st["showTeamRankings"] else 0
    nm_w = 263 - rk_w + (pb_w if has_pb else 0) + (-100 if h_both else 0)
    pn_base_w = 139 + (ps_base_w if h_ps else 0) + (200 if h_both else 0)
    # 最長の選手名の幅 (測り方は Canvas の measureText と同じ: 名前の文字サイズ 34*.65)
    widest = 0.0
    for t in m["teams"]:
        for p in t["players"]:
            widest = max(widest, measure_text(p["name"], st["playerNameFont"], 34 * .65, assets_dir))
    compact = (not h_ps) and (not h_both) and (not h_ts) and widest > 0
    base_pn_w = min(pn_base_w, max(72, widest + 14)) if compact else pn_base_w
    # 名前のセルだけを広げる (スコアと順位の枠は幅を変えない)
    name_extra_w = max(0, 152 - base_pn_w)
    pn_w = base_pn_w + name_extra_w
    pn_slack = pn_base_w - base_pn_w
    score_cols = max_sc + (1 if max_sc > 1 else 0)
    points_ext = pn_slack if compact else 0
    ps_w = ps_base_w + points_ext / score_cols
    fl_w = 54 if has_flags else 0
    sc_w = 0 if h_ps else ps_w
    fs_w = sc_w if max_sc > 1 else 0
    pl_w = pn_w + fl_w + max_sc * sc_w + fs_w + 42
    bn_w = 0 if h_ps else pb_w
    base_ts_w2 = ts_w + (-100 if h_both else 0)
    ts_w2 = base_ts_w2 + pn_slack - points_ext - name_extra_w
    W = rk_w + nm_w + pl_w + bn_w + ts_w2
    y = HH
    T = []
    for t in m["teams"]:
        tr = len(t["players"]) + (1 if t["bonus"] else 0)
        tp = pad * tr / rows
        h = 20 + tp + tr * 34 + (tr - 1) * 4
        T.append({"y": y, "h": h, "tp": tp, "tr": tr})
        y += h
    H = y if m["teams"] else 528
    return dict(W=W, H=H, T=T, h_tn=h_tn, h_ts=h_ts, h_ps=h_ps, rk_w=rk_w, nm_w=nm_w,
                pn_w=pn_w, fl_w=fl_w, ps_w=ps_w, max_sc=max_sc, pl_w=pl_w, bn_w=bn_w,
                ts_w2=ts_w2, has_flags=has_flags, has_pb=has_pb, base_ts_w2=base_ts_w2,
                name_extra_w=name_extra_w, ps_base_w=ps_base_w, pn_base_w=pn_base_w,
                widest_name=widest, compact_names=compact)


def _date_text(d):
    if d is None:
        d = _dt.datetime.now()
    elif isinstance(d, str):
        d = _dt.datetime.strptime(d.strip()[:10], "%Y-%m-%d")
    return f"{d.day} {MONTHS[d.month - 1]} {d.year}"


def resolve_style(style):
    if isinstance(style, dict):
        return style
    if style not in STYLES:
        raise KeyError(f"unknown style: {style!r} (use one of {', '.join(STYLES)})")
    return STYLES[style]


# ══════════════════════════════════════════════
#  drawTable
# ══════════════════════════════════════════════
def render_table(model, style=DEFAULT_STYLE, scale=2, show_flags=True, watermark="",
                 assets_dir=None):
    """順位表を描いて PIL.Image (RGB) を返す。scale は最終出力の倍率 (1 か 2)。"""
    st = resolve_style(style)
    m = model if model.get("_expanded") else expand(model)
    assets_dir = Path(assets_dir) if assets_dir else default_assets_dir()
    L = compute_layout(m, st, show_flags, assets_dir)
    W, H = L["W"], L["H"]
    fw, fh = int(W * scale), int(H * scale)
    k = scale * SS
    cv = _Canvas(fw * SS, fh * SS, k, assets_dir)
    n_teams = len(m["teams"])

    cv.fill_rect(0, 0, W, H, parse_css_color(st["bkgColor"]))
    cv.fill_rect(0, 0, W, HH, (0, 0, 0, 255))
    if watermark:
        cv.text(watermark, W - 10, HH / 2 + 2, 150, 20, (255, 255, 255, 0xaa),
                {"name": "Roboto", "weight": 900}, align="right")
    hs = []
    if st["title"]:
        hs.append(st["title"])
    if m.get("title"):
        hs.append(m["title"])
    if st["showDate"]:
        hs.append(_date_text(m.get("date")))
    cv.text_fom("    •    ".join(hs), W / 2, HH / 2, W - 360, 25, (255, 255, 255, 255), st["headerFont"])

    rk_w, nm_w, pn_w, fl_w = L["rk_w"], L["nm_w"], L["pn_w"], L["fl_w"]
    ps_w, max_sc, pl_w, bn_w = L["ps_w"], L["max_sc"], L["pl_w"], L["bn_w"]
    h_tn, h_ts, h_ps, ts_w2 = L["h_tn"], L["h_ts"], L["h_ps"], L["ts_w2"]
    has_flags, has_pb = L["has_flags"], L["has_pb"]
    base_ts_w2, name_extra_w = L["base_ts_w2"], L["name_extra_w"]

    for t, team in enumerate(m["teams"]):
        g = L["T"][t]
        col, tx, bg = _team_colors(g["y"], g["h"], t, n_teams, team, st)
        cv.fill_rect(0, g["y"], W, g["h"], _fill_of(bg), st["bkgOpacity"])
        if st["showBkgPolkaDots"]:
            hh, ss, vv = rgb2hsv(*hex2rgb(col))
            hh = (hh + .95) % 1
            ss = max(ss - .25, 0)
            vv *= .6
            cv.dots(0, g["y"], W, g["h"], "#333" if st["invertColors"] else rgb2hex(hsv2rgb(hh, ss, vv)))
        tx_fill = _fill_of(tx)
        ink = _fill_of(st["baseTextColor"] if st["invertColors"] else tx)
        base_fill = _fill_of(st["baseTextColor"])

        if st["showTeamRankings"] and not h_tn:
            _ranking(cv, 0, g["y"], 60, g["h"], 24, 60 * .25, ink, team["ranking"], st)
        nr_x, nr_y, nr_w, nr_h = rk_w, g["y"], nm_w, g["h"]
        nr_xc, nr_yc = nr_x + nr_w / 2, nr_y + nr_h / 2
        if not h_tn:
            ts = min(nr_h * (.5 if team["name"] else .85), nr_w * .45)
            cv.text_fom(team["tag"], nr_xc, nr_yc + (-ts * FOM if team["name"] else 0), nr_w - 20,
                        ts, tx_fill, st["teamNameFont"], fit=True)
            if team["name"]:
                ns = min(nr_h * .2, nr_w * .15)
                cv.text_fom(team["name"], nr_xc, nr_yc + ts / 2 + ns / 2 - ns * FOM, nr_w - 20,
                            ns, tx_fill, st["teamNameFont"], fit=True)
        sx = W - ts_w2
        if not h_ts:
            sr_w, sr_h = ts_w2, g["h"]
            sr_xc, sr_yc = sx + sr_w / 2, g["y"] + sr_h / 2
            ss_ = min(sr_h * .65, base_ts_w2 * .35)
            score_x = sr_xc - 24 - name_extra_w / 2
            cv.text_fom(str(team["finalScore"]), score_x, sr_yc, sr_w, ss_, tx_fill, st["teamScoreFont"])
            if t > 0:
                diff = abs(m["teams"][t - 1]["finalScore"] - team["finalScore"])
                cv.text_fom("±" + str(diff), score_x, g["y"], sr_w - 20, 28, base_fill, st["teamNameFont"])

        px = rk_w + nm_w
        py = g["y"] + 10 + g["tp"] / 2
        bkg = parse_css_color(st["playerBkgColor"])

        def row_y(i):
            return py + i * 38

        for i, p in enumerate(team["players"]):
            ry = row_y(i)
            cv.round_rect(px, ry, pl_w, 34, 5, bkg, st["playerBkgOpacity"])
            cv.text_fom(p["name"], px + pn_w / 2 + 6, ry + 17, pn_w - 4, 34 * .65, tx_fill,
                        st["playerNameFont"], fit=True)
            if has_flags and p["flag"] and show_flags:
                cv.flag_box(p["flag"], px + pn_w, ry, 54, 34)
            cx = px + pn_w + fl_w
            if not h_ps:
                for kk, s in enumerate(p["scores"]):
                    cv.text_fom(str(s), cx + ps_w / 2, ry + 17, ps_w - 4,
                                34 * (.6 if max_sc > 1 else .65), tx_fill, st["playerScoreFont"],
                                alpha=.75 if max_sc > 1 else 1.0)
                    if max_sc > 1 and kk < len(p["scores"]) - 1:
                        cv.fill_rect(cx + ps_w - 1, ry + 4, 2, 26, parse_css_color("#fff4"))
                    cx += ps_w
                if max_sc > 1:
                    cx = px + pn_w + fl_w + max_sc * ps_w
                    cv.fill_rect(cx, ry, ps_w, 34, parse_css_color("#4444" if st["invertColors"] else "#fff4"))
                    cv.text_fom(str(p["finalScoreWithoutBonus"]), cx + ps_w / 2, ry + 17, ps_w - 4,
                                34 * .65, tx_fill, st["playerScoreFont"])
                if has_pb and p["bonus"]:
                    cv.text_fom("(" + ("+" if p["bonus"] >= 0 else "") + str(p["bonus"]) + ")",
                                px + pl_w + bn_w / 2, ry + 17, bn_w, 17, tx_fill, st["playerScoreFont"])
            _ranking(cv, px + pl_w - 42, ry, 42, 34, 4, 34 * .65 * .6, ink, p["ranking"], st)

        if team["bonus"] and not h_ts:
            ry = row_y(len(team["players"]))
            cv.round_rect(px + 10, ry + 2, pl_w - 20, 30, 5, bkg, st["playerBkgOpacity"])
            cv.text_fom("Bonus" if team["bonus"] >= 0 else "Penalty", px + pn_w / 2, ry + 17,
                        pn_w - 4, 17, tx_fill, st["playerNameFont"])
            bx = (px + pn_w + fl_w + max_sc * ps_w) if max_sc > 1 else (px + pn_w + fl_w + (max_sc - 1) * ps_w)
            cv.text_fom(("+" if team["bonus"] >= 0 else "") + str(team["bonus"]), bx + ps_w / 2,
                        ry + 17, ps_w - 4, 17, tx_fill, st["playerScoreFont"])

    out = cv.im.resize((fw, fh), Image.LANCZOS) if SS != 1 else cv.im
    return out.convert("RGB")


def _ranking(cv, x, y, w, h, pad, ts, col, r, st):
    xc, yc = x + w / 2, y + h / 2
    if st["useRankingIcons"] and r <= 3:
        im = cv._image(f"ranking{r}.png")
        if im is not None:
            cv.draw_fit(im, xc, yc, w - pad, h - pad)
        else:
            cv.text_fom(rank_str(r), xc, yc, w - 4, ts, col, st["rankingFont"])
    else:
        cv.text_fom(rank_str(r), xc, yc, w - 4, ts, col, st["rankingFont"])


# ══════════════════════════════════════════════
#  CLI
# ══════════════════════════════════════════════
def main(argv=None):
    ap = argparse.ArgumentParser(description="順位表 (PNG) を描く。--sample で index.html の SAMPLE を5スタイルで出力")
    ap.add_argument("--sample", metavar="OUT_DIR", help="SAMPLE を全スタイルで OUT_DIR に出力する")
    ap.add_argument("--styles", default=",".join(STYLES), help="出力するスタイル (カンマ区切り)")
    ap.add_argument("--scale", type=int, default=2, choices=(1, 2), help="出力の倍率 (既定 2)")
    ap.add_argument("--watermark", default="", help="ヘッダー右端の透かし文字 (既定: なし)")
    ap.add_argument("--assets", default=None, help="assets フォルダ (既定: このファイルの隣)")
    args = ap.parse_args(argv)
    if not args.sample:
        ap.print_help()
        return 1
    out = Path(args.sample)
    out.mkdir(parents=True, exist_ok=True)
    missing = check_assets(args.assets)
    if missing:
        print("足りない素材 (代用フォントで描画します):")
        for name in missing:
            print("  -", name)
    for key in [s.strip() for s in args.styles.split(",") if s.strip()]:
        img = render_table(SAMPLE_MODEL, key, args.scale, True, args.watermark, args.assets)
        path = out / f"sample_{key}.png"
        img.save(path)
        print(f"{path}  {img.size[0]}x{img.size[1]}")
    for w in font_warnings(args.assets):
        print("警告:", w)
    return 0


if __name__ == "__main__":
    sys.exit(main())
