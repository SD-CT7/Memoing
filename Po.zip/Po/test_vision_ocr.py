#!/usr/bin/env python3
"""
利用量管理とOCRクライアントのテスト (実際の Vision API は呼びません / ユニット消費なし)
実行:  python test_vision_ocr.py
"""
import io
import json
import multiprocessing as mp
import os
import tempfile
import unittest
import urllib.error
from pathlib import Path
from datetime import datetime, timezone
from unittest import mock

from PIL import Image

import vision_ocr
from usage_guard import (UsageGuard, UsageLimitReached, UsageRecordError,
                         current_month_key)
from window_capture import is_blank
from vision_ocr import (VisionError, VisionOCR, MissingApiKey, extract_words,
                        get_expected_rows, get_window_capture_method,
                        get_window_half_crop, load_env_file,
                        postprocess_rows, save_debug_image, words_to_rows)

FAKE_KEY = "AIzaFAKEKEY123"


def _worker(args):
    db, limit, tries = args
    g = UsageGuard(db_path=db, limit=limit)
    ok = 0
    for _ in range(tries):
        try:
            g.reserve(1, "t")
            ok += 1
        except UsageLimitReached:
            pass
    return ok


def _fake_response(rows):
    """rows: [(text, y)] -> TEXT_DETECTION 風の応答 (名前 + pts を別単語で)"""
    anns = [{"description": "full"}]
    for text, y in rows:
        for t, x0, x1 in ((text[:3], 60, 90), (text[3:], 92, 150), ("5 pts", 250, 300)):
            if not t:
                continue
            anns.append({"description": t, "boundingPoly": {"vertices": [
                {"x": x0, "y": y}, {"x": x1, "y": y},
                {"x": x1, "y": y + 14}, {"x": x0, "y": y + 14}]}})
    return {"responses": [{"textAnnotations": anns}]}


class FakeHTTP:
    def __init__(self, payload):
        self.payload = json.dumps(payload).encode()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def read(self):
        return self.payload


class TestUsageGuard(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = os.path.join(self.tmp.name, "u.db")

    def tearDown(self):
        self.tmp.cleanup()

    def test_limit_stops_exactly(self):
        g = UsageGuard(self.db, limit=5)
        for i in range(5):
            self.assertEqual(g.reserve(1), i + 1)
        with self.assertRaises(UsageLimitReached):
            g.reserve(1)
        self.assertEqual(g.status()["used"], 5)

    def test_multi_process_never_exceeds_limit(self):
        with mp.Pool(6) as pool:
            oks = pool.map(_worker, [(self.db, 50, 30)] * 6)   # 180回試行, 上限50
        self.assertEqual(sum(oks), 50)
        self.assertEqual(UsageGuard(self.db, 50).status()["used"], 50)

    def test_month_rollover_resets(self):
        month = ["2026-11"]
        g = UsageGuard(self.db, limit=2, month_fn=lambda: month[0])
        g.reserve(1)
        g.reserve(1)
        with self.assertRaises(UsageLimitReached):
            g.reserve(1)
        month[0] = "2026-12"
        self.assertEqual(g.reserve(1), 1)          # 翌月は自動的に0から
        month[0] = "2026-11"
        self.assertEqual(g.status()["used"], 2)    # 前月分は保持

    def test_unwritable_db_fails_safe(self):
        bad = os.path.join(self.tmp.name, "dir_not_file")
        os.mkdir(bad)                              # ディレクトリをDBパスにする
        with self.assertRaises(UsageRecordError):
            UsageGuard(bad, limit=10).reserve(1)

    def test_manual_adjust(self):
        g = UsageGuard(self.db, limit=10)
        self.assertEqual(g.adjust(4)["used"], 4)
        self.assertEqual(g.adjust(-100)["used"], 0)   # 0 未満にはならない

    def test_month_key_pacific_boundary(self):
        # 2026-12-01 07:30 UTC = 太平洋時間 2026-11-30 23:30 (PST, UTC-8) -> まだ11月
        t = datetime(2026, 12, 1, 7, 30, tzinfo=timezone.utc)
        self.assertEqual(current_month_key(t), "2026-11")
        t = datetime(2026, 12, 1, 8, 30, tzinfo=timezone.utc)
        self.assertEqual(current_month_key(t), "2026-12")


class TestVisionOCR(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.guard = UsageGuard(os.path.join(self.tmp.name, "u.db"), limit=3)
        self.img = Image.new("RGB", (100, 80), "white")
        self.env = mock.patch.dict(os.environ, {"GOOGLE_VISION_API_KEY": FAKE_KEY})
        self.env.start()
        self.noenv = mock.patch.object(vision_ocr, "load_env_file", lambda *a, **k: None)
        self.noenv.start()

    def tearDown(self):
        self.env.stop()
        self.noenv.stop()
        self.tmp.cleanup()

    def test_success_counts_one_unit_and_returns_rows(self):
        resp = _fake_response([("B◇SD", 40), ("Cじゃなくてd", 64)])
        with mock.patch("urllib.request.urlopen", return_value=FakeHTTP(resp)) as m:
            ocr = VisionOCR(guard=self.guard)
            rows = ocr.read(self.img)
            sent = json.loads(m.call_args[0][0].data)
        self.assertEqual(self.guard.status()["used"], 1)
        self.assertEqual(len(sent["requests"]), 1)                       # 画像1枚
        self.assertEqual(len(sent["requests"][0]["features"]), 1)        # 機能1つ
        self.assertEqual([r[1] for r in rows], ["B◇SD", "Cじゃなくてd"])   # pts は除去済み
        self.assertEqual(len(rows[0][0]), 4)                             # 4点bbox

    def test_missing_key_does_not_call_or_count(self):
        os.environ["GOOGLE_VISION_API_KEY"] = ""
        with mock.patch("urllib.request.urlopen") as m:
            with self.assertRaises(MissingApiKey):
                VisionOCR(guard=self.guard).read(self.img)
            m.assert_not_called()
        self.assertEqual(self.guard.status()["used"], 0)

    def test_limit_reached_does_not_call_api(self):
        resp = _fake_response([("Ayaneko", 40)])
        with mock.patch("urllib.request.urlopen", return_value=FakeHTTP(resp)) as m:
            ocr = VisionOCR(guard=self.guard)
            for _ in range(3):
                ocr.read(self.img)
            with self.assertRaises(UsageLimitReached):
                ocr.read(self.img)
            self.assertEqual(m.call_count, 3)       # 4回目は送信されていない

    def test_usage_db_failure_does_not_call_api(self):
        bad = os.path.join(self.tmp.name, "d")
        os.mkdir(bad)
        ocr = VisionOCR(guard=UsageGuard(bad, limit=10))
        with mock.patch("urllib.request.urlopen") as m:
            with self.assertRaises(UsageRecordError):
                ocr.read(self.img)
            m.assert_not_called()

    def test_http_error_is_conservative_and_hides_key(self):
        body = json.dumps({"error": {"message": f"bad key {FAKE_KEY}"}}).encode()
        err = urllib.error.HTTPError(f"https://x/?key={FAKE_KEY}", 403, "Forbidden",
                                     {}, io.BytesIO(body))
        with mock.patch("urllib.request.urlopen", side_effect=err):
            with self.assertRaises(VisionError) as cm:
                VisionOCR(guard=self.guard).read(self.img)
        self.assertNotIn(FAKE_KEY, str(cm.exception))
        self.assertIn("403", str(cm.exception))
        self.assertEqual(self.guard.status()["used"], 1)    # 保守的に加算したまま

    def test_connection_error_hides_key(self):
        err = urllib.error.URLError(f"timed out for {FAKE_KEY}")
        with mock.patch("urllib.request.urlopen", side_effect=err):
            with self.assertRaises(VisionError) as cm:
                VisionOCR(guard=self.guard).read(self.img)
        self.assertNotIn(FAKE_KEY, str(cm.exception))

    def test_document_text_detection_parsing(self):
        def sym(c):
            return {"text": c}
        word = {"confidence": 0.9, "symbols": [sym("D"), sym("☆")],
                "boundingBox": {"vertices": [{"x": 10, "y": 10}, {"x": 40, "y": 10},
                                             {"x": 40, "y": 24}, {"x": 10, "y": 24}]}}
        resp = {"responses": [{"fullTextAnnotation": {"pages": [{"blocks": [
            {"paragraphs": [{"words": [word]}]}]}]}}]}
        with mock.patch("urllib.request.urlopen", return_value=FakeHTTP(resp)):
            rows = VisionOCR(guard=self.guard,
                             feature="DOCUMENT_TEXT_DETECTION").read(self.img)
        self.assertEqual(rows[0][1], "D☆")
        self.assertAlmostEqual(rows[0][2], 0.9)

    def test_coordinates_normalized_to_4x(self):
        words = [("A", 0, 10, 10, 20, None)]
        rows = words_to_rows(words, factor=4.0 / 2)      # 2倍送信 -> 4倍座標へ
        self.assertEqual(rows[0][0][0], [0.0, 20.0])

    def test_invalid_feature_rejected(self):
        with self.assertRaises(VisionError):
            VisionOCR(guard=self.guard, feature="LABEL_DETECTION")


FIXTURES = Path(__file__).resolve().parent / "fixtures"
EXPECTED_NAMES = ["B◇SD", "Cじゃなくてd", "DCだけはこめん", "Ayaneko",
                  "D☆Dekasugi", "B◆よめない", "C◆うお", "D◇どわー"]
EXPECTED_TAG_LETTERS = ["B", "C", "D", "A", "D", "B", "C", "D"]


def _rows(fixture, feature, scale):
    r0 = json.loads((FIXTURES / fixture).read_text(encoding="utf-8"))["responses"][0]
    return postprocess_rows(words_to_rows(extract_words(r0, feature), 4.0 / scale))


@unittest.skipUnless(FIXTURES.is_dir(), "fixtures フォルダがありません")
class TestMK7Postprocess(unittest.TestCase):
    """実際の Vision 応答 (MK7結果画面, 検証で取得) を使った後処理のテスト"""

    def _check(self, rows):
        # 見出し(RESULT)が除かれ、ちょうど8行、先頭文字(=タグ)が全行正しいこと
        self.assertEqual(len(rows), 8)
        self.assertEqual([r[1][:1] for r in rows], EXPECTED_TAG_LETTERS)
        for _, text, _ in rows:           # 順位数字・pts が残っていない
            self.assertNotRegex(text, r"pts?$")
            self.assertFalse(text[:1].isdigit())

    def test_x1_text_detection(self):
        rows = _rows("mk7_x1_text.json", "TEXT_DETECTION", 1)
        self._check(rows)
        self.assertEqual(rows[0][1], "B◇SD")
        self.assertEqual(rows[2][1], "DCだけはこめん")     # DC の行 (旧: Cと誤判定)
        self.assertEqual(rows[4][1], "D☆Dekasugi")        # 先頭の ■ が除かれる
        self.assertEqual(rows[5][1], "Bよめない")           # ◆ は Vision が返さない(既知)

    def test_x1_document_text_detection(self):
        rows = _rows("mk7_x1_document.json", "DOCUMENT_TEXT_DETECTION", 1)
        self._check(rows)

    def test_x2_text_detection(self):
        self._check(_rows("mk7_x2_text.json", "TEXT_DETECTION", 2))

    def test_names_only_crop_is_unchanged(self):
        """順位数字・pts・見出しが無い画像 (名前列だけ) でも名前を壊さない"""
        rows = [([[0, i * 100], [1, i * 100], [1, i * 100 + 40], [0, i * 100 + 40]], n, 1.0)
                for i, n in enumerate(EXPECTED_NAMES)]
        out = postprocess_rows(rows)
        self.assertEqual([r[1] for r in out], EXPECTED_NAMES)

    def test_header_row_dropped(self):
        rows = [([[0, 0], [1, 0], [1, 1], [0, 1]], "RESULT", 1.0),
                ([[0, 100], [1, 100], [1, 101], [0, 101]], "Ayaneko", 1.0)]
        self.assertEqual([r[1] for r in postprocess_rows(rows)], ["Ayaneko"])



class TestSettings(unittest.TestCase):
    CROP_KEYS = ("MK7_CROP_LEFT", "MK7_CROP_TOP", "MK7_CROP_RIGHT", "MK7_CROP_BOTTOM")

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        keys = list(self.CROP_KEYS) + ["MK7_EXPECTED_ROWS", "MK7_OCR_DEBUG_DIR"]
        self.env = mock.patch.dict(os.environ, {k: "" for k in keys})
        self.env.start()
        self.noenv = mock.patch.object(vision_ocr, "load_env_file", lambda *a, **k: None)
        self.noenv.start()

    def tearDown(self):
        self.noenv.stop()
        self.env.stop()
        self.tmp.cleanup()

    def test_crop_defaults_keep_old_behaviour(self):
        self.assertEqual(get_window_half_crop(), (0.245, 0.570, 0.612, 0.930))

    def test_crop_from_env(self):
        os.environ.update({"MK7_CROP_LEFT": "0.1142", "MK7_CROP_TOP": "0.5809",
                           "MK7_CROP_RIGHT": "0.6142", "MK7_CROP_BOTTOM": "0.9701"})
        self.assertEqual(get_window_half_crop(), (0.1142, 0.5809, 0.6142, 0.9701))

    def test_crop_invalid_values_rejected(self):
        os.environ["MK7_CROP_LEFT"] = "abc"
        with self.assertRaises(VisionError):
            get_window_half_crop()
        os.environ["MK7_CROP_LEFT"] = "0.7"            # LEFT >= RIGHT(既定0.612)
        with self.assertRaises(VisionError):
            get_window_half_crop()
        os.environ["MK7_CROP_LEFT"] = "-0.1"
        with self.assertRaises(VisionError):
            get_window_half_crop()

    def test_expected_rows(self):
        self.assertEqual(get_expected_rows(), 8)
        os.environ["MK7_EXPECTED_ROWS"] = "6"
        self.assertEqual(get_expected_rows(), 6)
        os.environ["MK7_EXPECTED_ROWS"] = "0"          # 警告なし
        self.assertEqual(get_expected_rows(), 0)
        os.environ["MK7_EXPECTED_ROWS"] = "x"          # 不正 -> 既定
        self.assertEqual(get_expected_rows(), 8)

    def test_debug_image_saved_only_when_configured(self):
        img = Image.new("RGB", (10, 10), "red")
        save_debug_image(img, "a.png")
        self.assertFalse(os.path.exists(os.path.join(self.tmp.name, "a.png")))
        os.environ["MK7_OCR_DEBUG_DIR"] = self.tmp.name
        save_debug_image(img, "a.png")
        self.assertTrue(os.path.exists(os.path.join(self.tmp.name, "a.png")))


class TestEnvReload(unittest.TestCase):
    def test_env_file_values_update_on_reload_but_real_env_wins(self):
        with tempfile.TemporaryDirectory() as d:
            envfile = os.path.join(d, ".env")
            with mock.patch.dict(os.environ, {"MK7_TEST_REAL": "from_shell"}):
                for k in ("MK7_TEST_A", "MK7_TEST_REAL"):
                    vision_ocr._FILE_KEYS.discard(k)
                Path(envfile).write_text("MK7_TEST_A=1\nMK7_TEST_REAL=file\n", encoding="utf-8")
                load_env_file(envfile)
                self.assertEqual(os.environ["MK7_TEST_A"], "1")
                Path(envfile).write_text("MK7_TEST_A=2\nMK7_TEST_REAL=file\n", encoding="utf-8")
                load_env_file(envfile)
                self.assertEqual(os.environ["MK7_TEST_A"], "2")           # 更新される
                self.assertEqual(os.environ["MK7_TEST_REAL"], "from_shell")  # setした値が優先
            os.environ.pop("MK7_TEST_A", None)
            vision_ocr._FILE_KEYS.discard("MK7_TEST_A")



class TestWindowCapture(unittest.TestCase):
    def setUp(self):
        self.env = mock.patch.dict(os.environ, {"MK7_WINDOW_CAPTURE": ""})
        self.env.start()
        self.noenv = mock.patch.object(vision_ocr, "load_env_file", lambda *a, **k: None)
        self.noenv.start()

    def tearDown(self):
        self.noenv.stop()
        self.env.stop()

    def test_method_default_is_screen(self):
        self.assertEqual(get_window_capture_method(), "screen")

    def test_method_values(self):
        for m in ("screen", "printwindow", "raise"):
            os.environ["MK7_WINDOW_CAPTURE"] = m.upper()      # 大文字でもよい
            self.assertEqual(get_window_capture_method(), m)

    def test_method_invalid_rejected(self):
        os.environ["MK7_WINDOW_CAPTURE"] = "magic"
        with self.assertRaises(VisionError):
            get_window_capture_method()

    def test_blank_image_detected(self):
        self.assertTrue(is_blank(Image.new("RGB", (50, 50), "black")))
        self.assertTrue(is_blank(Image.new("RGB", (50, 50), (255, 255, 255))))
        img = Image.new("RGB", (50, 50), "black")
        img.putpixel((10, 10), (200, 200, 200))               # 文字が1ドットでもあれば blank ではない
        self.assertFalse(is_blank(img))


if __name__ == "__main__":
    unittest.main(verbosity=2)
