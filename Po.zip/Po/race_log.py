#!/usr/bin/env python3
"""
race_log.py -- レースごとの記録保存と、プレイヤー別スコアの遡及集計
====================================================================
1回の「模擬」= 1セッション。セッションごとに次のフォルダを作る:

    logs/20261105_201530/
        race_01.png      OCR に送った画像
        race_01.json     読み取り結果 (順位・名前・タグ・ポイント・状態)
        race_02.png / race_02.json ...
        roster.json      入力された名簿 (あれば)
        session.txt      人が読むための一覧 (全レース)
        session.json     全レースをまとめたもの
        players.txt / players.json   プレイヤー別の集計 (名簿を適用したとき)

* race_XX.json の status:
      pending    読み取っただけ (まだ加算していない)
      added      add score で確定した  <- プレイヤー集計の対象はこれだけ
      discarded  retry や再読み取りで破棄した
* 名簿は、読み取り済みの記録 (名前の文字列) に後から当てはめるので、途中で入力しても
  過去のレースまで遡って集計できる。アプリを再起動しても、フォルダから読み直せる。
* 読み取り結果は、後から手で直せる (update_race / revert_race)。直す前の行は
  rows_original に1度だけ保存され、revert_race で元に戻せる。
* 画面 (Tk) には依存しない。
"""

import json
import os
import sys
from collections import Counter
from datetime import datetime
from difflib import SequenceMatcher
from pathlib import Path

from name_lists import expand_variants
from tag_match import normalize

STATUS_PENDING = "pending"
STATUS_ADDED = "added"
STATUS_DISCARDED = "discarded"

DEFAULT_POINTS = [10, 8, 6, 5, 4, 3, 2, 1]
MATCH_THRESHOLD = 0.6        # 名簿と読み取り名の一致とみなす最小スコア
CONTAIN_SCORE = 0.9          # 名簿の名前が読み取り名に含まれる (略称入力など)


# ── 保存先 ────────────────────────────────────
def default_log_dir():
    env = os.environ.get("MK7_LOG_DIR", "").strip()
    if env:
        return Path(env)
    if getattr(sys, "frozen", False):
        base = Path(sys.executable).parent
    else:
        base = Path(__file__).resolve().parent
    return base / "logs"


def _write_json(path, obj):
    """途中で止まっても壊れたファイルを残さないよう、一時ファイル経由で書く。"""
    tmp = Path(str(path) + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def _write_text(path, text):
    tmp = Path(str(path) + ".tmp")
    with open(tmp, "w", encoding="utf-8-sig") as f:      # メモ帳でも文字化けしない
        f.write(text)
    os.replace(tmp, path)


# ── セッション ────────────────────────────────
class SessionLog:
    def __init__(self, folder):
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True)
        existing = [int(p.stem.split("_")[1]) for p in self.folder.glob("race_*.json")
                    if p.stem.split("_")[1].isdigit()]
        self._next_seq = (max(existing) + 1) if existing else 1

    @classmethod
    def create(cls, base_dir=None, now=None):
        base = Path(base_dir) if base_dir else default_log_dir()
        now = now or datetime.now()
        name = now.strftime("%Y%m%d_%H%M%S")
        folder, n = base / name, 2
        while folder.exists():              # 同じ秒に2つ作った場合
            folder = base / f"{name}_{n}"
            n += 1
        return cls(folder)

    # ── レースの保存 ──────────────────────────
    def _race_paths(self, seq):
        return self.folder / f"race_{seq:02d}.png", self.folder / f"race_{seq:02d}.json"

    def save_capture(self, img, rows, meta=None, now=None):
        """画像と読み取り結果を保存し、連番 (seq) を返す。状態は pending。
        rows: [{"rank": int|None, "text": str, "tag": str|None, "points": int|None}]"""
        seq = self._next_seq
        png, js = self._race_paths(seq)
        img.convert("RGB").save(png, format="PNG")
        data = {
            "seq": seq,
            "captured_at": (now or datetime.now()).isoformat(timespec="seconds"),
            "status": STATUS_PENDING,
            "image": png.name,
            "rows": rows,
        }
        data.update(meta or {})
        _write_json(js, data)
        self._next_seq = seq + 1
        self.write_summary()
        return seq

    def set_status(self, seq, status):
        _, js = self._race_paths(seq)
        with open(js, encoding="utf-8") as f:
            data = json.load(f)
        data["status"] = status
        data["status_at"] = datetime.now().isoformat(timespec="seconds")
        _write_json(js, data)
        self.write_summary()

    def load_race(self, seq):
        """1レース分を読み込む。無ければ None。"""
        _, js = self._race_paths(seq)
        try:
            with open(js, encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            return None

    def update_race(self, seq, rows=None, status=None):
        """読み取り結果 (rows) や状態 (status) を書き換える。
        rows を直した場合、直す前の行を rows_original に1度だけ残す。"""
        data = self.load_race(seq)
        if data is None:
            raise KeyError(f"race {seq} not found")
        now = datetime.now().isoformat(timespec="seconds")
        if rows is not None:
            data.setdefault("rows_original", data.get("rows", []))
            data["rows"] = rows
            data["row_count"] = len(rows)
            data["edited"] = True
            data["edited_at"] = now
        if status is not None:
            data["status"] = status
            data["status_at"] = now
        _write_json(self._race_paths(seq)[1], data)
        self.write_summary()
        return data

    def revert_race(self, seq):
        """直す前の読み取り結果に戻す。戻せたら True。"""
        data = self.load_race(seq)
        if data is None or "rows_original" not in data:
            return False
        data["rows"] = data.pop("rows_original")
        data["row_count"] = len(data["rows"])
        data["edited"] = False
        data["reverted_at"] = datetime.now().isoformat(timespec="seconds")
        _write_json(self._race_paths(seq)[1], data)
        self.write_summary()
        return True

    def load_races(self, statuses=(STATUS_ADDED,)):
        """フォルダから読み直して、指定した状態のレースを seq 順で返す。"""
        races = []
        for js in sorted(self.folder.glob("race_*.json")):
            try:
                with open(js, encoding="utf-8") as f:
                    data = json.load(f)
            except (OSError, ValueError):
                continue                      # 壊れたファイルは飛ばす
            if statuses is None or data.get("status") in statuses:
                races.append(data)
        races.sort(key=lambda d: d.get("seq", 0))
        return races

    # ── 名簿 ──────────────────────────────────
    def save_roster(self, names):
        _write_json(self.folder / "roster.json", {"names": list(names)})

    def load_roster(self):
        try:
            with open(self.folder / "roster.json", encoding="utf-8") as f:
                return list(json.load(f).get("names", []))
        except (OSError, ValueError):
            return []

    # ── まとめファイル ────────────────────────
    def write_summary(self):
        races = self.load_races(statuses=None)
        _write_json(self.folder / "session.json",
                    {"roster": self.load_roster(), "races": races})
        lines = [f"session: {self.folder.name}", ""]
        for r in races:
            edited = "  (edited)" if r.get("edited") else ""
            lines.append(f"race {r.get('seq', 0):02d}  [{r.get('status', '?')}]  "
                         f"{r.get('captured_at', '')}  rows={r.get('row_count', len(r.get('rows', [])))}{edited}")
            for row in r.get("rows", []):
                rank = row.get("rank")
                label = row.get("tag") or "-"
                pts = row.get("points")
                lines.append(f"   {rank if rank is not None else '-'}  [{label}]  "
                             f"{'+' + str(pts) if pts else ''}  {row.get('text', '')}")
            lines.append("")
        _write_text(self.folder / "session.txt", "\n".join(lines))

    def export_players(self, report):
        _write_json(self.folder / "players.json", report)
        _write_text(self.folder / "players.txt", format_report(report))


# ── 手で直した結果の取り込み ─────────────────
def parse_names_text(text):
    """入力欄の文字列を、順位順の名前リストにする。
    1行目 = 1位。途中の空行は「名前不明のプレイヤー」として順位を数える。
    末尾の空行だけは無視する。"""
    names = [line.strip() for line in text.splitlines()]
    while names and not names[-1]:
        names.pop()
    return names


def rebuild_rows(names, tags, tag_fn, points=None):
    """順位順の名前リストから、保存用の行 (rank / text / tag / points) を作り直す。
    8位までは順位とポイントを付け、9行目以降は対象外 (rank=None) にする。"""
    points = points or DEFAULT_POINTS
    rows = []
    for i, name in enumerate(names):
        rank = i + 1 if i < len(points) else None
        tag = tag_fn(name, tags) if (rank is not None and name) else None
        rows.append({"rank": rank, "text": name, "tag": tag,
                     "points": points[i] if tag else None})
    return rows


def team_delta(rows):
    """行のタグとポイントから、そのレースのチーム別ポイントを求める。"""
    delta = {}
    for r in rows:
        if r.get("tag") and r.get("points"):
            delta[r["tag"]] = delta.get(r["tag"], 0) + r["points"]
    return delta


def delta_diff(before, after):
    """2つのチーム別ポイントの差 (after - before)。0 の項目は含めない。"""
    diff = {}
    for t in set(before) | set(after):
        v = after.get(t, 0) - before.get(t, 0)
        if v:
            diff[t] = v
    return diff


# ── 名簿との照合 ──────────────────────────────
def name_score(roster_name, row_text):
    """名簿の名前と、読み取った名前の近さ (0〜1)。記号・空白・大文字小文字・
    全角半角・かな種別の違いは無視する。"""
    a, b = normalize(roster_name), normalize(row_text)
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    # 略称の入力 (名簿が短い) や、右端で名前が切れている (読み取りが短い) 場合
    if (len(a) >= 2 and a in b) or (len(b) >= 3 and b in a):
        return CONTAIN_SCORE
    return SequenceMatcher(None, a, b).ratio()


def match_roster(rows, roster, threshold=MATCH_THRESHOLD):
    """1レース分の行と名簿を、スコアの高い順に1対1で対応づける。
    戻り値: {名簿の番号: 行の番号}"""
    cands = []
    for ri, name in enumerate(roster):
        for wi, row in enumerate(rows):
            if row.get("rank") is None:        # 9行目以降などの対象外の行
                continue
            s = name_score(name, row.get("text", ""))
            if s >= threshold:
                cands.append((-s, ri, wi))
    cands.sort()
    used_r, used_w, result = set(), set(), {}
    for _, ri, wi in cands:
        if ri in used_r or wi in used_w:
            continue
        used_r.add(ri)
        used_w.add(wi)
        result[ri] = wi
    return result


def match_roster_with_fixes(rows, roster, rules=None, threshold=MATCH_THRESHOLD):
    """match_roster の結果に加えて、一致しなかった行にだけ OCR ミスのリスト (rules) を当てはめて
    照合し直す。まだ誰とも対応していない名簿の名前にだけ当てはめるので、すでに一致した行や
    名簿の名前を奪うことはない。
    戻り値: (対応 {名簿の番号: 行の番号}, 補正した行 {名簿の番号: 置き換え後の文字列})"""
    matched = match_roster(rows, roster, threshold)
    fixes = {}
    if not rules:
        return matched, fixes
    used_r, used_w = set(matched), set(matched.values())
    cands = []
    for wi, row in enumerate(rows):
        if wi in used_w or row.get("rank") is None:
            continue
        variants = expand_variants(row.get("text", ""), rules)
        if not variants:
            continue
        for ri, name in enumerate(roster):
            if ri in used_r:
                continue
            score, best = max((name_score(name, v), v) for v in variants)
            if score >= threshold:
                cands.append((-score, ri, wi, best))
    cands.sort()
    for _, ri, wi, variant in cands:
        if ri in used_r or wi in used_w:
            continue
        used_r.add(ri)
        used_w.add(wi)
        matched[ri] = wi
        fixes[ri] = variant
    return matched, fixes


def compute_player_totals(races, roster, points=None, rules=None):
    """確定済みレース (races) と名簿から、プレイヤー別の集計を作る。
    rules: OCR ミスのリスト [(置き換え前, 置き換え後)]。一致しなかった行にだけ使い、
    使って一致した行は report["corrections"] に記録する。"""
    points = points or DEFAULT_POINTS
    players = [{"name": n, "points": 0, "races": 0, "per_race": {}, "team": None}
               for n in roster]
    tag_counts = [Counter() for _ in roster]
    issues = []
    corrections = []
    for race in races:
        seq = race.get("seq", 0)
        rows = race.get("rows", [])
        matched, fixes = match_roster_with_fixes(rows, roster, rules)
        for ri, variant in fixes.items():
            corrections.append({"race": seq, "rank": rows[matched[ri]].get("rank"),
                                "text": rows[matched[ri]].get("text", ""), "fixed": variant,
                                "player": roster[ri]})
        for ri, wi in matched.items():
            rank = rows[wi]["rank"]
            pts = points[rank - 1] if 1 <= rank <= len(points) else 0
            p = players[ri]
            tag = rows[wi].get("tag")
            if tag:
                tag_counts[ri][tag] += 1
            p["points"] += pts
            p["races"] += 1
            p["per_race"][str(seq)] = {"rank": rank, "points": pts, "tag": tag}
        missing = [roster[i] for i in range(len(roster)) if i not in matched]
        used = set(matched.values())
        extra = [{"rank": r.get("rank"), "text": r.get("text", "")}
                 for i, r in enumerate(rows) if i not in used and r.get("rank") is not None]
        if missing or extra:
            issues.append({"race": seq, "missing_players": missing, "unmatched_rows": extra})
    for p, counts in zip(players, tag_counts):      # チーム = 最も多く付いたタグ
        if counts:
            p["team"] = counts.most_common(1)[0][0]
    ordered = sorted(players, key=lambda p: (-p["points"], p["name"]))
    return {
        "roster": list(roster),
        "races": [r.get("seq", 0) for r in races],
        "players": ordered,
        "issues": issues,
        "corrections": corrections,
    }


def format_report(report):
    races = report.get("races", [])
    lines = [f"PLAYER TOTALS   ({len(races)} race{'s' if len(races) != 1 else ''} counted: "
             f"{', '.join(str(s) for s in races) or '-'})", ""]
    for i, p in enumerate(report.get("players", []), 1):
        ranks = " ".join(str(p["per_race"][str(s)]["rank"]) if str(s) in p["per_race"] else "-"
                         for s in races)
        lines.append(f"{i}. {p['name']}   {p['points']} pts   ({p['races']} races)")
        if races:
            lines.append(f"     ranks: {ranks}")
    corrections = report.get("corrections", [])
    if corrections:
        lines += ["", "AUTO-FIXED (OCR misread list):"]
        for c in corrections:
            lines.append(f"  race {c['race']}  {c['rank']}: {c['text']} -> {c['fixed']}   [{c['player']}]")
    issues = report.get("issues", [])
    if issues:
        lines += ["", "CHECK (names not matched):"]
        for it in issues:
            parts = []
            if it["missing_players"]:
                parts.append("not found: " + ", ".join(it["missing_players"]))
            if it["unmatched_rows"]:
                parts.append("unmatched rows: " + ", ".join(
                    f"{r['rank']}:{r['text']}" for r in it["unmatched_rows"]))
            lines.append(f"  race {it['race']}  " + " / ".join(parts))
    return "\n".join(lines)
