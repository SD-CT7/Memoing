#!/usr/bin/env python3
"""
アプリ全体の流れのテスト (Tk・mss・keyboard・win32 はスタブに置き換えるので、画面は出ません)
  読み取り -> 確定 / retry -> 途中で名簿入力 -> 過去分も遡って集計 -> CLEAR で新セッション
実行:  python test_app_flow.py
"""
import json
import os
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest import mock

for _name in ("mss", "keyboard", "win32gui"):
    sys.modules[_name] = mock.MagicMock()

_tk = types.ModuleType("tkinter")


class _Widget:
    def __init__(self, *a, **k):
        pass

    def __getattr__(self, name):           # title/geometry/lift/... は何もしない
        return mock.MagicMock()


_tk.Tk = type("Tk", (_Widget,), {})
_tk.Toplevel = type("Toplevel", (_Widget,), {})
for _attr in ("Canvas", "Frame", "Label", "Button", "Entry", "StringVar", "IntVar",
              "BooleanVar", "Text", "Scrollbar", "Listbox", "Radiobutton", "Checkbutton"):
    setattr(_tk, _attr, mock.MagicMock())
_tk.ttk = mock.MagicMock()
_tk.filedialog = mock.MagicMock()
sys.modules["tkinter"] = _tk
sys.modules["tkinter.ttk"] = _tk.ttk
sys.modules["tkinter.filedialog"] = _tk.filedialog

import PIL.ImageTk  # noqa: E402
PIL.ImageTk.PhotoImage = lambda im: object()
from PIL import Image  # noqa: E402

import score_app_v3 as app  # noqa: E402
from vision_ocr import extract_words, postprocess_rows, words_to_rows  # noqa: E402
from name_lists import NameLists  # noqa: E402

# どのテストも、実際の settings フォルダ (利用者の辞書) を読まないよう、空の一時フォルダを既定にする
import atexit  # noqa: E402
import shutil  # noqa: E402
_HERMETIC_SETTINGS = tempfile.mkdtemp(prefix="mk7_test_settings_")
os.environ["MK7_SETTINGS_DIR"] = _HERMETIC_SETTINGS
atexit.register(shutil.rmtree, _HERMETIC_SETTINGS, True)

FIXTURE = Path(__file__).resolve().parent / "fixtures" / "mk7_x1_text.json"
TRUE_NAMES = ["B◇SD", "Cじゃなくてd", "DCだけはこめん", "Ayaneko",
              "D☆Dekasugi", "B◆よめない", "C◆うお", "D◇どわー"]


class FakeVar:
    def __init__(self, v=""):
        self.v = v

    def get(self):
        return self.v


class FakePanel:
    """ControlPanel のうち、今回の流れに必要なメソッドだけを借りる。"""
    _on_captured = app.ControlPanel._on_captured
    _log_capture = app.ControlPanel._log_capture
    _mark_race = app.ControlPanel._mark_race
    _discard_pending_race = app.ControlPanel._discard_pending_race
    _confirm = app.ControlPanel._confirm
    _clear = app.ControlPanel._clear
    _open_players = app.ControlPanel._open_players
    _players_win_alive = app.ControlPanel._players_win_alive
    _on_players_closed = app.ControlPanel._on_players_closed
    _apply_roster = app.ControlPanel._apply_roster
    _refresh_players = app.ControlPanel._refresh_players
    _write_leaderboard = app.ControlPanel._write_leaderboard
    _export_image = app.ControlPanel._export_image
    _lorenzi_text = app.ControlPanel._lorenzi_text
    _export_done = app.ControlPanel._export_done
    _load_lists = app.ControlPanel._load_lists
    _reload_lists = app.ControlPanel._reload_lists
    _lists_win_alive = app.ControlPanel._lists_win_alive
    _open_lists = app.ControlPanel._open_lists
    _on_lists_closed = app.ControlPanel._on_lists_closed
    _save_lists = app.ControlPanel._save_lists
    _unmatched_text = app.ControlPanel._unmatched_text
    _unknown_flag_codes = app.ControlPanel._unknown_flag_codes
    _races_win_alive = app.ControlPanel._races_win_alive
    _open_races = app.ControlPanel._open_races
    _on_races_closed = app.ControlPanel._on_races_closed
    _refresh_races = app.ControlPanel._refresh_races
    _races_list = app.ControlPanel._races_list
    _races_load = app.ControlPanel._races_load
    _apply_race_change = app.ControlPanel._apply_race_change
    _result_text = app.ControlPanel._result_text
    _races_save = app.ControlPanel._races_save
    _races_revert = app.ControlPanel._races_revert

    def __init__(self):
        self.tags = ["A", "B", "C", "D"]
        self.session = None
        self.roster = []
        self.players_win = None
        self.races_win = None
        self.roster_flags = {}
        self.lists = NameLists()
        self.lists_win = None
        self._exporting = False
        self._export_thread = None
        self._pending = None
        self._pending_seq = None
        self._last_img = None
        self._last_rows = []
        self._usage_msg = ""
        self.history = []
        self.status = []
        self.capture_mode = FakeVar("window_half")
        self.scoreboard = mock.MagicMock()
        self.lst_hist = mock.MagicMock()
        for n in ("lbl_preview", "btn_ok", "btn_retry", "txt_result"):
            setattr(self, n, mock.MagicMock())

    def _set_status(self, msg):
        self.status.append(msg)

    def after(self, ms, fn):                     # Tk の after の代わり (すぐ実行)
        fn()

    def capture(self, rows):
        """_capture の先頭 (前回の未確定を破棄) + 読み取り完了までを再現する。"""
        self._discard_pending_race()
        self._pending = None
        self._last_img = Image.new("RGB", (60, 40), "white")
        app.ControlPanel._on_captured(self, rows, [], Image.new("RGB", (10, 10)))


def fixture_rows():
    r0 = json.loads(FIXTURE.read_text(encoding="utf-8"))["responses"][0]
    return postprocess_rows(words_to_rows(extract_words(r0, "TEXT_DETECTION"), 4.0))


@unittest.skipUnless(FIXTURE.is_file(), "fixtures がありません")
class TestAppFlow(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.env = mock.patch.dict(os.environ, {"MK7_LOG_DIR": self.tmp.name,
                                                "MK7_EXPECTED_ROWS": ""})
        self.env.start()
        self.p = FakePanel()
        self.rows = fixture_rows()

    def tearDown(self):
        self.env.stop()
        self.tmp.cleanup()

    def _statuses(self):
        return [r["status"] for r in self.p.session.load_races(statuses=None)]

    def test_full_flow_with_roster_entered_midway(self):
        p = self.p
        # レース1: 読み取り -> 確定
        p.capture(self.rows)
        self.assertEqual(self._statuses(), ["pending"])
        p._confirm()
        # レース2: 読み取り -> retry(再読み取り) -> 確定
        p.capture(self.rows)
        p.capture(self.rows)                     # retry 相当: 前の読み取りは discarded
        p._confirm()
        self.assertEqual(self._statuses(), ["added", "discarded", "added"])
        self.assertTrue((p.session.folder / "race_01.png").is_file())

        # ここで名簿を入力 -> 確定済みの2レース分を遡って集計
        p._apply_roster(TRUE_NAMES)
        report = json.loads((p.session.folder / "players.json").read_text("utf-8"))
        got = {pl["name"]: pl["points"] for pl in report["players"]}
        for rank, name in enumerate(TRUE_NAMES, 1):
            self.assertEqual(got[name], 2 * app.POINTS[rank - 1], name)
        self.assertEqual(report["races"], [1, 3])
        self.assertEqual(report["issues"], [])

        # レース3 を確定すると、名簿は適用済みなので自動で再集計される
        p.capture(self.rows)
        p._confirm()
        report = json.loads((p.session.folder / "players.json").read_text("utf-8"))
        self.assertEqual({pl["name"]: pl["points"] for pl in report["players"]}[TRUE_NAMES[0]], 30)

    def test_team_scores_unchanged_by_logging(self):
        p = self.p
        p.capture(self.rows)
        self.assertEqual(p._pending, {"A": 5, "B": 13, "C": 10, "D": 11})
        p._confirm()
        p.scoreboard.update_scores.assert_called_once_with({"A": 5, "B": 13, "C": 10, "D": 11})

    def test_unconfirmed_race_is_not_counted(self):
        p = self.p
        p.capture(self.rows)
        p._confirm()
        p.capture(self.rows)                     # 読み取っただけで確定しない
        p._apply_roster(TRUE_NAMES)
        report = json.loads((p.session.folder / "players.json").read_text("utf-8"))
        self.assertEqual(report["races"], [1])

    def test_clear_starts_new_session(self):
        p = self.p
        p.capture(self.rows)
        p._confirm()
        first = p.session.folder
        p._clear()
        self.assertIsNone(p.session)
        self.assertEqual(p.roster, [])
        p.capture(self.rows)
        self.assertNotEqual(p.session.folder, first)
        self.assertTrue(first.is_dir())          # 以前の記録は残る
        self.assertEqual(self._statuses(), ["pending"])

    def test_logging_failure_does_not_stop_scoring(self):
        p = self.p
        blocker = Path(self.tmp.name) / "not_a_folder"
        blocker.write_text("x")                  # ファイルの下にはフォルダを作れない
        with mock.patch.dict(os.environ, {"MK7_LOG_DIR": str(blocker / "logs")}):
            p.capture(self.rows)
        self.assertEqual(p._pending, {"A": 5, "B": 13, "C": 10, "D": 11})
        self.assertIn("log failed", p.status[-1])
        p._confirm()                             # 記録が無くても確定できる
        p.scoreboard.update_scores.assert_called_once()

    def test_fill_names_from_last_race(self):
        p = self.p
        p.capture(self.rows)
        self.assertEqual(len(p._last_rows), 8)
        self.assertEqual(p._last_rows[0], "B◇SD")

    def test_players_window_opens_and_refreshes(self):
        p = self.p
        p.capture(self.rows)
        p._confirm()
        p._open_players()
        self.assertIsNotNone(p.players_win)
        p._apply_roster(TRUE_NAMES)              # 画面が開いていても落ちない
        p._on_players_closed()
        self.assertIsNone(p.players_win)



@unittest.skipUnless(FIXTURE.is_file(), "fixtures がありません")
class TestEditRaces(unittest.TestCase):
    """過去レースの読み取り結果を直す -> チーム点・プレイヤー別が再集計される"""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.env = mock.patch.dict(os.environ, {"MK7_LOG_DIR": self.tmp.name,
                                                "MK7_EXPECTED_ROWS": ""})
        self.env.start()
        self.p = FakePanel()
        self.rows = fixture_rows()
        for _ in range(2):                       # 同じ結果の2レースを確定
            self.p.capture(self.rows)
            self.p._confirm()
        self.p.scoreboard.adjust_scores.reset_mock()
        self.p._apply_roster(TRUE_NAMES)

    def tearDown(self):
        self.env.stop()
        self.tmp.cleanup()

    def _players(self):
        rep = json.loads((self.p.session.folder / "players.json").read_text("utf-8"))
        return {pl["name"]: pl["points"] for pl in rep["players"]}, rep["races"]

    def test_swap_ranks_adjusts_board_and_players(self):
        p = self.p
        names = p._races_load(1)["names"]
        self.assertEqual(names[:2], ["B◇SD", "Cじゃなくてd"])
        names[0], names[1] = names[1], names[0]          # 1位と2位を入れ替える
        text = p._races_save(1, names, True)
        # チーム点: B 13->11 (-2), C 10->12 (+2)。スコアボードには差分だけ反映
        p.scoreboard.adjust_scores.assert_called_once_with({"B": -2, "C": 2})
        pts, races = self._players()
        self.assertEqual(pts["B◇SD"], 8 + 10)            # レース1で2位(8) + レース2で1位(10)
        self.assertEqual(pts["Cじゃなくてd"], 10 + 8)
        self.assertEqual(races, [1, 2])
        self.assertIn("B:-2", text)
        d = p.session.load_race(1)
        self.assertTrue(d["edited"])
        self.assertEqual(d["rows_original"][0]["text"], "B◇SD")

    def test_exclude_and_include_race(self):
        p = self.p
        names = p._races_load(2)["names"]
        p._races_save(2, names, False)                   # レース2を集計から外す
        p.scoreboard.adjust_scores.assert_called_once_with({"A": -5, "B": -13, "C": -10, "D": -11})
        pts, races = self._players()
        self.assertEqual(races, [1])
        self.assertEqual(pts["B◇SD"], 10)
        p.scoreboard.adjust_scores.reset_mock()
        p._races_save(2, names, True)                    # 戻す
        p.scoreboard.adjust_scores.assert_called_once_with({"A": 5, "B": 13, "C": 10, "D": 11})
        self.assertEqual(self._players()[1], [1, 2])

    def test_revert_restores_everything(self):
        p = self.p
        names = p._races_load(1)["names"]
        names[0], names[1] = names[1], names[0]
        p._races_save(1, names, True)
        p.scoreboard.adjust_scores.reset_mock()
        text = p._races_revert(1)
        p.scoreboard.adjust_scores.assert_called_once_with({"B": 2, "C": -2})
        self.assertIn("reverted", text)
        d = p.session.load_race(1)
        self.assertNotIn("rows_original", d)
        self.assertEqual(self._players()[0]["B◇SD"], 20)
        self.assertEqual(p._races_revert(1), "This race has not been edited.")

    def test_blank_line_keeps_rank_and_extra_rows_ignored(self):
        p = self.p
        names = p._races_load(1)["names"]
        names[2] = ""                                    # 3位は名前不明
        names.append("ghost")                            # 9行目
        p._races_save(1, names, True)
        rows = p.session.load_race(1)["rows"]
        self.assertEqual([r["rank"] for r in rows], [1, 2, 3, 4, 5, 6, 7, 8, None])
        self.assertIsNone(rows[2]["tag"])                # 3位のDの6点は付かない
        p.scoreboard.adjust_scores.assert_called_once_with({"D": -6})

    def test_different_tags_does_not_touch_board(self):
        p = self.p
        p.tags = ["A", "B", "C", "X"]                    # 途中でタグを変えた状況
        names = p._races_load(1)["names"]
        names[0], names[1] = names[1], names[0]
        text = p._races_save(1, names, True)
        p.scoreboard.adjust_scores.assert_not_called()
        self.assertIn("NOT changed", text)
        self.assertEqual(self._players()[0]["B◇SD"], 18)  # プレイヤー別は再集計される

    def test_pending_race_is_not_listed_and_unknown_race(self):
        p = self.p
        p.capture(self.rows)                             # 確認待ち (未確定)
        self.assertEqual([r["seq"] for r in p._races_list()], [1, 2])
        self.assertEqual(p._races_save(99, ["x"], True), "race 99 not found")
        p._open_races()                                  # 画面が開いても落ちない
        self.assertIsNotNone(p.races_win)
        p._refresh_races()
        p._on_races_closed()
        self.assertIsNone(p.races_win)

    def test_load_info_contains_edit_marker(self):
        p = self.p
        names = p._races_load(1)["names"]
        names[0] = "B◇SDX"
        p._races_save(1, names, True)
        self.assertIn("edited", p._races_load(1)["info"])
        self.assertTrue(p._races_list()[0]["edited"])


@unittest.skipUnless(FIXTURE.is_file(), "fixtures がありません")
class TestLeaderboardOutput(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.env = mock.patch.dict(os.environ, {"MK7_LOG_DIR": self.tmp.name,
                                                "MK7_EXPECTED_ROWS": "",
                                                "MK7_EVENT_TITLE": "Test Mogi"})
        self.env.start()
        self.p = FakePanel()
        self.rows = fixture_rows()

    def tearDown(self):
        self.env.stop()
        self.tmp.cleanup()

    def test_image_written_after_roster_and_confirm(self):
        p = self.p
        p.capture(self.rows)
        p._confirm()
        self.assertFalse((Path(self.tmp.name) / "leaderboard_latest.png").exists())  # 名簿なし
        p._apply_roster(TRUE_NAMES)
        for path in (p.session.folder / "leaderboard_live.png",
                     Path(self.tmp.name) / "leaderboard_latest.png"):
            self.assertTrue(path.is_file(), path)
            with Image.open(path) as im:
                self.assertEqual(im.size[0], 1600)
        before = (Path(self.tmp.name) / "leaderboard_latest.png").stat().st_mtime_ns
        p.capture(self.rows)
        p._confirm()                                     # 確定のたびに更新される
        self.assertGreaterEqual((Path(self.tmp.name) / "leaderboard_latest.png").stat().st_mtime_ns, before)

    def test_image_failure_does_not_break_players(self):
        p = self.p
        p.capture(self.rows)
        p._confirm()
        with mock.patch.object(app, "write_leaderboard", side_effect=RuntimeError("boom")):
            p._apply_roster(TRUE_NAMES)
        self.assertTrue((p.session.folder / "players.json").is_file())    # 集計は残る
        self.assertIn("leaderboard failed", p.status[-1])


@unittest.skipUnless(FIXTURE.is_file(), "fixtures がありません")
class TestImageExport(unittest.TestCase):
    """名簿ウィンドウの「画像出力」: セッションのフォルダに leaderboard.png を保存する"""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.env = mock.patch.dict(os.environ, {"MK7_LOG_DIR": self.tmp.name, "MK7_EXPECTED_ROWS": "",
                                                "MK7_EVENT_TITLE": "Export Test"})
        self.env.start()
        self.p = FakePanel()
        self.rows = fixture_rows()

    def tearDown(self):
        self.env.stop()
        self.tmp.cleanup()

    def _two_races_with_roster(self):
        for _ in range(2):
            self.p.capture(self.rows)
            self.p._confirm()
        self.p._apply_roster(TRUE_NAMES)

    def _wait(self):
        t = self.p._export_thread
        if t is not None:
            t.join(timeout=60)

    def test_export_writes_leaderboard_png_in_session_folder(self):
        p = self.p
        self._two_races_with_roster()
        msg = p._export_image("dark")
        self.assertIn("作成中", msg)
        self._wait()
        path = p.session.folder / "leaderboard.png"
        self.assertTrue(path.is_file())
        with Image.open(path) as im:
            self.assertEqual(im.mode, "RGB")
            self.assertGreater(im.size[0], 1000)                 # 倍率2で出力
        self.assertIn("画像を保存しました", p.status[-1])
        self.assertFalse(p._exporting)
        self.assertEqual(list(p.session.folder.glob("*.tmp")), [])

    def test_every_style_can_be_exported(self):
        p = self.p
        self._two_races_with_roster()
        for key in app.LB_STYLES:
            p._export_image(key)
            self._wait()
            self.assertIn("画像を保存しました", p.status[-1], key)

    def test_empty_roster_is_reported_without_making_an_image(self):
        p = self.p
        p.capture(self.rows)
        p._confirm()
        msg = p._export_image("dark")
        self.assertIn("名簿が空", msg)
        self.assertIsNone(p._export_thread)
        self.assertFalse((p.session.folder / "leaderboard.png").exists())
        self.assertEqual(p.status[-1], msg)

    def test_no_confirmed_race_is_reported(self):
        p = self.p
        p.roster = list(TRUE_NAMES)
        self.assertIn("確定済みのレースがありません", p._export_image("dark"))     # セッション自体が無い
        p.capture(self.rows)                                    # 読み取っただけで確定しない
        self.assertIn("確定済みのレースがありません", p._export_image("dark"))
        self.assertFalse((p.session.folder / "leaderboard.png").exists())

    def test_second_click_while_running_is_ignored(self):
        p = self.p
        self._two_races_with_roster()
        p._exporting = True
        self.assertIn("作成中", p._export_image("dark"))
        self.assertIsNone(p._export_thread)

    def test_render_failure_does_not_crash_and_allows_retry(self):
        p = self.p
        self._two_races_with_roster()
        with mock.patch.object(app, "render_table", side_effect=RuntimeError("boom")):
            p._export_image("dark")
            self._wait()
        self.assertIn("画像出力に失敗しました", p.status[-1])
        self.assertIn("boom", p.status[-1])
        self.assertFalse(p._exporting)
        self.assertFalse((p.session.folder / "leaderboard.png").exists())
        p._export_image("dark")                                  # もう一度試せる
        self._wait()
        self.assertIn("画像を保存しました", p.status[-1])

    def test_unknown_style_is_reported_as_failure(self):
        p = self.p
        self._two_races_with_roster()
        p._export_image("nope")
        self._wait()
        self.assertIn("画像出力に失敗しました", p.status[-1])

    def test_team_scores_and_other_files_are_not_touched(self):
        p = self.p
        self._two_races_with_roster()
        before = json.loads((p.session.folder / "players.json").read_text("utf-8"))
        p._export_image("light")
        self._wait()
        after = json.loads((p.session.folder / "players.json").read_text("utf-8"))
        self.assertEqual(before, after)
        p.scoreboard.update_scores.assert_called()               # 既存の加算は従来どおり

    def test_window_passes_the_selected_style_to_the_app(self):
        from players_window import PlayersWindow
        got = []
        win = PlayersWindow(None, {"bg": "#000", "bg2": "#111", "fg": "#fff", "fg2": "#aaa",
                                   "btnb": "#333", "btnf": "#fff"}, [], lambda n: None, lambda: [],
                            lambda: None, on_export=lambda k: got.append(k) or "ok",
                            styles=[(k, v["name"]) for k, v in app.LB_STYLES.items()])
        win.var_style.get = lambda: "Atlas League"
        win._export()
        self.assertEqual(got, ["atlasLeague"])


@unittest.skipUnless(FIXTURE.is_file(), "fixtures がありません")
class TestListsInApp(unittest.TestCase):
    """LISTS: OCRミスのリスト (照合に使う) と、表示名の辞書 (lorenzi 画像だけに使う)"""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.settings = Path(self.tmp.name) / "settings"
        self.env = mock.patch.dict(os.environ, {"MK7_LOG_DIR": str(Path(self.tmp.name) / "logs"),
                                                "MK7_SETTINGS_DIR": str(self.settings),
                                                "MK7_EXPECTED_ROWS": ""})
        self.env.start()
        self.p = FakePanel()
        self.rows = fixture_rows()

    def tearDown(self):
        self.env.stop()
        self.tmp.cleanup()

    def _two_races_with_roster(self):
        for _ in range(2):
            self.p.capture(self.rows)
            self.p._confirm()
        self.p._apply_roster(TRUE_NAMES)

    def _players(self):
        rep = json.loads((self.p.session.folder / "players.json").read_text("utf-8"))
        return {pl["name"]: pl["points"] for pl in rep["players"]}, rep

    def _export_model(self, style="dark"):
        """画像出力に渡された model を取り出す (描画そのものは差し替える)。"""
        got = []
        with mock.patch.object(app, "render_table",
                               side_effect=lambda model, *a, **k: got.append(model) or Image.new("RGB", (60, 40))):
            self.p._export_image(style)
            self.p._export_thread.join(timeout=60)
        return got[0]

    def test_save_writes_files_and_reports_counts_and_ignored_lines(self):
        msg = self.p._save_lists("4 -> A\nthis line is broken", "B◇SD = SD")
        self.assertIn("保存しました", msg)
        self.assertIn("OCRミス 1 件", msg)
        self.assertIn("表示名 1 件", msg)
        self.assertIn("無視した行が 1 件", msg)
        self.assertTrue((self.settings / "ocr_fixes.txt").is_file())
        self.assertTrue((self.settings / "name_dictionary.txt").is_file())
        self.assertEqual(self.p.lists.rules, [("4", "A")])
        self.assertIn("保存しました", self.p.status[-1])

    def test_misread_row_is_fixed_retroactively_after_saving_the_list(self):
        p = self._two_races_with_roster_and_misread()
        self.assertEqual(self._players()[0]["B◇SD"], 10)               # 1レース目の行が誤読 → 加算されない
        self.assertIn("8S0", p._unmatched_text())
        p._save_lists("8 -> B\n0 -> D", "")                            # リストを追加 → 過去のレースにも効く
        pts, rep = self._players()
        self.assertEqual(pts["B◇SD"], 20)
        self.assertEqual([(c["race"], c["text"], c["fixed"], c["player"]) for c in rep["corrections"]],
                         [(1, "8S0", "BSD", "B◇SD")])
        self.assertIn("マッチしていない名前はありません", p._unmatched_text())
        # 画像にも同じ結果が出る (名簿画面の集計と食い違わない)
        model = self._export_model()
        scores = {pl["name"]: pl["scores"] for t in model["teams"] for pl in t["players"]}
        self.assertEqual(scores["B◇SD"], [20])                        # 2レースの和 (4レース未満なので1列)

    def _two_races_with_roster_and_misread(self):
        p = self.p
        self._two_races_with_roster()
        names = p._races_load(1)["names"]
        names[0] = "8S0"                                               # B◇SD が誤読された
        p._races_save(1, names, True)
        return p

    def test_removing_a_rule_takes_the_fix_away(self):
        p = self._two_races_with_roster_and_misread()
        p._save_lists("8 -> B\n0 -> D", "")
        self.assertEqual(self._players()[0]["B◇SD"], 20)
        p._save_lists("", "")
        self.assertEqual(self._players()[0]["B◇SD"], 10)

    def test_dictionary_changes_only_the_names_on_the_lorenzi_image(self):
        p = self.p
        p._save_lists("", "B◇SD = SD\nAyaneko = あやねこ")
        self._two_races_with_roster()
        model = self._export_model()
        shown = {pl["name"] for t in model["teams"] for pl in t["players"]}
        self.assertIn("SD", shown)
        self.assertIn("あやねこ", shown)
        self.assertNotIn("B◇SD", shown)
        # 集計・名簿画面・保存ファイルは試合中の名前のまま
        pts, rep = self._players()
        self.assertIn("B◇SD", pts)
        self.assertNotIn("SD", pts)
        self.assertIn("B◇SD", (p.session.folder / "players.txt").read_text("utf-8-sig"))
        self.assertNotIn("あやねこ", (p.session.folder / "players.txt").read_text("utf-8-sig"))
        self.assertEqual(p.session.load_roster(), TRUE_NAMES)

    def test_lists_persist_and_are_loaded_again(self):
        self.p._save_lists("4 -> A", "B◇SD = SD")
        again = FakePanel()._load_lists()
        self.assertEqual((again.rules, again.names), ([("4", "A")], {"B◇SD": "SD"}))
        self.assertEqual(NameLists().rules, [])

    def test_save_failure_keeps_the_old_lists(self):
        self.p._save_lists("4 -> A", "")
        blocker = Path(self.tmp.name) / "blocker"
        blocker.write_text("x")
        with mock.patch.dict(os.environ, {"MK7_SETTINGS_DIR": str(blocker / "sub")}):
            msg = self.p._save_lists("0 -> O", "")
        self.assertIn("保存に失敗しました", msg)
        self.assertEqual(self.p.lists.rules, [("4", "A")])

    def test_unmatched_text_messages_and_window(self):
        p = self.p
        self.assertIn("名簿を適用", p._unmatched_text())
        p.roster = list(TRUE_NAMES)
        self.assertIn("確定済みのレースがまだありません", p._unmatched_text())
        p._open_lists()                                                # 画面が開いても落ちない
        self.assertIsNotNone(p.lists_win)
        p._on_lists_closed()
        self.assertIsNone(p.lists_win)

    def test_window_passes_the_texts_to_the_app(self):
        from lists_window import ListsWindow
        saved = []
        win = ListsWindow(None, {"bg": "#000", "bg2": "#111", "fg": "#fff", "fg2": "#aaa",
                                 "btnb": "#333", "btnf": "#fff"}, "", "", "#help1", "#help2",
                          lambda f, d: saved.append((f, d)) or "ok", lambda: "none", lambda: None)
        win.texts = lambda: ("4 -> A", "x = y")
        win._save()
        self.assertEqual(saved, [("4 -> A", "x = y")])


@unittest.skipUnless(FIXTURE.is_file(), "fixtures がありません")
class TestLorenziTextInPlayersWindow(unittest.TestCase):
    """PLAYERS ウィンドウに、lorenzi の入力欄に貼るテキストを表示する (得点は4レースごとの和)"""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.env = mock.patch.dict(os.environ, {"MK7_LOG_DIR": str(Path(self.tmp.name) / "logs"),
                                                "MK7_SETTINGS_DIR": str(Path(self.tmp.name) / "settings"),
                                                "MK7_EXPECTED_ROWS": "", "MK7_EVENT_TITLE": "Mock 1"})
        self.env.start()
        self.p = FakePanel()
        self.rows = fixture_rows()

    def tearDown(self):
        self.env.stop()
        self.tmp.cleanup()

    def _confirm_races(self, n):
        for _ in range(n):
            self.p.capture(self.rows)
            self.p._confirm()

    def _player_line(self, text, name):
        return next(l for l in text.splitlines() if l.startswith(name + " "))

    def test_messages_when_nothing_can_be_shown_yet(self):
        p = self.p
        self.assertIn("名簿が空", p._lorenzi_text())
        p.roster = list(TRUE_NAMES)
        self.assertIn("確定済みのレースがありません", p._lorenzi_text())

    def test_text_for_twelve_races_has_three_columns(self):
        p = self.p
        self._confirm_races(12)
        p._apply_roster(TRUE_NAMES)
        text = p._lorenzi_text()
        self.assertTrue(text.startswith("#title Mock 1\n"))
        # 毎回同じ順位 (B◇SD は毎回1位=10点) → 4レースの和 40 が3列: 40|40|40
        self.assertEqual(self._player_line(text, "B◇SD"), "B◇SD 40|40|40")
        self.assertEqual(self._player_line(text, "D◇どわー"), "D◇どわー 4|4|4")       # 毎回8位 (1点)

    def test_text_for_five_races_is_four_plus_one(self):
        p = self.p
        self._confirm_races(5)
        p._apply_roster(TRUE_NAMES)
        text = p._lorenzi_text()
        self.assertEqual(self._player_line(text, "B◇SD"), "B◇SD 40|10")               # 4レースの和 | 余り1レース
        self.assertEqual(self._player_line(text, "C◆うお"), "C◆うお 8|2")             # 毎回7位 (2点)

    def test_text_uses_the_dictionary_but_the_screen_does_not(self):
        p = self.p
        self._confirm_races(2)
        p._apply_roster(TRUE_NAMES)
        p._save_lists("", "B◇SD = SD")
        self.assertIn("\nSD 20\n", p._lorenzi_text())
        self.assertNotIn("B◇SD", p._lorenzi_text())
        report_text = (p.session.folder / "players.txt").read_text("utf-8-sig")
        self.assertIn("B◇SD", report_text)

    def test_window_is_updated_whenever_the_players_screen_is_refreshed(self):
        p = self.p
        win = mock.MagicMock()
        win.winfo_exists.return_value = True
        p.players_win = win
        p._refresh_players()                                       # 名簿なし → 理由を表示
        self.assertIn("名簿が空", win.show_lorenzi.call_args[0][0])
        self._confirm_races(2)                                     # 確定のたびに更新される
        p._apply_roster(TRUE_NAMES)
        self.assertIn("B◇SD 20", win.show_lorenzi.call_args[0][0])
        self._confirm_races(1)
        self.assertIn("B◇SD 30", win.show_lorenzi.call_args[0][0])  # 3レースの和 (まだ1列)

    def test_text_and_image_come_from_the_same_model(self):
        p = self.p
        self._confirm_races(5)
        p._apply_roster(TRUE_NAMES)
        got = []
        with mock.patch.object(app, "render_table",
                               side_effect=lambda model, *a, **k: got.append(model) or Image.new("RGB", (60, 40))):
            p._export_image("dark")
            p._export_thread.join(timeout=60)
        cols = {len(pl["scores"]) for t in got[0]["teams"] for pl in t["players"]}
        self.assertEqual(cols, {2})                                # 画像も 4レースごとの和 (4|1)
        by_name = {pl["name"]: pl["scores"] for t in got[0]["teams"] for pl in t["players"]}
        self.assertEqual(by_name["B◇SD"], [40, 10])

    def test_copy_button_copies_the_shown_text(self):
        from players_window import PlayersWindow
        win = PlayersWindow(None, {"bg": "#000", "bg2": "#111", "fg": "#fff", "fg2": "#aaa",
                                   "btnb": "#333", "btnf": "#fff"}, [], lambda n: None, lambda: [], lambda: None)
        win.txt_lorenzi.get = lambda *a: "A\nRen 4|4|4\n"
        win.clipboard_clear = mock.MagicMock()
        win.clipboard_append = mock.MagicMock()
        win._copy_lorenzi()
        win.clipboard_clear.assert_called_once()
        win.clipboard_append.assert_called_once_with("A\nRen 4|4|4")
        win.show_lorenzi("x")                                      # 表示の更新も落ちない


@unittest.skipUnless(FIXTURE.is_file(), "fixtures がありません")
class TestDictionaryFlagsInApp(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.env = mock.patch.dict(os.environ, {"MK7_LOG_DIR": str(Path(self.tmp.name) / "logs"),
                                                "MK7_SETTINGS_DIR": str(Path(self.tmp.name) / "settings"),
                                                "MK7_EXPECTED_ROWS": "", "MK7_EVENT_TITLE": ""})
        self.env.start()
        self.p = FakePanel()
        self.rows = fixture_rows()
        for _ in range(2):
            self.p.capture(self.rows)
            self.p._confirm()
        self.p._apply_roster(TRUE_NAMES)

    def tearDown(self):
        self.env.stop()
        self.tmp.cleanup()

    def test_lorenzi_text_and_image_get_the_flag(self):
        p = self.p
        p._save_lists("", "Ayaneko = Lemon [jp]\nB◇SD = [us]")
        text = p._lorenzi_text()
        lines = text.splitlines()
        self.assertTrue(any(l.startswith("Lemon [jp] ") for l in lines))
        self.assertTrue(any(l.startswith("B◇SD [us] ") for l in lines))
        got = []
        with mock.patch.object(app, "render_table",
                               side_effect=lambda model, *a, **k: got.append(model) or Image.new("RGB", (60, 40))):
            p._export_image("dark")
            p._export_thread.join(timeout=60)
        flags = {pl["name"]: pl["flag"] for t in got[0]["teams"] for pl in t["players"]}
        self.assertEqual((flags["Lemon"], flags["B◇SD"]), ("jp", "us"))

    def test_players_screen_and_files_are_not_affected(self):
        p = self.p
        p._save_lists("", "Ayaneko = Lemon [jp]")
        report = (p.session.folder / "players.txt").read_text("utf-8-sig")
        self.assertIn("Ayaneko", report)
        self.assertNotIn("Lemon", report)
        self.assertNotIn("[jp]", report)

    def test_saving_warns_about_flag_codes_without_an_image(self):
        p = self.p
        ok = p._save_lists("", "Ayaneko = Lemon [jp]\nB◇SD = [gb-eng]")
        self.assertNotIn("見つからない", ok)
        bad = p._save_lists("", "Ayaneko = Lemon [zz]\nB◇SD = [a.b]\nATM = x [jp]")
        self.assertIn("国旗の画像が見つからないコード: zz, a.b", bad)
        self.assertEqual(p._unknown_flag_codes(), ["zz", "a.b"])
        self.assertNotIn("見つからない", p._save_lists("", "Ayaneko = Lemon"))       # 国コードなしなら出ない



@unittest.skipUnless(FIXTURE.is_file(), "fixtures がありません")
class TestListsReloadFromTextFiles(unittest.TestCase):
    """LISTS を開いた瞬間に、テキストファイルの現在の内容が入力欄に入る。エディタで直した内容もそのまま反映される。"""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.settings = Path(self.tmp.name) / "settings"
        self.settings.mkdir()
        self.env = mock.patch.dict(os.environ, {"MK7_LOG_DIR": str(Path(self.tmp.name) / "logs"),
                                                "MK7_SETTINGS_DIR": str(self.settings),
                                                "MK7_EXPECTED_ROWS": "", "MK7_EVENT_TITLE": ""})
        self.env.start()
        self.p = FakePanel()
        self.rows = fixture_rows()

    def tearDown(self):
        self.env.stop()
        self.tmp.cleanup()

    def _write(self, name, text, encoding="utf-8"):
        (self.settings / name).write_bytes(text.encode(encoding))

    def _open_and_get_texts(self):
        with mock.patch.object(app, "ListsWindow") as win:
            self.p._open_lists()
        args = win.call_args[0]
        return args[2], args[3]              # (ocr_fixes.txt の内容, name_dictionary.txt の内容)

    def _two_races_with_roster(self):
        for _ in range(2):
            self.p.capture(self.rows)
            self.p._confirm()
        self.p._apply_roster(TRUE_NAMES)

    def test_opening_lists_puts_the_current_file_contents_into_the_boxes(self):
        fixes = "# よくあるミス\n4 -> A\n0 <-> O\n"
        names = "\n".join(["# 100件の名簿"] + [f"選手{i:03d} = 表示{i:03d}" for i in range(100)]) + "\n"
        self._write("ocr_fixes.txt", fixes)
        self._write("name_dictionary.txt", names)
        got_fix, got_dict = self._open_and_get_texts()
        self.assertEqual((got_fix, got_dict), (fixes, names))
        self.assertEqual(len(self.p.lists.names), 100)                       # 集計にも同じ内容が使われる
        self.assertEqual(self.p.lists.rules, [("4", "A"), ("0", "O"), ("O", "0")])

    def test_shift_jis_file_from_a_text_editor_is_shown_correctly(self):
        self._write("name_dictionary.txt", "Ayaneko = あやねこ\n", "cp932")
        self._write("ocr_fixes.txt", "4 -> A\n", "utf-16")
        got_fix, got_dict = self._open_and_get_texts()
        self.assertEqual(got_dict, "Ayaneko = あやねこ\n")
        self.assertEqual(got_fix, "4 -> A\n")

    def test_help_text_is_shown_only_when_the_files_do_not_exist(self):
        with mock.patch.object(app, "ListsWindow") as win:
            self.p._open_lists()
        args = win.call_args[0]
        self.assertEqual((args[2], args[3]), ("", ""))                       # 空 → 画面側が説明文を出す
        self.assertEqual((args[4], args[5]), (app.HELP_FIXES, app.HELP_DICT))

    def test_every_time_it_is_opened_the_files_are_read_again(self):
        self._write("name_dictionary.txt", "A = 1\n")
        self.assertEqual(self._open_and_get_texts()[1], "A = 1\n")
        self.p._on_lists_closed()
        self._write("name_dictionary.txt", "A = 1\nB = 2\n")                # エディタで追記して保存
        self.assertEqual(self._open_and_get_texts()[1], "A = 1\nB = 2\n")
        self.assertEqual(self.p.lists.names, {"A": "1", "B": "2"})

    def test_an_open_window_is_not_overwritten(self):
        self._write("name_dictionary.txt", "A = 1\n")
        win = mock.MagicMock()
        win.winfo_exists.return_value = True
        self.p.lists_win = win
        with mock.patch.object(app, "ListsWindow") as new_window:
            self.p._open_lists()
        win.lift.assert_called_once()
        new_window.assert_not_called()                                       # 編集中の内容を消さない

    def test_editing_the_files_takes_effect_without_opening_lists(self):
        p = self.p
        self._two_races_with_roster()
        self.assertTrue(any(l.startswith("B◇SD ") for l in p._lorenzi_text().splitlines()))
        self._write("name_dictionary.txt", "B◇SD = SD [us]\n")             # エディタで直しただけ
        p._refresh_players()
        text = p._lorenzi_text()
        self.assertTrue(any(l.startswith("SD [us] ") for l in text.splitlines()))
        got = []
        self._write("name_dictionary.txt", "B◇SD = エスディー\n")
        with mock.patch.object(app, "render_table",
                               side_effect=lambda model, *a, **k: got.append(model) or Image.new("RGB", (60, 40))):
            p._export_image("dark")
            p._export_thread.join(timeout=60)
        self.assertIn("エスディー", {pl["name"] for t in got[0]["teams"] for pl in t["players"]})

    def test_ocr_fix_list_edited_in_a_text_editor_takes_effect_too(self):
        p = self.p
        self._two_races_with_roster()
        names = p._races_load(1)["names"]
        names[0] = "8S0"                                                     # B◇SD が誤読された
        p._races_save(1, names, True)
        pts = lambda: json.loads((p.session.folder / "players.json").read_text("utf-8"))
        self.assertEqual({q["name"]: q["points"] for q in pts()["players"]}["B◇SD"], 10)
        self._write("ocr_fixes.txt", "8 -> B\n0 -> D\n")
        p._refresh_players()
        self.assertEqual({q["name"]: q["points"] for q in pts()["players"]}["B◇SD"], 20)
        self.assertEqual(len(pts()["corrections"]), 1)

    def test_the_dictionary_is_matched_exactly_in_the_app(self):
        p = self.p
        self._write("name_dictionary.txt", "ayaneko = あやねこ\nB◆SD = エスディー\n")   # 似ているが同じではない
        self._two_races_with_roster()
        text = p._lorenzi_text()
        self.assertTrue(any(l.startswith("Ayaneko ") for l in text.splitlines()))
        self.assertNotIn("あやねこ", text)
        self.assertNotIn("エスディー", text)
        self.assertIn("Ayaneko", p._unmatched_text())                          # 辞書に載っていない名前として示される

    def test_hint_about_names_missing_from_the_dictionary(self):
        p = self.p
        self._two_races_with_roster()
        self.assertNotIn("辞書に載っていない", p._unmatched_text())               # 辞書が空なら出さない
        self._write("name_dictionary.txt", "Ayaneko = あやねこ\n")
        p._refresh_players()
        hint = p._unmatched_text()
        self.assertIn("辞書に載っていない PLAYERS の名前", hint)
        self.assertIn("B◇SD", hint)
        self.assertNotIn("Ayaneko,", hint)                                      # 載っている名前は出さない
        everyone = "\n".join(f"{n} = {n}" for n in TRUE_NAMES)
        self._write("name_dictionary.txt", everyone)
        p._refresh_players()
        self.assertNotIn("辞書に載っていない", p._unmatched_text())

    def test_hint_is_shortened_when_there_are_many_names(self):
        p = self.p
        p.roster = [f"選手{i:02d}" for i in range(40)]
        self._write("name_dictionary.txt", "誰か = だれか\n")
        p._refresh_players()
        hint = p._unmatched_text()
        self.assertIn("ほか 25 件", hint)

    def test_saving_a_hundred_lines_roundtrips(self):
        text = "\n".join(f"選手{i:03d} = 表示{i:03d} [jp]" for i in range(100))
        msg = self.p._save_lists("", text)
        self.assertIn("表示名 100 件", msg)
        self.assertNotIn("無視した行", msg)
        got_fix, got_dict = self._open_and_get_texts()
        self.assertEqual(got_dict, text)

    def test_the_lists_window_puts_the_text_into_scrollable_boxes(self):
        import lists_window
        widgets = [mock.MagicMock() for _ in range(3)]                      # 入力欄2つ + 参考表示1つ
        pool = list(widgets)
        with mock.patch.object(lists_window.tk, "Text", side_effect=lambda *a, **k: pool.pop(0)), \
             mock.patch.object(lists_window.tk, "Scrollbar") as bar:
            lists_window.ListsWindow(None, {"bg": "#000", "bg2": "#111", "fg": "#fff", "fg2": "#aaa",
                                            "btnb": "#333", "btnf": "#fff"}, "4 -> A\n", "A = 1\n",
                                     "#help1", "#help2", lambda f, d: "ok", lambda: "none", lambda: None)
        widgets[0].insert.assert_any_call("1.0", "4 -> A\n")                 # ocr_fixes.txt の内容
        widgets[1].insert.assert_any_call("1.0", "A = 1\n")                  # name_dictionary.txt の内容
        self.assertEqual(bar.call_count, 3)                                   # 3つの欄すべてにスクロールバー

    def test_the_lists_window_shows_help_only_for_empty_files(self):
        import lists_window
        widgets = [mock.MagicMock() for _ in range(3)]
        pool = list(widgets)
        with mock.patch.object(lists_window.tk, "Text", side_effect=lambda *a, **k: pool.pop(0)):
            lists_window.ListsWindow(None, {"bg": "#000", "bg2": "#111", "fg": "#fff", "fg2": "#aaa",
                                            "btnb": "#333", "btnf": "#fff"}, "", "", "#help1", "#help2",
                                     lambda f, d: "ok", lambda: "none", lambda: None)
        widgets[0].insert.assert_any_call("1.0", "#help1")
        widgets[1].insert.assert_any_call("1.0", "#help2")

if __name__ == "__main__":
    unittest.main(verbosity=2)
