#!/usr/bin/env python3
"""
leaderboard_adapter.py -- 既存の集計結果を、順位表の描画 (leaderboard_render) の入力にする
==========================================================================================
入力:
    races   session.load_races() の結果 (確定済み = status が added のレース)
    roster  プレイヤー名簿 (名前のリスト)
    points  順位 → ポイントの表 (既定は race_log.DEFAULT_POINTS)

対応づけ (調査結果):
    * プレイヤーのチーム = 読み取った行に付いたタグのうち、そのプレイヤーに最も多く付いたもの
      (race_log.compute_player_totals の "team")。名簿の名前にタグの接頭辞は不要。
    * タグの無い (チームが決まらない) プレイヤーは "No team" のチームにまとめる。
    * レースごとのポイント = per_race[seq]["points"]。そのレースに出ていない場合は 0。
    * lorenzi の得点列は「4レースごとの和」にする (12レースなら 1|1|1|… ではなく 4|4|4 の3列)。
      4の倍数でないレース数は、最後の列に余ったレースの和を入れる (5レースなら 4|1)。
      1列あたりのレース数は races_per_column で変えられる (1 にすると従来どおりレースごと)。
    * 国旗は flags (名簿の名前 → 国コード) で渡す。無ければ国旗なしで描画される。
    * name_dict (試合中の名前 → 画像に載せる名前) は、この画像に出す名前だけに使う。
      照合・集計・flags・ボーナスの対応づけは、すべて試合中の名前 (名簿の名前) のまま行う。
      辞書の値の末尾に [国コード] を書くと、その国旗になる ("Lemon [jp]" → 名前 Lemon + 国旗 jp。
      "[jp]" だけなら名前はそのままで国旗だけ)。flags 引数より、辞書の国旗が優先される。
    * ocr_rules (OCR ミスのリスト) は、名簿の照合で一致しなかった行にだけ使う
      (名簿画面の集計と同じ結果にするため)。

to_lorenzi_text() は、同じ model を lorenzi の入力欄 (leaderboard-table-maker.html の parse) に
貼れるテキストにする。画像出力と同じ model から作るので、表の内容は一致する。

tkinter には依存しない。
"""

import re

from name_lists import display_name, split_flag
from race_log import compute_player_totals

NO_TEAM = "No team"
RACES_PER_COLUMN = 4          # lorenzi の得点列 1つに入れるレース数
ZWSP = "\u200b"                # 解釈を邪魔する文字の後ろに足す、見えない文字 (JS の trim() は取らない)


class ExportError(Exception):
    """画像を作れない理由 (そのまま利用者に見せられる文面)。"""


def build_model(races, roster, points=None, *, flags=None, title="", date=None,
                team_names=None, team_colors=None, team_bonus=None, player_bonus=None,
                hide_team_names=False, hide_team_scores=False, hide_player_scores=False,
                ocr_rules=None, name_dict=None, races_per_column=RACES_PER_COLUMN):
    """leaderboard_render.render_table に渡す model (dict) を作る。
    名簿が空 / 確定済みレースが無いときは ExportError。"""
    roster = [n for n in (roster or []) if n]
    if not roster:
        raise ExportError("名簿が空です。PLAYERS で名前を入力し、APPLY を押してください。")
    if not races:
        raise ExportError("確定済みのレースがありません。読み取り後に add score で確定してください。")

    flags = flags or {}
    team_names = team_names or {}
    team_colors = team_colors or {}
    team_bonus = team_bonus or {}
    player_bonus = player_bonus or {}

    report = compute_player_totals(races, roster, points, rules=ocr_rules)
    seqs = report["races"]
    n = max(1, int(races_per_column))
    chunks = [seqs[i:i + n] for i in range(0, len(seqs), n)]     # 4レースずつ (最後は余り)

    order = []                                        # チームの並び (表示順は render 側が合計で決める)
    for race in races:
        for t in race.get("tags") or []:
            if t not in order:
                order.append(t)
    for p in report["players"]:
        if p.get("team") and p["team"] not in order:
            order.append(p["team"])

    by_team = {}
    for p in report["players"]:
        tag = p.get("team") or NO_TEAM
        scores = [sum(p["per_race"].get(str(s), {}).get("points", 0) for s in chunk)
                  for chunk in chunks]
        shown = display_name(p["name"], name_dict)               # 画像に出す名前だけ辞書で置き換える
        dict_flag = None
        if shown != p["name"]:                                   # 辞書に載っている名前だけ、末尾の [国コード] を見る
            shown, dict_flag = split_flag(shown)
            shown = shown or p["name"]
        by_team.setdefault(tag, []).append({
            "name": shown,
            "flag": dict_flag or flags.get(p["name"]) or None,
            "scores": scores,
            "bonus": player_bonus.get(p["name"], 0),
        })

    teams = []
    for tag in order + ([NO_TEAM] if NO_TEAM in by_team else []):
        if tag not in by_team:
            continue
        teams.append({"tag": tag, "name": team_names.get(tag) or None,
                      "color": team_colors.get(tag) or None,
                      "bonus": team_bonus.get(tag, 0), "players": by_team[tag]})

    return {"title": title or "", "date": date, "teams": teams,
            "hide_team_names": hide_team_names, "hide_team_scores": hide_team_scores,
            "hide_player_scores": hide_player_scores}


# ── lorenzi の入力欄に貼るテキスト ───────────────
_SCORE_TAIL = re.compile(r"\s[0-9０-９＋－ー+|｜-]+$")          # 「空白 + 数字や + - |」で終わる = 得点に見える
_BONUS_TAIL = re.compile(r"[(（][0-9０-９＋－ー+-]+[)）]$")        # 末尾の (+5) = ボーナスに見える
_FLAG_TAIL = re.compile(r"[\]］」】]$")                          # 末尾の ] = 国コードに見える
_DASH = re.compile(r"\s+[-－ー]\s+")                            # " - " = チーム名の区切り


def _clean(text):
    return re.sub(r"[\r\n\t]+", " ", str(text)).strip()


def _safe_player(name):
    """選手名を、行の解釈が崩れない形にする (崩れうる場合だけ見えない文字を足す)。"""
    name = _clean(name).replace("|", "¦").replace("｜", "¦")
    if name.startswith("#"):                 # 行頭が # の行は、行ごと無視される
        name = ZWSP + name
    if _FLAG_TAIL.search(name):               # 末尾の [..] を国コードと見なされる
        name += ZWSP
    return name


def _safe_tag(tag):
    """チームのタグ行が、選手の行と間違われない形にする。"""
    tag = _DASH.sub(" ", _clean(tag))
    if tag.startswith("#"):
        tag = ZWSP + tag
    if _SCORE_TAIL.search(tag) or _BONUS_TAIL.search(tag):
        tag += ZWSP
    return tag


def _signed(n):
    return f"{n:+d}"


def to_lorenzi_text(model):
    """build_model の結果を、lorenzi の入力欄にそのまま貼れるテキストにする。

        #title Mock 1
        A
        Ren [jp] 4|4|4 (+5)
        Sam 3|5|4

    チーム行は「タグ [ - チーム名] [#色] [(ボーナス)]」、選手行は
    「名前 [国コード] 得点|得点|… [(ボーナス)]」。"""
    lines = []
    title = _clean(model.get("title") or "")
    if title:
        lines.append("#title " + title)
    hide = [name for name, key in (("teamNames", "hide_team_names"), ("teamScores", "hide_team_scores"),
                                   ("playerScores", "hide_player_scores")) if model.get(key)]
    if hide:
        lines.append("#hide " + ",".join(hide))
    for team in model.get("teams", []):
        head = _safe_tag(team["tag"])
        if team.get("name"):
            tname = _clean(team["name"])
            if _BONUS_TAIL.search(tname):
                tname += ZWSP
            head += " - " + tname
        if team.get("color"):
            head += " " + team["color"]
        if team.get("bonus"):
            head += f" ({_signed(team['bonus'])})"
        lines.append(head)
        for p in team["players"]:
            line = _safe_player(p["name"])
            if p.get("flag"):
                line += f" [{_clean(p['flag'])}]"
            line += " " + "|".join(str(x) for x in p["scores"])
            if p.get("bonus"):
                line += f" ({_signed(p['bonus'])})"
            lines.append(line)
        lines.append("")
    return "\n".join(lines).rstrip("\n") + "\n"
